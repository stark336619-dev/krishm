# SONORA — Premium Music Streaming Platform

SONORA is a production-oriented, Spotify-inspired dark-mode music streaming web application featuring persistent high-fidelity audio playback, comprehensive music catalog management, Google authentication, user libraries, and an administrative control suite.

---

## User Review & Critical Decisions

> [!IMPORTANT]
> The following core product and architecture decisions were confirmed:

- **Initial Catalog State**: Confirmed to start with an empty database state with sleek zero-state calls-to-action for manually adding tracks in Admin, plus an optional 1-click "Seed Demo Tracks" tool in the Admin panel to test streaming audio immediately.
- **Audio Delivery & Storage**: Direct streaming audio URLs (MP3, AAC, M4A, WAV, OGG) combined with client-side audio file uploads (persisted via browser storage / Object URLs) and automatic duration calculation.
- **Admin Authorization**: The user's account (`yug.hitendra2007@gmail.com`) is designated as the Super Administrator upon Google Sign-In, granting exclusive access to the `/admin` command center.
- **Data Persistence & Fallback**: Dual-layer persistent repository pattern integrating Cloud Firestore with local IndexedDB/LocalStorage sync so that playback, playlist creation, song addition, and favorites function seamlessly both in live Firebase and during local development.

---

## 1. Overview & Core Concept

- **What It Does**: SONORA delivers a Spotify-grade music streaming experience in deep charcoal and vibrant green (#1DB954). Users can stream songs, discover artists and albums, create and curate personal playlists, favorite tracks, control queue and playback, and search across music entities. Administrators possess full rights to upload/link tracks, manage metadata, control homepage feature carousels, view real listening metrics, and audit user activity.
- **Target Audience**: Music listeners seeking a desktop-class and mobile-responsive streaming web player, and content curators/labels managing music collections.
- **Key Value**: Zero lag, persistent cross-page audio playback with full queue management, keyboard accessibility, and a comprehensive music management CMS without relying on restrictive third-party Spotify APIs.

---

## 2. User Experience & Visual Design

### Key User Flows

1. **Discovery & Exploration**:
   - User lands on `/` greeted by a personalized time-aware header ("Good evening"), continue listening section, trending songs, popular albums, top artists, and curated playlists.
   - User clicks any track row or album card: audio immediately starts in the persistent bottom player without page interruption; queue updates with remaining tracks.

2. **Persistent Playback & Queue**:
   - Bottom bar contains track thumbnail, title, artist link, favorite button, playback controls (shuffle, previous, play/pause, next, repeat mode), interactive progress seek bar with buffered indication, volume slider, mute toggle, and Queue drawer toggle.
   - Mini-player on mobile floats above the bottom navigation bar with swipeable track info and expanded player view.

3. **Global Search**:
   - Dedicated `/search` view with instant debounced queries across Songs, Artists, Albums, and Playlists. Quick filter pills (`All`, `Songs`, `Artists`, `Albums`, `Playlists`) and recent search history management.

4. **Library & Playlist Creation**:
   - `/library` displays the user's personal playlists, saved albums, followed artists, and listening history.
   - Modal and dedicated page to create new playlists, customize cover artwork and description, and add songs via track context menus.

5. **Admin Management Suite**:
   - Secure `/admin` navigation with dedicated views: Dashboard Analytics, Song Catalog, Add Song Form, Album Manager, Artist Manager, Playlist Curator, User Management, and Homepage Customizer.
   - Comprehensive Add Song Form validates direct audio streams, tests playable formats, auto-extracts duration, previews artwork, and flags explicit/featured content.

### Visual Identity & Theme

- **Palette**:
  - Background Canvas: Deep Charcoal & True Black (`#0a0a0a` / `#121212`)
  - Elevated Surfaces & Cards: Charcoal Slate (`#181818` / `#222222`)
  - Accent Color: Sonic Emerald Green (`#1DB954` / `#1ed760`)
  - Typography: Pure White (`#FFFFFF`) for primary titles, Cool Platinum (`#A7A7A7`) for secondary metadata, and Subtle Hairlines (`rgba(255, 255, 255, 0.08)`)
- **Typography**:
  - Display / Headings: `Plus Jakarta Sans` (bold, geometric, high clarity)
  - Body & UI: `DM Sans` / `Plus Jakarta Sans` with strict `tabular-nums` for timestamps and track durations
- **Layout Math & Anti-Slop Discipline**:
  - Clean unboxed metadata separated by typographic dots (`·`)
  - No decorative pulsating dots or mechanical code comments
  - Single-elevation card depth with smooth hover micro-translations (`scale-[1.02]` on play hover)
  - 1440px desktop baseline with a 260px collapsible sidebar and 15% mobile sticky height cap

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Persistent Audio Context via React Context & HTML5 Audio Engine**
  - *Chosen Approach*: Single global `AudioPlayerContext` managing an underlying HTML5 `Audio` instance outside of route lifecycle.
  - *Why*: Ensures songs never skip, stutter, or reset when navigating between `/search`, `/library`, `/album/:id`, or `/admin`.
  - *Alternatives Considered*: Per-page audio elements (causes audio cutoff on navigation) or third-party bloated libraries (unnecessary bundle overhead).

- **Decision 2: Dual Persistence Storage Adapter (Firestore + IndexedDB)**
  - *Chosen Approach*: Repository interface (`MusicRepository`) with Firebase Firestore backend and automatic local synchronization.
  - *Why*: Allows immediate, reliable testing and song addition even before cloud credentials are provisioned, with zero risk of blank screens or broken flows.

- **Decision 3: Server-Gated & Security-Rule-Enforced Super Admin**
  - *Chosen Approach*: Hardened access control matching `request.auth.token.email == 'yug.hitendra2007@gmail.com'` alongside Firestore admin role validation. Non-admin users attempting to access `/admin` are redirected to an unauthorized screen.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌────────────────────────────────────────────────────────────────────────┐
│                          SONORA APPLICATION                            │
├────────────────────────────────────────────────────────────────────────┤
│                                                                        │
│   ┌────────────────────────┐         ┌──────────────────────────────┐  │
│   │   Desktop Sidebar      │         │   Top Navigation Bar         │  │
│   │   • Brand & Home       │         │   • Nav History (< >)        │  │
│   │   • Search & Library   │         │   • User Profile & Auth      │  │
│   │   • Playlists & Admin  │         │   • Admin Quick Badge        │  │
│   └───────────┬────────────┘         └──────────────┬───────────────┘  │
│               │                                     │                  │
│               ▼                                     ▼                  │
│   ┌─────────────────────────────────────────────────────────────────┐  │
│   │                   Active Route View Router                      │  │
│   │   /              /search         /library      /liked           │  │
│   │   /albums/:id    /artists/:id    /playlists/:id                 │  │
│   │   /admin         /admin/songs    /admin/songs/new  ...          │  │
│   └─────────────────────────────────┬───────────────────────────────┘  │
│                                     │                                  │
│                                     ▼                                  │
│   ┌─────────────────────────────────────────────────────────────────┐  │
│   │                    Persistent Audio Player                      │  │
│   │   • Track Details    • Controls (Play/Pause/Skip/Shuffle/Rep)   │  │
│   │   • Timeline Scrubber with Range • Volume & Mute • Queue Drawer │  │
│   └─────────────────────────────────┬───────────────────────────────┘  │
│                                     │                                  │
└─────────────────────────────────────┼──────────────────────────────────┘
                                      │
        ┌─────────────────────────────┴────────────────────────────┐
        │                                                          │
        ▼                                                          ▼
┌───────────────────────────────┐          ┌───────────────────────────────┐
│     Firebase Authentication   │          │    Cloud Firestore & Cache    │
│  • Google Sign-In Popup       │          │  • songs, albums, artists     │
│  • Session Persistence        │          │  • playlists, likes, history  │
│  • Super Admin UID verification│         │  • adminAuditLogs, analytics  │
└───────────────────────────────┘          └───────────────────────────────┘
```

### Core Data Models (Normalized Firestore Schema)

1. **Song (`songs/{songId}`)**:
   - `id`: string
   - `title`: string
   - `artist`: string (and `artistIds`: string[])
   - `album`: string (and `albumId`: string)
   - `coverUrl`: string
   - `audioUrl`: string
   - `duration`: number (in seconds)
   - `genre`: string
   - `language`: string
   - `releaseDate`: string
   - `lyrics`: string (optional)
   - `isExplicit`: boolean
   - `isFeatured`: boolean
   - `isPublished`: boolean
   - `playCount`: number
   - `createdAt`: string
   - `updatedAt`: string

2. **Album (`albums/{albumId}`)**:
   - `id`: string, `title`: string, `artist`: string, `coverUrl`: string, `releaseYear`: number, `songIds`: string[]

3. **Artist (`artists/{artistId}`)**:
   - `id`: string, `name`: string, `photoUrl`: string, `bio`: string, `genres`: string[], `followerCount`: number

4. **Playlist (`playlists/{playlistId}`)**:
   - `id`: string, `title`: string, `description`: string, `coverUrl`: string, `ownerId`: string, `ownerName`: string, `songIds`: string[], `isPublic`: boolean, `isFeatured`: boolean

5. **Like (`likes/{userId_songId}`)**:
   - `id`: string, `userId`: string, `songId`: string, `addedAt`: string

6. **Listening History (`history/{historyId}`)**:
   - `id`: string, `userId`: string, `songId`: string, `playedAt`: string

---

## 5. Execution Steps

1. **Environment & Metadata**:
   - Set applet branding to "SONORA — Premium Music Streaming" in `metadata.json` and `index.html`.
   - Install auxiliary packages (e.g., `canvas-confetti` or sound utilities if required).

2. **State & Repositories**:
   - Implement `types/music.ts` defining all entities.
   - Implement `services/storage.ts` with Firestore integration and local fallback.
   - Implement `context/AuthContext.tsx` with Google Sign-in and Super Admin resolution for `yug.hitendra2007@gmail.com`.
   - Implement `context/PlayerContext.tsx` with full audio controls, queue management, volume memory, repeat/shuffle algorithms, and keyboard bindings.

3. **Core Shell & Navigation**:
   - Create responsive shell: Desktop Sidebar, Top Navigation Bar, Mobile Bottom Bar, and Persistent Player.
   - Configure React client routing supporting all required paths (`/`, `/search`, `/library`, `/liked`, `/playlists/:id`, `/albums/:id`, `/artists/:id`, `/profile`, `/settings`, `/admin/*`).

4. **Music Views**:
   - Homepage with hero announcement, recent tracks, trending grid, and playlist spotlights.
   - Global Search with debounced multi-entity query filtering.
   - Library & Liked Songs with track sorting and custom playlist creation.
   - Detailed Album, Artist, and Playlist views with one-click "Play All" and track reordering.

5. **Admin Suite**:
   - Add Song form with direct audio URL validation, audio duration detection, and file caching.
   - Song management table with search, sorting, pagination, and bulk actions.
   - Albums, Artists, Playlists, Analytics, and User Management tables.
   - Quick "Seed Demo Music" button in Admin for rapid verification.

6. **Firebase Blueprint & Security Rules**:
   - Formulate `firebase-blueprint.json` and hardened `firestore.rules` enforcing role-based access control and admin security.

7. **Verification & Testing**:
   - Compile and verify with `compile_applet`.
   - Test audio playback, seeking, volume, queue transitions, playlist creation, and admin operations.
