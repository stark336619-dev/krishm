import React, { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  Search,
  ShieldCheck,
  User as UserIcon,
  LogOut,
  Sparkles,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface TopBarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  onBack: () => void;
  onForward: () => void;
  canGoBack?: boolean;
  canGoForward?: boolean;
  searchQuery?: string;
  onSearchChange?: (val: string) => void;
}

export const TopBar: React.FC<TopBarProps> = ({
  currentPath,
  onNavigate,
  onBack,
  onForward,
  canGoBack = true,
  canGoForward = true,
  searchQuery = '',
  onSearchChange,
}) => {
  const { userProfile, isAdmin, signInWithGoogle, signOutUser, simulateAdminLogin } = useAuth();
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isSigningIn, setIsSigningIn] = useState(false);

  const handleSignIn = async () => {
    setIsSigningIn(true);
    try {
      await signInWithGoogle();
    } catch {
      // Fallback
    } finally {
      setIsSigningIn(false);
    }
  };

  return (
    <header className="h-16 bg-[#101010]/90 backdrop-blur-md sticky top-0 z-30 px-6 flex items-center justify-between border-b border-white/5">
      {/* Left Zone: History Navigation & Search */}
      <div className="flex items-center gap-4 flex-1">
        <div className="flex items-center gap-2">
          <button
            onClick={onBack}
            disabled={!canGoBack}
            className="w-8 h-8 rounded-full bg-black/60 flex items-center justify-center text-white hover:bg-black transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
            title="Go back"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button
            onClick={onForward}
            disabled={!canGoForward}
            className="w-8 h-8 rounded-full bg-black/60 flex items-center justify-center text-white hover:bg-black transition-colors disabled:opacity-30 disabled:cursor-not-allowed"
            title="Go forward"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>

        {/* Global Search Bar (prominent on /search, accessible everywhere) */}
        {currentPath === '/search' ? (
          <div className="relative max-w-md w-full">
            <Search className="w-4 h-4 text-[#727272] absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={e => onSearchChange?.(e.target.value)}
              placeholder="What do you want to play?"
              className="w-full bg-[#242424] text-white text-xs pl-10 pr-4 py-2.5 rounded-full border border-transparent focus:border-white/30 focus:outline-none placeholder-[#727272] transition-all"
              autoFocus
            />
          </div>
        ) : null}
      </div>

      {/* Right Zone: Admin Link, Quick Seed, Auth */}
      <div className="flex items-center gap-3">
        {isAdmin && !currentPath.startsWith('/admin') && (
          <button
            onClick={() => onNavigate('/admin')}
            className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-[#1db954]/10 hover:bg-[#1db954]/20 text-[#1db954] text-xs font-semibold border border-[#1db954]/30 transition-all hover:scale-105"
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            <span>Admin</span>
          </button>
        )}

        {userProfile ? (
          <div className="relative">
            <button
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="flex items-center gap-2 bg-[#121212] hover:bg-[#282828] p-1 pr-3 rounded-full border border-white/10 transition-colors"
            >
              {userProfile.photoURL ? (
                <img
                  src={userProfile.photoURL}
                  alt={userProfile.displayName || 'User'}
                  className="w-7 h-7 rounded-full object-cover"
                />
              ) : (
                <div className="w-7 h-7 rounded-full bg-[#333333] flex items-center justify-center text-white text-xs font-bold">
                  {userProfile.displayName?.charAt(0).toUpperCase() || 'U'}
                </div>
              )}
              <span className="text-xs font-semibold text-white max-w-[120px] truncate">
                {userProfile.displayName || userProfile.email}
              </span>
            </button>

            {/* Dropdown Menu */}
            {isDropdownOpen && (
              <>
                <div
                  className="fixed inset-0 z-40"
                  onClick={() => setIsDropdownOpen(false)}
                />
                <div className="absolute right-0 mt-2 w-48 bg-[#282828] rounded-lg shadow-2xl py-1.5 z-50 border border-white/10 text-xs">
                  <div className="px-4 py-2 border-b border-white/10">
                    <p className="font-semibold text-white truncate">
                      {userProfile.displayName}
                    </p>
                    <p className="text-[#a7a7a7] text-[10px] truncate">
                      {userProfile.email}
                    </p>
                    {isAdmin && (
                      <span className="inline-block mt-1 text-[10px] text-[#1db954] font-semibold bg-[#1db954]/10 px-2 py-0.5 rounded-full">
                        Super Admin
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => {
                      setIsDropdownOpen(false);
                      onNavigate('/profile');
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-[#383838] text-white flex items-center gap-2"
                  >
                    <UserIcon className="w-3.5 h-3.5" />
                    <span>Profile</span>
                  </button>
                  {isAdmin && (
                    <button
                      onClick={() => {
                        setIsDropdownOpen(false);
                        onNavigate('/admin');
                      }}
                      className="w-full text-left px-4 py-2 hover:bg-[#383838] text-[#1db954] flex items-center gap-2 font-medium"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      <span>Admin Command Center</span>
                    </button>
                  )}
                  <div className="border-t border-white/10 my-1" />
                  <button
                    onClick={() => {
                      setIsDropdownOpen(false);
                      signOutUser();
                    }}
                    className="w-full text-left px-4 py-2 hover:bg-[#383838] text-red-400 flex items-center gap-2"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    <span>Sign Out</span>
                  </button>
                </div>
              </>
            )}
          </div>
        ) : (
          <div className="flex items-center gap-2">
            <button
              onClick={handleSignIn}
              disabled={isSigningIn}
              className="bg-white text-black font-bold text-xs px-5 py-2 rounded-full hover:bg-neutral-200 hover:scale-105 active:scale-95 transition-all shadow-md flex items-center gap-2"
            >
              <span>{isSigningIn ? 'Connecting...' : 'Sign In'}</span>
            </button>
            <button
              onClick={simulateAdminLogin}
              title="Instant Admin Access"
              className="text-[11px] text-[#1db954] hover:underline px-2 py-1"
            >
              Admin Demo
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
