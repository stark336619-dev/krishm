import React, { useEffect, useState } from 'react';
import {
  Home,
  Search,
  Library,
  PlusSquare,
  Heart,
  ShieldCheck,
  Disc3,
  Music2,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { Playlist } from '../../types/music';
import { musicRepository } from '../../services/musicRepository';

interface SidebarProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  onCreatePlaylist: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentPath,
  onNavigate,
  onCreatePlaylist,
}) => {
  const { userProfile, isAdmin } = useAuth();
  const [userPlaylists, setUserPlaylists] = useState<Playlist[]>([]);

  useEffect(() => {
    const fetchPlaylists = async () => {
      const all = await musicRepository.getPlaylists(userProfile?.uid);
      setUserPlaylists(all);
    };
    fetchPlaylists();
  }, [userProfile?.uid, currentPath]);

  const navItemClass = (path: string) =>
    `flex items-center gap-4 px-4 py-3 rounded-lg text-sm font-medium transition-colors ${
      currentPath === path
        ? 'bg-[#282828] text-white font-semibold'
        : 'text-[#b3b3b3] hover:text-white hover:bg-[#1a1a1a]'
    }`;

  return (
    <aside className="w-64 bg-[#000000] h-full flex flex-col p-2 gap-2 select-none shrink-0 border-r border-[#1a1a1a]">
      {/* Brand Header */}
      <div className="bg-[#121212] rounded-lg p-5 flex flex-col gap-5">
        <div
          onClick={() => onNavigate('/')}
          className="flex items-center gap-3 cursor-pointer group"
        >
          <div className="w-9 h-9 rounded-full bg-[#1ed760] flex items-center justify-center text-black font-extrabold shadow-lg shadow-[#1ed760]/20 group-hover:scale-105 transition-transform overflow-hidden">
            <img
              src="/sterniters-logo-hd.png"
              alt="SONORA"
              className="w-full h-full object-cover"
              onError={e => {
                (e.currentTarget as HTMLElement).style.display = 'none';
              }}
            />
            <Disc3 className="w-5 h-5 animate-[spin_10s_linear_infinite]" />
          </div>
          <div className="flex flex-col">
            <span className="text-xl font-bold tracking-tight text-white group-hover:text-[#1ed760] transition-colors">
              KRISH MUSIC
            </span>
            <span className="text-[10px] text-[#1ed760] font-semibold tracking-wider uppercase">
              Developed by Krish
            </span>
          </div>
        </div>

        {/* Primary Navigation */}
        <nav className="flex flex-col gap-1">
          <button
            onClick={() => onNavigate('/')}
            className={navItemClass('/')}
          >
            <Home className="w-5 h-5 shrink-0" />
            <span>Home</span>
          </button>
          <button
            onClick={() => onNavigate('/search')}
            className={navItemClass('/search')}
          >
            <Search className="w-5 h-5 shrink-0" />
            <span>Search</span>
          </button>
          <button
            onClick={() => onNavigate('/library')}
            className={navItemClass('/library')}
          >
            <Library className="w-5 h-5 shrink-0" />
            <span>Your Library</span>
          </button>
        </nav>
      </div>

      {/* Playlists & Actions Container */}
      <div className="bg-[#121212] rounded-lg flex-1 flex flex-col p-4 overflow-hidden">
        <div className="flex items-center justify-between pb-3 border-b border-white/5">
          <span className="text-xs font-bold text-[#b3b3b3] uppercase tracking-wider">
            Collections
          </span>
          <button
            onClick={onCreatePlaylist}
            title="Create Playlist"
            className="p-1 text-[#b3b3b3] hover:text-white hover:bg-[#282828] rounded-full transition-colors"
          >
            <PlusSquare className="w-4 h-4" />
          </button>
        </div>

        {/* Shortcuts */}
        <div className="flex flex-col gap-1 my-3">
          <button
            onClick={() => onNavigate('/liked')}
            className={`flex items-center gap-3 px-3 py-2 rounded-md text-xs font-medium transition-colors ${
              currentPath === '/liked'
                ? 'bg-[#282828] text-white'
                : 'text-[#b3b3b3] hover:text-white hover:bg-[#1a1a1a]'
            }`}
          >
            <div className="w-6 h-6 rounded bg-gradient-to-br from-[#450af5] to-[#c4efd9] flex items-center justify-center text-white">
              <Heart className="w-3.5 h-3.5 fill-white" />
            </div>
            <span>Liked Songs</span>
          </button>

          {isAdmin && (
            <button
              onClick={() => onNavigate('/admin')}
              className={`flex items-center gap-3 px-3 py-2 rounded-md text-xs font-medium transition-colors ${
                currentPath.startsWith('/admin')
                  ? 'bg-[#1db954]/20 text-[#1db954] border border-[#1db954]/30'
                  : 'text-[#1db954] hover:bg-[#1db954]/10'
              }`}
            >
              <div className="w-6 h-6 rounded bg-[#1db954]/20 flex items-center justify-center text-[#1db954]">
                <ShieldCheck className="w-4 h-4" />
              </div>
              <span className="font-semibold">Admin Panel</span>
            </button>
          )}
        </div>

        {/* Playlist List */}
        <div className="flex-1 overflow-y-auto space-y-1 pr-1 custom-scroll">
          {userPlaylists.length === 0 ? (
            <div className="py-6 text-center text-xs text-[#727272]">
              <p>No playlists yet.</p>
              <button
                onClick={onCreatePlaylist}
                className="mt-2 text-xs text-[#1db954] hover:underline"
              >
                Create your first
              </button>
            </div>
          ) : (
            userPlaylists.map(pl => (
              <button
                key={pl.id}
                onClick={() => onNavigate(`/playlists/${pl.id}`)}
                className={`w-full text-left px-3 py-2 rounded text-xs truncate transition-colors flex items-center gap-2 ${
                  currentPath === `/playlists/${pl.id}`
                    ? 'text-white font-medium bg-[#242424]'
                    : 'text-[#a7a7a7] hover:text-white hover:bg-[#181818]'
                }`}
              >
                <Music2 className="w-3.5 h-3.5 shrink-0 opacity-60" />
                <span className="truncate">{pl.title}</span>
              </button>
            ))
          )}
        </div>
      </div>
    </aside>
  );
};
