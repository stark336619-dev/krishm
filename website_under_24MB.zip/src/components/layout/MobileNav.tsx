import React from 'react';
import { Home, Search, Library, Heart, ShieldCheck } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface MobileNavProps {
  currentPath: string;
  onNavigate: (path: string) => void;
}

export const MobileNav: React.FC<MobileNavProps> = ({ currentPath, onNavigate }) => {
  const { isAdmin } = useAuth();

  const itemClass = (path: string) =>
    `flex flex-col items-center justify-center gap-1 flex-1 py-1 text-[10px] font-medium transition-colors ${
      currentPath === path ? 'text-white' : 'text-[#a7a7a7] hover:text-white'
    }`;

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 h-14 bg-[#121212] border-t border-white/10 z-40 flex items-center justify-around px-2">
      <button onClick={() => onNavigate('/')} className={itemClass('/')}>
        <Home className="w-5 h-5" />
        <span>Home</span>
      </button>
      <button onClick={() => onNavigate('/search')} className={itemClass('/search')}>
        <Search className="w-5 h-5" />
        <span>Search</span>
      </button>
      <button onClick={() => onNavigate('/library')} className={itemClass('/library')}>
        <Library className="w-5 h-5" />
        <span>Library</span>
      </button>
      <button onClick={() => onNavigate('/liked')} className={itemClass('/liked')}>
        <Heart className="w-5 h-5" />
        <span>Liked</span>
      </button>
      {isAdmin && (
        <button
          onClick={() => onNavigate('/admin')}
          className={`flex flex-col items-center justify-center gap-1 flex-1 py-1 text-[10px] font-medium ${
            currentPath.startsWith('/admin') ? 'text-[#1db954]' : 'text-[#1db954]/70'
          }`}
        >
          <ShieldCheck className="w-5 h-5" />
          <span>Admin</span>
        </button>
      )}
    </nav>
  );
};
