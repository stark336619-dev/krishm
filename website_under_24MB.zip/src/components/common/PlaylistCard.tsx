import React from 'react';
import { Play } from 'lucide-react';
import { Playlist } from '../../types/music';
import { getFallbackCoverArt } from '../../utils/format';

interface PlaylistCardProps {
  playlist: Playlist;
  onClick: () => void;
}

export const PlaylistCard: React.FC<PlaylistCardProps> = ({ playlist, onClick }) => {
  return (
    <div
      onClick={onClick}
      className="group bg-[#181818] hover:bg-[#282828] p-3.5 rounded-xl transition-all duration-200 cursor-pointer flex flex-col gap-3 select-none hover:shadow-xl hover:shadow-black/40"
    >
      <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-[#242424] shadow-md">
        <img
          src={playlist.coverUrl || getFallbackCoverArt(playlist.title, 'playlist')}
          alt={playlist.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute bottom-2 right-2 w-11 h-11 rounded-full bg-[#1db954] text-black flex items-center justify-center shadow-xl shadow-black/60 opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-200 hover:scale-105">
          <Play className="w-5 h-5 fill-black ml-0.5" />
        </div>
      </div>
      <div className="flex flex-col gap-1 min-w-0">
        <h4 className="text-sm font-bold text-white truncate group-hover:text-[#1db954] transition-colors">
          {playlist.title}
        </h4>
        <p className="text-xs text-[#a7a7a7] line-clamp-2 leading-relaxed">
          {playlist.description || `By ${playlist.ownerName}`}
        </p>
      </div>
    </div>
  );
};
