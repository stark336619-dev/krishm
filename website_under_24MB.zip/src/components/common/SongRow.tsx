import React, { useState, useEffect } from 'react';
import {
  Play,
  Pause,
  Heart,
  MoreHorizontal,
  Plus,
  Copy,
  Check,
} from 'lucide-react';
import { Song, Playlist } from '../../types/music';
import { usePlayer } from '../../context/PlayerContext';
import { useAuth } from '../../context/AuthContext';
import { formatDuration, getFallbackCoverArt } from '../../utils/format';
import { musicRepository } from '../../services/musicRepository';

interface SongRowProps {
  song: Song;
  index: number;
  contextQueue?: Song[];
  showAlbum?: boolean;
  onRemoveFromPlaylist?: (songId: string) => void;
}

export const SongRow: React.FC<SongRowProps> = ({
  song,
  index,
  contextQueue,
  showAlbum = true,
  onRemoveFromPlaylist,
}) => {
  const { currentSong, isPlaying, playSong, togglePlay, addToQueue } = usePlayer();
  const { userProfile } = useAuth();
  const [isLiked, setIsLiked] = useState(false);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [copied, setCopied] = useState(false);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [showPlaylistSubmenu, setShowPlaylistSubmenu] = useState(false);

  const isCurrent = currentSong?.id === song.id;

  useEffect(() => {
    if (!userProfile?.uid) return;
    musicRepository.getUserLikes(userProfile.uid).then(likes => {
      setIsLiked(likes.includes(song.id));
    });
  }, [userProfile?.uid, song.id]);

  const handleRowClick = () => {
    if (isCurrent) {
      togglePlay();
    } else {
      playSong(song, contextQueue);
    }
  };

  const handleToggleLike = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!userProfile?.uid) return;
    const newState = await musicRepository.toggleLike(userProfile.uid, song.id);
    setIsLiked(newState);
  };

  const handleAddToQueue = (e: React.MouseEvent) => {
    e.stopPropagation();
    addToQueue(song);
    setIsMenuOpen(false);
  };

  const handleCopyLink = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(song.audioUrl);
    setCopied(true);
    setTimeout(() => {
      setCopied(false);
      setIsMenuOpen(false);
    }, 1500);
  };

  const handleOpenPlaylists = async (e: React.MouseEvent) => {
    e.stopPropagation();
    if (!userProfile?.uid) return;
    const all = await musicRepository.getPlaylists(userProfile.uid);
    setPlaylists(all);
    setShowPlaylistSubmenu(true);
  };

  const handleAddToPlaylist = async (playlist: Playlist, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!playlist.songIds.includes(song.id)) {
      await musicRepository.updatePlaylist(playlist.id, {
        songIds: [...playlist.songIds, song.id],
      });
    }
    setIsMenuOpen(false);
    setShowPlaylistSubmenu(false);
  };

  return (
    <div
      onClick={handleRowClick}
      className={`group flex items-center gap-4 px-4 py-2.5 rounded-lg hover:bg-[#282828] cursor-pointer transition-colors relative select-none ${
        isCurrent ? 'bg-[#222222]' : ''
      }`}
    >
      {/* Index or Play icon */}
      <div className="w-6 flex items-center justify-center shrink-0">
        <span
          className={`text-xs tabular-nums font-mono group-hover:hidden ${
            isCurrent ? 'text-[#1db954] font-bold' : 'text-[#a7a7a7]'
          }`}
        >
          {index + 1}
        </span>
        <button className="hidden group-hover:flex items-center justify-center text-white">
          {isCurrent && isPlaying ? (
            <Pause className="w-3.5 h-3.5 fill-white text-[#1db954]" />
          ) : (
            <Play className="w-3.5 h-3.5 fill-white ml-0.5" />
          )}
        </button>
      </div>

      {/* Artwork thumbnail */}
      <img
        src={song.coverUrl || getFallbackCoverArt(song.title)}
        alt={song.title}
        className="w-10 h-10 rounded object-cover shrink-0 shadow-sm"
      />

      {/* Title & Artist */}
      <div className="flex-1 min-w-0 pr-2">
        <div className="flex items-center gap-1.5">
          <p
            className={`text-xs font-semibold truncate ${
              isCurrent ? 'text-[#1db954]' : 'text-white'
            }`}
          >
            {song.title}
          </p>
          {song.provider && song.provider !== 'local' && (
            <span
              className={`text-[9px] px-1.5 py-0.2 rounded font-semibold shrink-0 uppercase tracking-wider ${
                song.provider === 'spotify'
                  ? 'bg-[#1db954]/20 text-[#1db954]'
                  : song.provider === 'jamendo'
                  ? 'bg-rose-500/20 text-rose-300'
                  : 'bg-purple-500/20 text-purple-300'
              }`}
            >
              {song.provider === 'itunes' ? 'Regional' : song.provider}
            </span>
          )}
          {song.isExplicit && (
            <span className="text-[9px] bg-[#3e3e3e] text-[#a7a7a7] px-1 py-0.2 rounded font-mono uppercase font-bold shrink-0">
              E
            </span>
          )}
        </div>
        <p className="text-[11px] text-[#a7a7a7] truncate hover:text-white">
          {song.artist}
        </p>
      </div>

      {/* Album (desktop only) */}
      {showAlbum && (
        <div className="hidden md:block w-1/3 min-w-0 text-left">
          <p className="text-xs text-[#a7a7a7] truncate hover:text-white">
            {song.album || 'Single'}
          </p>
        </div>
      )}

      {/* Duration & Actions */}
      <div className="flex items-center gap-3 shrink-0">
        {userProfile && (
          <button
            onClick={handleToggleLike}
            className={`p-1 transition-colors ${
              isLiked
                ? 'text-[#1db954] opacity-100'
                : 'text-[#a7a7a7] opacity-0 group-hover:opacity-100 hover:text-white'
            }`}
          >
            <Heart
              className={`w-3.5 h-3.5 ${
                isLiked ? 'fill-[#1db954] text-[#1db954]' : ''
              }`}
            />
          </button>
        )}

        <span className="text-xs text-[#a7a7a7] tabular-nums font-mono w-10 text-right">
          {formatDuration(song.duration)}
        </span>

        {/* More actions button */}
        <div className="relative">
          <button
            onClick={(e) => {
              e.stopPropagation();
              setIsMenuOpen(!isMenuOpen);
            }}
            className="p-1 text-[#a7a7a7] hover:text-white opacity-0 group-hover:opacity-100 transition-opacity"
          >
            <MoreHorizontal className="w-4 h-4" />
          </button>

          {isMenuOpen && (
            <>
              <div
                className="fixed inset-0 z-40"
                onClick={(e) => {
                  e.stopPropagation();
                  setIsMenuOpen(false);
                  setShowPlaylistSubmenu(false);
                }}
              />
              <div
                onClick={(e) => e.stopPropagation()}
                className="absolute right-0 top-8 w-48 bg-[#282828] border border-white/10 rounded-lg shadow-2xl py-1.5 z-50 text-xs"
              >
                <button
                  onClick={handleAddToQueue}
                  className="w-full text-left px-3 py-2 hover:bg-[#383838] text-white flex items-center gap-2"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Add to Queue</span>
                </button>

                {userProfile && (
                  <button
                    onClick={handleOpenPlaylists}
                    className="w-full text-left px-3 py-2 hover:bg-[#383838] text-white flex items-center gap-2"
                  >
                    <Plus className="w-3.5 h-3.5" />
                    <span>Add to Playlist</span>
                  </button>
                )}

                {showPlaylistSubmenu && (
                  <div className="border-t border-white/10 mt-1 pt-1 max-h-36 overflow-y-auto custom-scroll">
                    {playlists.length === 0 ? (
                      <span className="px-3 py-1 text-[11px] text-[#727272] block">
                        No playlists
                      </span>
                    ) : (
                      playlists.map((pl) => (
                        <button
                          key={pl.id}
                          onClick={(e) => handleAddToPlaylist(pl, e)}
                          className="w-full text-left px-4 py-1.5 hover:bg-[#383838] text-[#a7a7a7] hover:text-white truncate"
                        >
                          {pl.title}
                        </button>
                      ))
                    )}
                  </div>
                )}

                <button
                  onClick={handleCopyLink}
                  className="w-full text-left px-3 py-2 hover:bg-[#383838] text-white flex items-center gap-2"
                >
                  {copied ? (
                    <Check className="w-3.5 h-3.5 text-[#1db954]" />
                  ) : (
                    <Copy className="w-3.5 h-3.5" />
                  )}
                  <span>{copied ? 'Copied Audio URL' : 'Copy Audio URL'}</span>
                </button>

                {onRemoveFromPlaylist && (
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsMenuOpen(false);
                      onRemoveFromPlaylist(song.id);
                    }}
                    className="w-full text-left px-3 py-2 hover:bg-[#383838] text-red-400 flex items-center gap-2 border-t border-white/10 mt-1"
                  >
                    <span>Remove from playlist</span>
                  </button>
                )}
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
