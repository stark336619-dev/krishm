import React, { useState } from 'react';
import { X, Music2, Image as ImageIcon } from 'lucide-react';
import { musicRepository } from '../../services/musicRepository';
import { useAuth } from '../../context/AuthContext';

interface CreatePlaylistModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCreated: (playlistId: string) => void;
}

export const CreatePlaylistModal: React.FC<CreatePlaylistModalProps> = ({
  isOpen,
  onClose,
  onCreated,
}) => {
  const { userProfile } = useAuth();
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [coverUrl, setCoverUrl] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setIsSubmitting(true);
    try {
      const newPlaylist = await musicRepository.createPlaylist({
        title: title.trim(),
        description: description.trim(),
        coverUrl: coverUrl.trim() || undefined,
        ownerId: userProfile?.uid || 'guest_user',
        ownerName: userProfile?.displayName || 'Sonora Listener',
        songIds: [],
        isPublic: true,
      });

      onCreated(newPlaylist.id);
      setTitle('');
      setDescription('');
      setCoverUrl('');
      onClose();
    } catch (e) {
      console.warn('Failed to create playlist:', e);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-[#242424] border border-white/10 rounded-2xl p-6 max-w-md w-full shadow-2xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-white/10">
          <div className="flex items-center gap-2">
            <Music2 className="w-5 h-5 text-[#1db954]" />
            <h3 className="text-base font-bold text-white">Create New Playlist</h3>
          </div>
          <button onClick={onClose} className="text-[#a7a7a7] hover:text-white">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
              Playlist Name <span className="text-[#1db954]">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="e.g. Late Night Vibes"
              className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
              autoFocus
              required
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
              Description (Optional)
            </label>
            <textarea
              value={description}
              onChange={e => setDescription(e.target.value)}
              placeholder="Give your playlist a description..."
              rows={2}
              className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
              Cover Image URL (Optional)
            </label>
            <input
              type="url"
              value={coverUrl}
              onChange={e => setCoverUrl(e.target.value)}
              placeholder="https://..."
              className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
            />
          </div>

          <div className="flex items-center justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 rounded-full text-xs font-semibold text-white hover:bg-white/10"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSubmitting || !title.trim()}
              className="bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-5 py-2 rounded-full disabled:opacity-50"
            >
              {isSubmitting ? 'Creating...' : 'Create'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
