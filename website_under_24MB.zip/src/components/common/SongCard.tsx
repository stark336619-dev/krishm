import React from 'react';
import { Play, Pause } from 'lucide-react';
import { Song } from '../../types/music';
import { usePlayer } from '../../context/PlayerContext';
import { getFallbackCoverArt } from '../../utils/format';

interface SongCardProps {
  song: Song;
  contextQueue?: Song[];
}

export const SongCard: React.FC<SongCardProps> = ({ song, contextQueue }) => {
  const { currentSong, isPlaying, playSong, togglePlay } = usePlayer();
  const isCurrent = currentSong?.id === song.id;

  const handlePlayClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (isCurrent) {
      togglePlay();
    } else {
      playSong(song, contextQueue);
    }
  };

  return (
    <div
      onClick={handlePlayClick}
      className="group bg-[#181818] hover:bg-[#282828] p-3.5 rounded-xl transition-all duration-200 cursor-pointer flex flex-col gap-3 relative select-none hover:shadow-xl hover:shadow-black/40"
    >
      <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-[#242424] shadow-md">
        <img
          src={song.coverUrl || getFallbackCoverArt(song.title)}
          alt={song.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />

        {/* Hover Floating Play Button (Spotify style) */}
        <button
          onClick={handlePlayClick}
          className={`absolute bottom-2 right-2 w-11 h-11 rounded-full bg-[#1db954] text-black flex items-center justify-center shadow-xl shadow-black/60 transition-all duration-200 transform hover:scale-105 hover:bg-[#1ed760] ${
            isCurrent
              ? 'opacity-100 translate-y-0'
              : 'opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0'
          }`}
        >
          {isCurrent && isPlaying ? (
            <Pause className="w-5 h-5 fill-black" />
          ) : (
            <Play className="w-5 h-5 fill-black ml-0.5" />
          )}
        </button>
      </div>

      <div className="flex flex-col gap-1 min-w-0">
        <h4 className="text-sm font-bold text-white truncate group-hover:text-[#1db954] transition-colors">
          {song.title}
        </h4>
        <p className="text-xs text-[#a7a7a7] truncate">{song.artist}</p>
        <div className="flex items-center gap-1.5 text-[11px] text-[#727272] mt-0.5">
          {song.provider && song.provider !== 'local' && (
            <span
              className={`text-[9px] px-1.5 py-0.2 rounded font-semibold uppercase tracking-wider ${
                song.provider === 'spotify'
                  ? 'bg-[#1db954]/20 text-[#1db954]'
                  : song.provider === 'jamendo'
                  ? 'bg-rose-500/20 text-rose-300'
                  : 'bg-purple-500/20 text-purple-300'
              }`}
            >
              {song.provider === 'itunes' ? 'Regional' : song.provider}
            </span>
          )}
          {song.genre && <span>{song.genre}</span>}
          {song.genre && song.releaseDate && <span aria-hidden="true">·</span>}
          {song.releaseDate && <span>{song.releaseDate.split('-')[0]}</span>}
        </div>
      </div>
    </div>
  );
};
