import React from 'react';
import { Play } from 'lucide-react';
import { Artist } from '../../types/music';
import { getFallbackCoverArt, formatNumber } from '../../utils/format';

interface ArtistCardProps {
  artist: Artist;
  onClick: () => void;
}

export const ArtistCard: React.FC<ArtistCardProps> = ({ artist, onClick }) => {
  return (
    <div
      onClick={onClick}
      className="group bg-[#181818] hover:bg-[#282828] p-3.5 rounded-xl transition-all duration-200 cursor-pointer flex flex-col gap-3 select-none hover:shadow-xl hover:shadow-black/40"
    >
      <div className="relative aspect-square w-full rounded-full overflow-hidden bg-[#242424] shadow-lg">
        <img
          src={artist.photoUrl || getFallbackCoverArt(artist.name, 'artist')}
          alt={artist.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute bottom-2 right-2 w-11 h-11 rounded-full bg-[#1db954] text-black flex items-center justify-center shadow-xl shadow-black/60 opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-200 hover:scale-105">
          <Play className="w-5 h-5 fill-black ml-0.5" />
        </div>
      </div>
      <div className="flex flex-col gap-1 min-w-0 text-center">
        <h4 className="text-sm font-bold text-white truncate group-hover:text-[#1db954] transition-colors">
          {artist.name}
        </h4>
        <p className="text-xs text-[#a7a7a7] capitalize">
          {artist.genres?.[0] ? `${artist.genres[0]} Artist` : 'Artist'}
        </p>
        <span className="text-[11px] text-[#727272] tabular-nums font-mono">
          {formatNumber(artist.monthlyListeners || 0)} monthly listeners
        </span>
      </div>
    </div>
  );
};
