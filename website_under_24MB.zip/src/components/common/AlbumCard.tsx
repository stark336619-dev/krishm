import React from 'react';
import { Play } from 'lucide-react';
import { Album } from '../../types/music';
import { getFallbackCoverArt } from '../../utils/format';

interface AlbumCardProps {
  album: Album;
  onClick: () => void;
}

export const AlbumCard: React.FC<AlbumCardProps> = ({ album, onClick }) => {
  return (
    <div
      onClick={onClick}
      className="group bg-[#181818] hover:bg-[#282828] p-3.5 rounded-xl transition-all duration-200 cursor-pointer flex flex-col gap-3 select-none hover:shadow-xl hover:shadow-black/40"
    >
      <div className="relative aspect-square w-full rounded-lg overflow-hidden bg-[#242424] shadow-md">
        <img
          src={album.coverUrl || getFallbackCoverArt(album.title, 'album')}
          alt={album.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
        />
        <div className="absolute bottom-2 right-2 w-11 h-11 rounded-full bg-[#1db954] text-black flex items-center justify-center shadow-xl shadow-black/60 opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-200 hover:scale-105">
          <Play className="w-5 h-5 fill-black ml-0.5" />
        </div>
      </div>
      <div className="flex flex-col gap-1 min-w-0">
        <h4 className="text-sm font-bold text-white truncate group-hover:text-[#1db954] transition-colors">
          {album.title}
        </h4>
        <div className="flex items-center gap-1.5 text-xs text-[#a7a7a7] truncate">
          <span>{album.artist}</span>
          {album.releaseYear && <span aria-hidden="true">·</span>}
          {album.releaseYear && <span>{album.releaseYear}</span>}
        </div>
      </div>
    </div>
  );
};
