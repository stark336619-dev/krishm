import React from 'react';
import { X, Play, Trash2, ListMusic } from 'lucide-react';
import { usePlayer } from '../../context/PlayerContext';
import { formatDuration, getFallbackCoverArt } from '../../utils/format';

export const QueueDrawer: React.FC = () => {
  const {
    queue,
    queueIndex,
    currentSong,
    isQueueOpen,
    setIsQueueOpen,
    playSong,
    removeFromQueue,
    clearQueue,
  } = usePlayer();

  if (!isQueueOpen) return null;

  const nowPlaying = currentSong;
  const upNext = queue.slice(queueIndex + 1);

  return (
    <div className="fixed right-4 bottom-24 w-80 sm:w-96 max-h-[520px] bg-[#181818] border border-white/10 rounded-2xl shadow-2xl flex flex-col z-50 overflow-hidden backdrop-blur-xl">
      {/* Header */}
      <div className="p-4 border-b border-white/5 flex items-center justify-between bg-[#202020]">
        <div className="flex items-center gap-2">
          <ListMusic className="w-4 h-4 text-[#1db954]" />
          <h3 className="text-sm font-bold text-white">Play Queue</h3>
          <span className="text-xs text-[#a7a7a7]">({queue.length} tracks)</span>
        </div>
        <div className="flex items-center gap-2">
          {queue.length > 1 && (
            <button
              onClick={clearQueue}
              className="text-[11px] text-[#a7a7a7] hover:text-red-400 flex items-center gap-1 transition-colors"
              title="Clear up next queue"
            >
              <Trash2 className="w-3.5 h-3.5" />
              <span>Clear</span>
            </button>
          )}
          <button
            onClick={() => setIsQueueOpen(false)}
            className="p-1 rounded-full text-[#a7a7a7] hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-4 custom-scroll">
        {/* Now Playing */}
        {nowPlaying && (
          <div>
            <span className="text-[11px] font-semibold text-[#a7a7a7] uppercase tracking-wider px-2 block mb-2">
              Now Playing
            </span>
            <div className="flex items-center gap-3 p-2 rounded-lg bg-[#242424] border border-white/5">
              <img
                src={nowPlaying.coverUrl || getFallbackCoverArt(nowPlaying.title)}
                alt={nowPlaying.title}
                className="w-11 h-11 rounded-md object-cover shrink-0"
              />
              <div className="flex-1 min-w-0">
                <p className="text-xs font-semibold text-[#1db954] truncate">
                  {nowPlaying.title}
                </p>
                <p className="text-[11px] text-[#a7a7a7] truncate">
                  {nowPlaying.artist}
                </p>
              </div>
              <span className="text-xs text-[#a7a7a7] tabular-nums font-mono">
                {formatDuration(nowPlaying.duration)}
              </span>
            </div>
          </div>
        )}

        {/* Up Next */}
        <div>
          <span className="text-[11px] font-semibold text-[#a7a7a7] uppercase tracking-wider px-2 block mb-2">
            Up Next
          </span>
          {upNext.length === 0 ? (
            <p className="text-xs text-[#727272] px-2 py-4 italic text-center">
              No tracks left in queue.
            </p>
          ) : (
            <div className="space-y-1">
              {upNext.map((song, i) => {
                const actualIndex = queueIndex + 1 + i;
                return (
                  <div
                    key={`${song.id}-${actualIndex}`}
                    className="group flex items-center gap-3 p-2 rounded-lg hover:bg-[#222222] transition-colors"
                  >
                    <div className="relative w-9 h-9 shrink-0">
                      <img
                        src={song.coverUrl || getFallbackCoverArt(song.title)}
                        alt={song.title}
                        className="w-full h-full rounded object-cover"
                      />
                      <button
                        onClick={() => playSong(song)}
                        className="absolute inset-0 bg-black/60 rounded flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity text-white"
                      >
                        <Play className="w-3.5 h-3.5 fill-white" />
                      </button>
                    </div>

                    <div className="flex-1 min-w-0">
                      <p className="text-xs font-medium text-white truncate">
                        {song.title}
                      </p>
                      <p className="text-[11px] text-[#a7a7a7] truncate">
                        {song.artist}
                      </p>
                    </div>

                    <span className="text-xs text-[#a7a7a7] tabular-nums font-mono">
                      {formatDuration(song.duration)}
                    </span>

                    <button
                      onClick={() => removeFromQueue(actualIndex)}
                      className="opacity-0 group-hover:opacity-100 text-[#a7a7a7] hover:text-red-400 p-1 transition-all"
                      title="Remove from queue"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
