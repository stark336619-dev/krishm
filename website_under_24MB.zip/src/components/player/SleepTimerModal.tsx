import React from 'react';
import { X, Moon, Clock, Check, StopCircle } from 'lucide-react';

interface SleepTimerModalProps {
  isOpen: boolean;
  onClose: () => void;
  activeTimerMinutes: number | null;
  onSetTimer: (minutes: number | null) => void;
  isEndOfTrackTimer: boolean;
  onToggleEndOfTrack: () => void;
}

export const SleepTimerModal: React.FC<SleepTimerModalProps> = ({
  isOpen,
  onClose,
  activeTimerMinutes,
  onSetTimer,
  isEndOfTrackTimer,
  onToggleEndOfTrack,
}) => {
  if (!isOpen) return null;

  const timerOptions = [
    { label: '5 minutes', value: 5 },
    { label: '15 minutes', value: 15 },
    { label: '30 minutes', value: 30 },
    { label: '45 minutes', value: 45 },
    { label: '1 hour', value: 60 },
  ];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-sm bg-[#121212] border border-white/10 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/5 bg-[#181818]/60">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#1ed760]/10 flex items-center justify-center text-[#1ed760] border border-[#1ed760]/20">
              <Moon className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Sleep Timer</h3>
              <p className="text-xs text-[#a0a0a0]">Auto-pause audio playback</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-[#a0a0a0] hover:text-white rounded-lg hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Options */}
        <div className="p-4 space-y-2">
          {timerOptions.map(opt => {
            const isSelected = activeTimerMinutes === opt.value && !isEndOfTrackTimer;
            return (
              <button
                key={opt.value}
                onClick={() => {
                  onSetTimer(opt.value);
                  onClose();
                }}
                className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
                  isSelected
                    ? 'bg-[#1ed760]/10 border-[#1ed760] text-white shadow-sm'
                    : 'bg-[#181818] border-white/5 text-[#a0a0a0] hover:bg-[#202020]'
                }`}
              >
                <div className="flex items-center gap-3">
                  <Clock className={`w-4 h-4 ${isSelected ? 'text-[#1ed760]' : 'text-[#808080]'}`} />
                  <span className="text-sm font-semibold text-white">{opt.label}</span>
                </div>
                {isSelected && <Check className="w-4 h-4 text-[#1ed760]" />}
              </button>
            );
          })}

          {/* End of Track Option */}
          <button
            onClick={() => {
              onToggleEndOfTrack();
              onClose();
            }}
            className={`w-full p-3 rounded-xl border text-left flex items-center justify-between transition-all ${
              isEndOfTrackTimer
                ? 'bg-[#1ed760]/10 border-[#1ed760] text-white shadow-sm'
                : 'bg-[#181818] border-white/5 text-[#a0a0a0] hover:bg-[#202020]'
            }`}
          >
            <div className="flex items-center gap-3">
              <StopCircle className={`w-4 h-4 ${isEndOfTrackTimer ? 'text-[#1ed760]' : 'text-[#808080]'}`} />
              <span className="text-sm font-semibold text-white">End of this song</span>
            </div>
            {isEndOfTrackTimer && <Check className="w-4 h-4 text-[#1ed760]" />}
          </button>

          {/* Turn off timer if active */}
          {(activeTimerMinutes !== null || isEndOfTrackTimer) && (
            <button
              onClick={() => {
                onSetTimer(null);
                if (isEndOfTrackTimer) onToggleEndOfTrack();
                onClose();
              }}
              className="w-full mt-2 p-2.5 rounded-xl border border-red-500/20 text-red-400 bg-red-500/10 hover:bg-red-500/20 text-xs font-semibold text-center transition-colors"
            >
              Turn off timer
            </button>
          )}
        </div>
      </div>
    </div>
  );
};
