import React, { useEffect, useState, useRef } from 'react';
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Shuffle,
  Repeat,
  Repeat1,
  Volume2,
  Volume1,
  VolumeX,
  ListMusic,
  Heart,
  AlertCircle,
  Loader2,
  Maximize2,
  ChevronDown,
  Mic2,
  Sliders,
  Moon,
  Download,
  Sparkles,
} from 'lucide-react';
import { usePlayer } from '../../context/PlayerContext';
import { useAuth } from '../../context/AuthContext';
import { formatDuration, getFallbackCoverArt } from '../../utils/format';
import { musicRepository } from '../../services/musicRepository';
import { LyricsModal } from './LyricsModal';
import { EqualizerModal } from './EqualizerModal';
import { SleepTimerModal } from './SleepTimerModal';

export const PersistentPlayer: React.FC = () => {
  const {
    currentSong,
    isPlaying,
    isLoading,
    currentTime,
    duration,
    volume,
    isMuted,
    isShuffle,
    repeatMode,
    isQueueOpen,
    audioError,
    togglePlay,
    pause,
    playNext,
    playPrevious,
    seek,
    setVolume,
    toggleMute,
    toggleShuffle,
    toggleRepeat,
    setIsQueueOpen,
    clearAudioError,
  } = usePlayer();

  const { userProfile } = useAuth();
  const [isLiked, setIsLiked] = useState(false);
  const [isMobileExpanded, setIsMobileExpanded] = useState(false);
  const [isSeeking, setIsSeeking] = useState(false);
  const [seekValue, setSeekValue] = useState(0);

  // New STERNITERS Modals & Features
  const [isLyricsOpen, setIsLyricsOpen] = useState(false);
  const [isEqualizerOpen, setIsEqualizerOpen] = useState(false);
  const [isSleepTimerOpen, setIsSleepTimerOpen] = useState(false);
  const [sleepTimerMinutes, setSleepTimerMinutes] = useState<number | null>(null);
  const [sleepTimerRemainingSec, setSleepTimerRemainingSec] = useState<number | null>(null);
  const [isEndOfTrackTimer, setIsEndOfTrackTimer] = useState(false);

  // Sleep timer interval countdown
  useEffect(() => {
    if (sleepTimerMinutes === null) {
      setSleepTimerRemainingSec(null);
      return;
    }

    setSleepTimerRemainingSec(sleepTimerMinutes * 60);
    const interval = setInterval(() => {
      setSleepTimerRemainingSec(prev => {
        if (prev === null || prev <= 1) {
          clearInterval(interval);
          setSleepTimerMinutes(null);
          pause();
          return null;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [sleepTimerMinutes, pause]);

  // End of track timer trigger
  useEffect(() => {
    if (!isEndOfTrackTimer || !isPlaying || duration === 0) return;
    if (currentTime >= duration - 0.75) {
      pause();
      setIsEndOfTrackTimer(false);
    }
  }, [isEndOfTrackTimer, currentTime, duration, isPlaying, pause]);

  const handleDownload = () => {
    if (!currentSong) return;
    const cleanId = (currentSong.providerId || currentSong.id).replace(/^saavn_/, '');
    const downloadUrl = `/api/music/download?id=${encodeURIComponent(cleanId)}&title=${encodeURIComponent(
      currentSong.title
    )}&artist=${encodeURIComponent(currentSong.artist)}`;
    
    // Trigger download
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.download = `${currentSong.title} - ${currentSong.artist}.mp3`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Sync liked state
  useEffect(() => {
    if (!currentSong || !userProfile?.uid) {
      setIsLiked(false);
      return;
    }
    const checkLiked = async () => {
      const likes = await musicRepository.getUserLikes(userProfile.uid);
      setIsLiked(likes.includes(currentSong.id));
    };
    checkLiked();
  }, [currentSong?.id, userProfile?.uid]);

  const handleLikeToggle = async () => {
    if (!currentSong || !userProfile?.uid) return;
    const newState = await musicRepository.toggleLike(userProfile.uid, currentSong.id);
    setIsLiked(newState);
  };

  const handleSeekChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = Number(e.target.value);
    setSeekValue(val);
    setIsSeeking(true);
  };

  const handleSeekCommit = () => {
    seek(seekValue);
    setIsSeeking(false);
  };

  const displayedTime = isSeeking ? seekValue : currentTime;
  const progressPercent = duration > 0 ? (displayedTime / duration) * 100 : 0;
  const volumePercent = volume * 100;

  if (!currentSong) {
    return null; // Clean zero-state when no song has been selected yet
  }

  return (
    <>
      {/* Audio Error Toast */}
      {audioError && (
        <div className="fixed bottom-24 left-1/2 -translate-x-1/2 bg-[#282828] text-white px-4 py-2.5 rounded-lg shadow-2xl border border-red-500/30 flex items-center gap-3 z-50 animate-bounce">
          <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
          <span className="text-xs">{audioError}</span>
          <button
            onClick={clearAudioError}
            className="text-xs text-[#1db954] hover:underline font-semibold"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* Mobile Mini-Player (shown on small screens) */}
      <div className="md:hidden fixed bottom-14 left-2 right-2 bg-[#202020] rounded-xl p-2.5 z-40 border border-white/10 shadow-2xl flex items-center justify-between">
        <div
          onClick={() => setIsMobileExpanded(true)}
          className="flex items-center gap-3 flex-1 min-w-0 cursor-pointer"
        >
          <img
            src={currentSong.coverUrl || getFallbackCoverArt(currentSong.title)}
            alt={currentSong.title}
            className="w-10 h-10 rounded-lg object-cover shrink-0"
          />
          <div className="min-w-0 flex-1">
            <p className="text-xs font-semibold text-white truncate">
              {currentSong.title}
            </p>
            <p className="text-[11px] text-[#a7a7a7] truncate">
              {currentSong.artist}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          {userProfile && (
            <button
              onClick={handleLikeToggle}
              className="p-2 text-[#a7a7a7] hover:text-[#1db954]"
            >
              <Heart
                className={`w-4 h-4 ${
                  isLiked ? 'text-[#1db954] fill-[#1db954]' : ''
                }`}
              />
            </button>
          )}

          <button
            onClick={togglePlay}
            disabled={isLoading}
            className="w-9 h-9 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-transform"
          >
            {isLoading ? (
              <Loader2 className="w-4 h-4 animate-spin" />
            ) : isPlaying ? (
              <Pause className="w-4 h-4 fill-black" />
            ) : (
              <Play className="w-4 h-4 fill-black ml-0.5" />
            )}
          </button>
        </div>

        {/* Mini progress bar on top */}
        <div className="absolute -top-1 left-3 right-3 h-1 bg-white/10 rounded-full overflow-hidden">
          <div
            className="h-full bg-[#1db954]"
            style={{ width: `${progressPercent}%` }}
          />
        </div>
      </div>

      {/* Mobile Full Expanded Player Modal */}
      {isMobileExpanded && (
        <div className="md:hidden fixed inset-0 bg-gradient-to-b from-[#282828] to-[#121212] z-50 p-6 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <button
              onClick={() => setIsMobileExpanded(false)}
              className="p-2 text-white/80 hover:text-white"
            >
              <ChevronDown className="w-6 h-6" />
            </button>
            <span className="text-xs font-semibold text-[#a7a7a7] uppercase tracking-wider">
              Playing from Sonora
            </span>
            <button
              onClick={() => setIsQueueOpen(!isQueueOpen)}
              className="p-2 text-white/80 hover:text-white"
            >
              <ListMusic className="w-5 h-5" />
            </button>
          </div>

          <div className="my-auto text-center px-4">
            <img
              src={currentSong.coverUrl || getFallbackCoverArt(currentSong.title)}
              alt={currentSong.title}
              className="w-64 h-64 mx-auto rounded-2xl shadow-2xl object-cover mb-8"
            />
            <div className="flex items-center justify-between">
              <div className="text-left">
                <h2 className="text-xl font-bold text-white truncate">
                  {currentSong.title}
                </h2>
                <p className="text-sm text-[#a7a7a7]">{currentSong.artist}</p>
              </div>
              {userProfile && (
                <button
                  onClick={handleLikeToggle}
                  className="p-2 text-[#a7a7a7] hover:text-[#1db954]"
                >
                  <Heart
                    className={`w-6 h-6 ${
                      isLiked ? 'text-[#1db954] fill-[#1db954]' : ''
                    }`}
                  />
                </button>
              )}
            </div>
          </div>

          <div className="space-y-6 pb-6">
            {/* Seek Scrubber */}
            <div className="space-y-1">
              <input
                type="range"
                min="0"
                max={duration || 100}
                value={displayedTime}
                onChange={handleSeekChange}
                onMouseUp={handleSeekCommit}
                onTouchEnd={handleSeekCommit}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-[#a7a7a7] tabular-nums font-mono">
                <span>{formatDuration(displayedTime)}</span>
                <span>{formatDuration(duration)}</span>
              </div>
            </div>

            {/* Controls */}
            <div className="flex items-center justify-between">
              <button
                onClick={toggleShuffle}
                className={`p-2 ${
                  isShuffle ? 'text-[#1db954]' : 'text-[#a7a7a7]'
                }`}
              >
                <Shuffle className="w-5 h-5" />
              </button>
              <button
                onClick={playPrevious}
                className="p-2 text-white hover:text-white/80"
              >
                <SkipBack className="w-7 h-7 fill-white" />
              </button>
              <button
                onClick={togglePlay}
                disabled={isLoading}
                className="w-16 h-16 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-transform"
              >
                {isLoading ? (
                  <Loader2 className="w-7 h-7 animate-spin" />
                ) : isPlaying ? (
                  <Pause className="w-7 h-7 fill-black" />
                ) : (
                  <Play className="w-7 h-7 fill-black ml-1" />
                )}
              </button>
              <button
                onClick={playNext}
                className="p-2 text-white hover:text-white/80"
              >
                <SkipForward className="w-7 h-7 fill-white" />
              </button>
              <button
                onClick={toggleRepeat}
                className={`p-2 ${
                  repeatMode !== 'off' ? 'text-[#1db954]' : 'text-[#a7a7a7]'
                }`}
              >
                {repeatMode === 'one' ? (
                  <Repeat1 className="w-5 h-5" />
                ) : (
                  <Repeat className="w-5 h-5" />
                )}
              </button>
            </div>

            {/* Mobile Feature Toolbar: Lyrics, EQ, Sleep Timer, Download */}
            <div className="flex items-center justify-around pt-2 border-t border-white/10 text-xs">
              <button
                onClick={() => setIsLyricsOpen(true)}
                className={`flex flex-col items-center gap-1 ${
                  isLyricsOpen ? 'text-[#1ed760]' : 'text-[#a7a7a7] hover:text-white'
                }`}
              >
                <Mic2 className="w-5 h-5" />
                <span className="text-[10px]">Lyrics</span>
              </button>

              <button
                onClick={() => setIsEqualizerOpen(true)}
                className={`flex flex-col items-center gap-1 ${
                  isEqualizerOpen ? 'text-[#1ed760]' : 'text-[#a7a7a7] hover:text-white'
                }`}
              >
                <Sliders className="w-5 h-5" />
                <span className="text-[10px]">Equalizer</span>
              </button>

              <button
                onClick={() => setIsSleepTimerOpen(true)}
                className={`flex flex-col items-center gap-1 ${
                  sleepTimerMinutes !== null || isEndOfTrackTimer
                    ? 'text-[#1ed760]'
                    : 'text-[#a7a7a7] hover:text-white'
                }`}
              >
                <Moon className="w-5 h-5" />
                <span className="text-[10px]">
                  {sleepTimerMinutes ? `${sleepTimerMinutes}m` : isEndOfTrackTimer ? 'End Track' : 'Timer'}
                </span>
              </button>

              <button
                onClick={handleDownload}
                className="flex flex-col items-center gap-1 text-[#a7a7a7] hover:text-[#1ed760]"
              >
                <Download className="w-5 h-5" />
                <span className="text-[10px]">Download</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Desktop Persistent Bottom Player */}
      <footer className="hidden md:flex fixed bottom-0 left-0 right-0 h-20 bg-[#121212]/95 backdrop-blur-xl border-t border-white/10 px-4 items-center justify-between z-40 select-none">
        {/* Left Section: Track Info & Artwork */}
        <div className="flex items-center gap-3.5 w-1/4 min-w-[220px]">
          <div className="relative group w-14 h-14 rounded-lg overflow-hidden shrink-0 shadow-md">
            <img
              src={currentSong.coverUrl || getFallbackCoverArt(currentSong.title)}
              alt={currentSong.title}
              className="w-full h-full object-cover"
            />
          </div>
          <div className="flex flex-col min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-semibold text-white truncate hover:underline cursor-pointer">
                {currentSong.title}
              </span>
              {currentSong.provider === 'sterniters' && (
                <span className="text-[9px] bg-[#1ed760]/15 text-[#1ed760] font-semibold px-1.5 py-0.2 rounded border border-[#1ed760]/30 shrink-0">
                  320k
                </span>
              )}
            </div>
            <span className="text-[11px] text-[#a7a7a7] truncate hover:text-white hover:underline cursor-pointer">
              {currentSong.artist}
            </span>
          </div>
          {userProfile && (
            <button
              onClick={handleLikeToggle}
              title={isLiked ? 'Remove from Liked' : 'Save to Liked'}
              className="p-1.5 text-[#a7a7a7] hover:text-white transition-colors"
            >
              <Heart
                className={`w-4 h-4 ${
                  isLiked ? 'text-[#1ed760] fill-[#1ed760]' : ''
                }`}
              />
            </button>
          )}
        </div>

        {/* Center Section: Controls & Scrubber */}
        <div className="flex flex-col items-center gap-1.5 max-w-xl w-2/4">
          <div className="flex items-center gap-5">
            <button
              onClick={toggleShuffle}
              title={isShuffle ? 'Disable Shuffle' : 'Enable Shuffle'}
              className={`p-1 transition-colors relative ${
                isShuffle ? 'text-[#1ed760]' : 'text-[#a7a7a7] hover:text-white'
              }`}
            >
              <Shuffle className="w-4 h-4" />
              {isShuffle && (
                <span className="w-1 h-1 bg-[#1ed760] rounded-full absolute -bottom-1 left-1/2 -translate-x-1/2" />
              )}
            </button>

            <button
              onClick={playPrevious}
              title="Previous Track (Shift+P)"
              className="p-1 text-[#b3b3b3] hover:text-white transition-colors"
            >
              <SkipBack className="w-4 h-4 fill-[#b3b3b3]" />
            </button>

            <button
              onClick={togglePlay}
              disabled={isLoading}
              title={isPlaying ? 'Pause (Space)' : 'Play (Space)'}
              className="w-8 h-8 rounded-full bg-white text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-all shadow-md"
            >
              {isLoading ? (
                <Loader2 className="w-4 h-4 animate-spin text-black" />
              ) : isPlaying ? (
                <Pause className="w-4 h-4 fill-black" />
              ) : (
                <Play className="w-4 h-4 fill-black ml-0.5" />
              )}
            </button>

            <button
              onClick={playNext}
              title="Next Track (Shift+N)"
              className="p-1 text-[#b3b3b3] hover:text-white transition-colors"
            >
              <SkipForward className="w-4 h-4 fill-[#b3b3b3]" />
            </button>

            <button
              onClick={toggleRepeat}
              title={`Repeat: ${repeatMode}`}
              className={`p-1 transition-colors relative ${
                repeatMode !== 'off'
                  ? 'text-[#1ed760]'
                  : 'text-[#a7a7a7] hover:text-white'
              }`}
            >
              {repeatMode === 'one' ? (
                <Repeat1 className="w-4 h-4" />
              ) : (
                <Repeat className="w-4 h-4" />
              )}
              {repeatMode !== 'off' && (
                <span className="w-1 h-1 bg-[#1ed760] rounded-full absolute -bottom-1 left-1/2 -translate-x-1/2" />
              )}
            </button>
          </div>

          {/* Time Scrubber */}
          <div className="w-full flex items-center gap-2 group">
            <span className="text-[11px] text-[#a7a7a7] tabular-nums font-mono w-9 text-right">
              {formatDuration(displayedTime)}
            </span>
            <div className="relative flex-1 flex items-center h-4">
              <input
                type="range"
                min="0"
                max={duration || 100}
                value={displayedTime}
                onChange={handleSeekChange}
                onMouseUp={handleSeekCommit}
                className="w-full z-10"
              />
              {/* Custom colored fill behind input */}
              <div
                className="absolute top-1/2 -translate-y-1/2 left-0 h-1 bg-[#1ed760] rounded-full pointer-events-none group-hover:bg-[#1ed760]"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
            <span className="text-[11px] text-[#a7a7a7] tabular-nums font-mono w-9">
              {formatDuration(duration)}
            </span>
          </div>
        </div>

        {/* Right Section: Features, Volume & Queue */}
        <div className="flex items-center justify-end gap-2 w-1/4 min-w-[280px]">
          {/* Lyrics Button */}
          <button
            onClick={() => setIsLyricsOpen(!isLyricsOpen)}
            title="Lyrics (STERNITERS)"
            className={`p-1.5 rounded-full transition-colors ${
              isLyricsOpen ? 'text-[#1ed760]' : 'text-[#a7a7a7] hover:text-white'
            }`}
          >
            <Mic2 className="w-4 h-4" />
          </button>

          {/* Equalizer Button */}
          <button
            onClick={() => setIsEqualizerOpen(true)}
            title="Equalizer & Audio Presets"
            className={`p-1.5 rounded-full transition-colors ${
              isEqualizerOpen ? 'text-[#1ed760]' : 'text-[#a7a7a7] hover:text-white'
            }`}
          >
            <Sliders className="w-4 h-4" />
          </button>

          {/* Sleep Timer Button */}
          <button
            onClick={() => setIsSleepTimerOpen(true)}
            title={
              sleepTimerRemainingSec !== null
                ? `Sleep Timer: ${Math.ceil(sleepTimerRemainingSec / 60)}m left`
                : isEndOfTrackTimer
                ? 'Sleep Timer: End of Track'
                : 'Sleep Timer'
            }
            className={`p-1.5 rounded-full transition-colors relative ${
              sleepTimerMinutes !== null || isEndOfTrackTimer
                ? 'text-[#1ed760]'
                : 'text-[#a7a7a7] hover:text-white'
            }`}
          >
            <Moon className="w-4 h-4" />
            {(sleepTimerMinutes !== null || isEndOfTrackTimer) && (
              <span className="w-1.5 h-1.5 bg-[#1ed760] rounded-full absolute top-0.5 right-0.5 animate-pulse" />
            )}
          </button>

          {/* Download Button */}
          <button
            onClick={handleDownload}
            title="Download MP3"
            className="p-1.5 rounded-full text-[#a7a7a7] hover:text-[#1ed760] transition-colors"
          >
            <Download className="w-4 h-4" />
          </button>

          {/* Queue Button */}
          <button
            onClick={() => setIsQueueOpen(!isQueueOpen)}
            title="Play Queue"
            className={`p-1.5 rounded-full transition-colors ${
              isQueueOpen ? 'text-[#1ed760]' : 'text-[#a7a7a7] hover:text-white'
            }`}
          >
            <ListMusic className="w-4 h-4" />
          </button>

          {/* Volume Control */}
          <div className="flex items-center gap-1.5 group w-24">
            <button
              onClick={toggleMute}
              title={isMuted ? 'Unmute (M)' : 'Mute (M)'}
              className="text-[#a7a7a7] hover:text-white transition-colors"
            >
              {isMuted || volume === 0 ? (
                <VolumeX className="w-4 h-4 text-red-400" />
              ) : volume < 0.5 ? (
                <Volume1 className="w-4 h-4" />
              ) : (
                <Volume2 className="w-4 h-4" />
              )}
            </button>
            <div className="relative flex-1 flex items-center h-4">
              <input
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={isMuted ? 0 : volume}
                onChange={e => setVolume(Number(e.target.value))}
                className="w-full z-10"
              />
              <div
                className="absolute top-1/2 -translate-y-1/2 left-0 h-1 bg-[#1ed760] rounded-full pointer-events-none group-hover:bg-[#1ed760]"
                style={{ width: `${isMuted ? 0 : volumePercent}%` }}
              />
            </div>
          </div>
        </div>
      </footer>

      {/* Feature Modals */}
      <LyricsModal
        song={currentSong}
        isOpen={isLyricsOpen}
        onClose={() => setIsLyricsOpen(false)}
        currentTime={currentTime}
      />

      <EqualizerModal
        isOpen={isEqualizerOpen}
        onClose={() => setIsEqualizerOpen(false)}
        isPlaying={isPlaying}
      />

      <SleepTimerModal
        isOpen={isSleepTimerOpen}
        onClose={() => setIsSleepTimerOpen(false)}
        activeTimerMinutes={sleepTimerMinutes}
        onSetTimer={setSleepTimerMinutes}
        isEndOfTrackTimer={isEndOfTrackTimer}
        onToggleEndOfTrack={() => setIsEndOfTrackTimer(!isEndOfTrackTimer)}
      />
    </>
  );
};
