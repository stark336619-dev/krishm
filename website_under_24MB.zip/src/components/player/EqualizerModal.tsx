import React, { useState } from 'react';
import { X, Sliders, Volume2, Sparkles, Check } from 'lucide-react';

interface EqualizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  isPlaying?: boolean;
}

export type EqPreset = 'flat' | 'bass_boost' | 'vocal' | 'treble' | 'lofi' | 'party';

export const EqualizerModal: React.FC<EqualizerModalProps> = ({
  isOpen,
  onClose,
  isPlaying = false,
}) => {
  const [activePreset, setActivePreset] = useState<EqPreset>('flat');
  const [bands, setBands] = useState<Record<string, number>>({
    '60Hz': 0,
    '250Hz': 0,
    '1kHz': 0,
    '4kHz': 0,
    '16kHz': 0,
  });
  const [streamQuality, setStreamQuality] = useState<'320' | '160' | 'auto'>('320');

  if (!isOpen) return null;

  const presets: Record<EqPreset, { name: string; desc: string; values: Record<string, number> }> = {
    flat: {
      name: 'Flat / Studio Reference',
      desc: 'Balanced, untouched audio reproduction as mastered.',
      values: { '60Hz': 0, '250Hz': 0, '1kHz': 0, '4kHz': 0, '16kHz': 0 },
    },
    bass_boost: {
      name: 'Deep Bass Boost',
      desc: 'Enhanced punch and low-frequency resonance for EDM and hip-hop.',
      values: { '60Hz': 6, '250Hz': 4, '1kHz': 0, '4kHz': -1, '16kHz': -2 },
    },
    vocal: {
      name: 'Vocal Clarity & Ghazal',
      desc: 'Crisp, articulate mid-range frequencies highlighting singer vocals.',
      values: { '60Hz': -2, '250Hz': 0, '1kHz': 4, '4kHz': 3, '16kHz': 1 },
    },
    treble: {
      name: 'Bright Treble Boost',
      desc: 'Extended sparkle and airy high frequencies for acoustic tracks.',
      values: { '60Hz': -1, '250Hz': -1, '1kHz': 1, '4kHz': 4, '16kHz': 6 },
    },
    lofi: {
      name: 'Lo-Fi Chill & Warmth',
      desc: 'Soft analog tape saturation tone with rolled-off harsh highs.',
      values: { '60Hz': 3, '250Hz': 3, '1kHz': 1, '4kHz': -2, '16kHz': -5 },
    },
    party: {
      name: 'Club & Party Vibe',
      desc: 'Dynamic loudness curve with elevated bass and shimmering highs.',
      values: { '60Hz': 5, '250Hz': 2, '1kHz': -1, '4kHz': 3, '16kHz': 5 },
    },
  };

  const handleSelectPreset = (presetKey: EqPreset) => {
    setActivePreset(presetKey);
    setBands(presets[presetKey].values);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-lg bg-[#121212] border border-white/10 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/5 bg-[#181818]/60">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-[#1ed760]/10 flex items-center justify-center text-[#1ed760] border border-[#1ed760]/20">
              <Sliders className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white">Audio Equalizer & Quality</h3>
              <p className="text-xs text-[#a0a0a0]">STERNITERS DSP Audio Processor</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-[#a0a0a0] hover:text-white rounded-lg hover:bg-white/5 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 space-y-6 overflow-y-auto max-h-[75vh]">
          {/* Quality Mode */}
          <div>
            <label className="text-xs font-semibold text-[#a0a0a0] uppercase tracking-wider block mb-2">
              Streaming Bitrate Quality
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: '320', label: '320kbps CD Quality', sub: 'Lossless HQ' },
                { id: '160', label: '160kbps Standard', sub: 'Balanced' },
                { id: 'auto', label: 'Auto Adaptive', sub: 'Data Saver' },
              ].map(q => (
                <button
                  key={q.id}
                  onClick={() => setStreamQuality(q.id as any)}
                  className={`p-2.5 rounded-xl border text-left transition-all ${
                    streamQuality === q.id
                      ? 'bg-[#1ed760]/10 border-[#1ed760] text-white shadow-[0_0_15px_rgba(30,215,96,0.15)]'
                      : 'bg-[#181818] border-white/5 text-[#a0a0a0] hover:border-white/10'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-white">{q.label}</span>
                    {streamQuality === q.id && <Check className="w-3.5 h-3.5 text-[#1ed760]" />}
                  </div>
                  <span className="text-[10px] text-[#808080]">{q.sub}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Equalizer Frequency Graphic */}
          <div className="bg-[#181818] p-4 rounded-xl border border-white/5 space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-semibold text-white">5-Band Equalizer</span>
              <span className="text-[10px] text-[#1ed760] font-mono">
                {presets[activePreset].name}
              </span>
            </div>

            {/* Bars Visualization */}
            <div className="flex items-end justify-between h-28 pt-2 pb-2 px-4 border-b border-white/5">
              {Object.entries(bands).map(([hz, db]) => {
                const heightPercent = Math.min(100, Math.max(10, ((db + 10) / 20) * 100));
                return (
                  <div key={hz} className="flex flex-col items-center gap-2 h-full justify-end">
                    <span className="text-[10px] font-mono text-[#a0a0a0]">
                      {db > 0 ? `+${db}` : db}dB
                    </span>
                    <div className="w-8 bg-[#252525] rounded-t-md relative overflow-hidden h-20 flex items-end">
                      <div
                        className="w-full bg-gradient-to-t from-[#1ed760]/50 to-[#1ed760] rounded-t-md transition-all duration-300"
                        style={{ height: `${heightPercent}%` }}
                      />
                    </div>
                    <span className="text-[10px] text-[#808080] font-medium">{hz}</span>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Presets List */}
          <div>
            <label className="text-xs font-semibold text-[#a0a0a0] uppercase tracking-wider block mb-2">
              Audio Presets
            </label>
            <div className="grid grid-cols-2 gap-2">
              {(Object.keys(presets) as EqPreset[]).map(key => {
                const p = presets[key];
                const isActive = activePreset === key;
                return (
                  <button
                    key={key}
                    onClick={() => handleSelectPreset(key)}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      isActive
                        ? 'bg-[#1ed760]/10 border-[#1ed760] text-white shadow-sm'
                        : 'bg-[#181818] border-white/5 text-[#a0a0a0] hover:bg-[#202020]'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs font-bold text-white">{p.name}</span>
                      {isActive && <Check className="w-3.5 h-3.5 text-[#1ed760]" />}
                    </div>
                    <p className="text-[10px] text-[#808080] line-clamp-2 leading-relaxed">
                      {p.desc}
                    </p>
                  </button>
                );
              })}
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3 border-t border-white/5 bg-[#181818]/60 flex items-center justify-between">
          <span className="text-[11px] text-[#808080]">
            Changes apply in real-time to active playback.
          </span>
          <button
            onClick={onClose}
            className="px-4 py-1.5 text-xs font-semibold bg-[#1ed760] text-black rounded-full hover:scale-105 active:scale-95 transition-all shadow-md"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
