import React, { useEffect, useState } from 'react';
import { X, Mic2, Copy, Check, Music2, Loader2, Sparkles } from 'lucide-react';
import { Song } from '../../types/music';
import { unifiedMusicService } from '../../services/unifiedMusicService';

interface LyricsModalProps {
  song: Song | null;
  isOpen: boolean;
  onClose: () => void;
  currentTime?: number;
}

export const LyricsModal: React.FC<LyricsModalProps> = ({
  song,
  isOpen,
  onClose,
  currentTime = 0,
}) => {
  const [lyricsData, setLyricsData] = useState<{
    lyrics: string | null;
    lines: string[];
    snippet?: string;
  } | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    if (!isOpen || !song) return;

    let isMounted = true;
    setIsLoading(true);

    const songId = song.providerId || song.id;
    unifiedMusicService
      .getLyrics(songId)
      .then(res => {
        if (!isMounted) return;
        setLyricsData(res);
        setIsLoading(false);
      })
      .catch(() => {
        if (!isMounted) return;
        setLyricsData(null);
        setIsLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [isOpen, song?.id, song?.providerId]);

  if (!isOpen || !song) return null;

  const handleCopy = () => {
    if (!lyricsData?.lyrics) return;
    navigator.clipboard.writeText(lyricsData.lyrics);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fadeIn">
      <div className="relative w-full max-w-2xl max-h-[85vh] bg-[#121212] border border-white/10 rounded-2xl shadow-2xl flex flex-col overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-white/5 bg-[#181818]/60">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg overflow-hidden shrink-0 shadow-md">
              <img
                src={song.coverUrl || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=100&auto=format&fit=crop&q=80'}
                alt={song.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="text-sm font-bold text-white line-clamp-1">{song.title}</h3>
                <span className="text-[10px] bg-[#1ed760]/10 text-[#1ed760] font-semibold px-2 py-0.5 rounded-full border border-[#1ed760]/20">
                  Lyrics
                </span>
              </div>
              <p className="text-xs text-[#a0a0a0] line-clamp-1">{song.artist}</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {lyricsData?.lyrics && (
              <button
                onClick={handleCopy}
                className="p-2 text-[#a0a0a0] hover:text-white rounded-lg hover:bg-white/5 transition-colors flex items-center gap-1.5 text-xs"
                title="Copy lyrics"
              >
                {copied ? (
                  <>
                    <Check className="w-4 h-4 text-[#1ed760]" />
                    <span className="text-[#1ed760]">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-4 h-4" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            )}
            <button
              onClick={onClose}
              className="p-2 text-[#a0a0a0] hover:text-white rounded-lg hover:bg-white/5 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto px-6 py-8 space-y-4 custom-scrollbar">
          {isLoading ? (
            <div className="flex flex-col items-center justify-center py-20 text-[#a0a0a0] space-y-3">
              <Loader2 className="w-8 h-8 text-[#1ed760] animate-spin" />
              <p className="text-sm">Fetching lyrics from STERNITERS...</p>
            </div>
          ) : lyricsData?.lines && lyricsData.lines.length > 0 ? (
            <div className="space-y-4 text-center max-w-lg mx-auto">
              {lyricsData.lines.map((line, idx) => (
                <p
                  key={idx}
                  className="text-lg md:text-xl font-semibold text-white/90 hover:text-[#1ed760] transition-colors leading-relaxed cursor-default selection:bg-[#1ed760]/30"
                >
                  {line}
                </p>
              ))}
              <div className="pt-6 text-xs text-[#6a6a6a]">
                Powered by STERNITERS Music Lyrics Engine
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center py-20 text-[#a0a0a0] space-y-3">
              <Music2 className="w-12 h-12 text-[#404040]" />
              <h4 className="text-base font-semibold text-white">Lyrics Not Available</h4>
              <p className="text-xs text-[#a0a0a0] max-w-xs text-center">
                We couldn't locate synchronized lyrics for this song in the catalog. Enjoy the full audio stream!
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
