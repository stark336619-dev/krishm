import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';

export interface SpotifyUserProfile {
  id: string;
  displayName: string;
  email?: string;
  imageUrl?: string;
  profileUrl?: string;
}

interface SpotifyContextType {
  isConnected: boolean;
  isLoading: boolean;
  spotifyUser: SpotifyUserProfile | null;
  accessToken: string | null;
  error: string | null;
  connectSpotify: () => Promise<void>;
  disconnectSpotify: () => void;
  getValidAccessToken: () => Promise<string | null>;
}

const SpotifyContext = createContext<SpotifyContextType | undefined>(undefined);

const STORAGE_KEYS = {
  ACCESS_TOKEN: 'sonora_spotify_user_access_token',
  REFRESH_TOKEN: 'sonora_spotify_user_refresh_token',
  EXPIRES_AT: 'sonora_spotify_user_expires_at',
  USER_PROFILE: 'sonora_spotify_user_profile',
};

export const SpotifyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [accessToken, setAccessToken] = useState<string | null>(() => {
    return localStorage.getItem(STORAGE_KEYS.ACCESS_TOKEN);
  });
  const [spotifyUser, setSpotifyUser] = useState<SpotifyUserProfile | null>(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEYS.USER_PROFILE);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  });
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const isConnected = Boolean(accessToken && spotifyUser);

  // Store tokens in state and localStorage
  const saveAuthSession = useCallback(
    (token: string, refreshToken: string, expiresIn: number, profile?: SpotifyUserProfile | null) => {
      const expiresAt = Date.now() + (expiresIn - 60) * 1000;
      setAccessToken(token);
      localStorage.setItem(STORAGE_KEYS.ACCESS_TOKEN, token);
      localStorage.setItem(STORAGE_KEYS.EXPIRES_AT, String(expiresAt));

      if (refreshToken) {
        localStorage.setItem(STORAGE_KEYS.REFRESH_TOKEN, refreshToken);
      }

      if (profile) {
        setSpotifyUser(profile);
        localStorage.setItem(STORAGE_KEYS.USER_PROFILE, JSON.stringify(profile));
      }
      setError(null);
    },
    []
  );

  // Disconnect & wipe Spotify credentials
  const disconnectSpotify = useCallback(() => {
    setAccessToken(null);
    setSpotifyUser(null);
    setError(null);
    localStorage.removeItem(STORAGE_KEYS.ACCESS_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.REFRESH_TOKEN);
    localStorage.removeItem(STORAGE_KEYS.EXPIRES_AT);
    localStorage.removeItem(STORAGE_KEYS.USER_PROFILE);
  }, []);

  // Refresh access token via server proxy
  const refreshAccessToken = useCallback(async (): Promise<string | null> => {
    const refreshToken = localStorage.getItem(STORAGE_KEYS.REFRESH_TOKEN);
    if (!refreshToken) {
      disconnectSpotify();
      return null;
    }

    try {
      const res = await fetch('/api/spotify/refresh', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ refresh_token: refreshToken }),
      });

      if (!res.ok) {
        disconnectSpotify();
        return null;
      }

      const data = await res.json();
      if (data.access_token) {
        saveAuthSession(data.access_token, data.refresh_token || refreshToken, data.expires_in);
        return data.access_token;
      }
      return null;
    } catch (err) {
      console.warn('Failed to refresh Spotify access token:', err);
      return null;
    }
  }, [disconnectSpotify, saveAuthSession]);

  // Retrieve valid access token, refreshing if necessary
  const getValidAccessToken = useCallback(async (): Promise<string | null> => {
    const token = localStorage.getItem(STORAGE_KEYS.ACCESS_TOKEN);
    const expiresAtStr = localStorage.getItem(STORAGE_KEYS.EXPIRES_AT);
    const expiresAt = expiresAtStr ? parseInt(expiresAtStr, 10) : 0;

    if (!token) return null;

    // If token is valid for at least 30 more seconds, return it
    if (Date.now() < expiresAt - 30000) {
      return token;
    }

    // Otherwise refresh token
    return await refreshAccessToken();
  }, [refreshAccessToken]);

  // Initiate Popup-Based OAuth Flow
  const connectSpotify = useCallback(async () => {
    setIsLoading(true);
    setError(null);

    try {
      // 1. Fetch OAuth URL directly from server (passing client origin for dynamic redirect matching)
      const currentOrigin = window.location.origin;
      const res = await fetch(`/api/spotify/auth-url?origin=${encodeURIComponent(currentOrigin)}`);
      if (!res.ok) {
        const errorData = await res.json().catch(() => ({}));
        throw new Error(errorData.error || errorData.help || 'Spotify OAuth service is unconfigured.');
      }

      const { url } = await res.json();
      if (!url) {
        throw new Error('Server returned empty Spotify authorization URL.');
      }

      // 2. Open Spotify authorize URL directly in popup (required in iframe context)
      const popup = window.open(
        url,
        'sonora_spotify_auth',
        'width=600,height=720,menubar=no,toolbar=no,location=yes,status=no'
      );

      if (!popup) {
        setError('Popup was blocked by your browser. Please allow popups for this site and retry.');
        setIsLoading(false);
      }
    } catch (err: any) {
      setError(err?.message || 'Failed to start Spotify authentication.');
      setIsLoading(false);
    }
  }, []);

  // Listen for popup callback message
  useEffect(() => {
    const handleMessage = (event: MessageEvent) => {
      // Validate origin: preview domain (.run.app), firebaseapp.com, web.app, or localhost
      const origin = event.origin;
      const isAllowedOrigin =
        origin.endsWith('.run.app') ||
        origin.endsWith('.firebaseapp.com') ||
        origin.endsWith('.web.app') ||
        origin.includes('localhost') ||
        origin === window.location.origin;

      if (!isAllowedOrigin) {
        return;
      }

      const data = event.data;
      if (!data || typeof data !== 'object') return;

      if (data.type === 'SPOTIFY_AUTH_SUCCESS') {
        saveAuthSession(
          data.accessToken,
          data.refreshToken,
          data.expiresIn,
          data.spotifyUser
        );
        setIsLoading(false);
      } else if (data.type === 'SPOTIFY_AUTH_ERROR') {
        setError(`Spotify authorization: ${data.error || 'Connection cancelled.'}`);
        setIsLoading(false);
      }
    };

    window.addEventListener('message', handleMessage);
    return () => window.removeEventListener('message', handleMessage);
  }, [saveAuthSession]);

  return (
    <SpotifyContext.Provider
      value={{
        isConnected,
        isLoading,
        spotifyUser,
        accessToken,
        error,
        connectSpotify,
        disconnectSpotify,
        getValidAccessToken,
      }}
    >
      {children}
    </SpotifyContext.Provider>
  );
};

export const useSpotify = () => {
  const context = useContext(SpotifyContext);
  if (!context) {
    throw new Error('useSpotify must be used within a SpotifyProvider');
  }
  return context;
};
