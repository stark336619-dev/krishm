import React, { createContext, useContext, useEffect, useRef, useState } from 'react';
import { Song, PlaybackRepeatMode } from '../types/music';
import { musicRepository } from '../services/musicRepository';
import { useAuth } from './AuthContext';

interface PlayerContextType {
  currentSong: Song | null;
  isPlaying: boolean;
  isLoading: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isShuffle: boolean;
  repeatMode: PlaybackRepeatMode;
  queue: Song[];
  queueIndex: number;
  isQueueOpen: boolean;
  audioError: string | null;
  playSong: (song: Song, contextQueue?: Song[]) => void;
  togglePlay: () => void;
  pause: () => void;
  resume: () => void;
  seek: (seconds: number) => void;
  setVolume: (vol: number) => void;
  toggleMute: () => void;
  playNext: () => void;
  playPrevious: () => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  addToQueue: (song: Song) => void;
  removeFromQueue: (index: number) => void;
  clearQueue: () => void;
  setIsQueueOpen: (open: boolean) => void;
  clearAudioError: () => void;
}

const PlayerContext = createContext<PlayerContextType | undefined>(undefined);

const VERIFIED_FALLBACK_STREAMS = [
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
  'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
];

export const PlayerProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { userProfile } = useAuth();
  const audioRef = useRef<HTMLAudioElement | null>(null);

  const [currentSong, setCurrentSong] = useState<Song | null>(() => {
    try {
      const saved = localStorage.getItem('sonora_last_song');
      return saved ? JSON.parse(saved) : null;
    } catch {
      return null;
    }
  });

  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [volume, setVolumeState] = useState(() => {
    try {
      const saved = localStorage.getItem('sonora_volume');
      return saved !== null ? Number(saved) : 0.8;
    } catch {
      return 0.8;
    }
  });
  const [prevVolume, setPrevVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [isShuffle, setIsShuffle] = useState(false);
  const [repeatMode, setRepeatMode] = useState<PlaybackRepeatMode>('off');
  const [queue, setQueue] = useState<Song[]>(() => {
    try {
      const saved = localStorage.getItem('sonora_queue');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });
  const [queueIndex, setQueueIndex] = useState(0);
  const [isQueueOpen, setIsQueueOpen] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);

  // References for values needed inside long-lived event listeners
  const currentSongRef = useRef<Song | null>(currentSong);
  const userProfileRef = useRef(userProfile);
  const repeatModeRef = useRef(repeatMode);
  const isShuffleRef = useRef(isShuffle);
  const queueRef = useRef(queue);
  const queueIndexRef = useRef(queueIndex);
  const playLoggedRef = useRef<string | null>(null);

  // Keep refs synchronized
  useEffect(() => {
    currentSongRef.current = currentSong;
  }, [currentSong]);

  useEffect(() => {
    userProfileRef.current = userProfile;
  }, [userProfile]);

  useEffect(() => {
    repeatModeRef.current = repeatMode;
  }, [repeatMode]);

  useEffect(() => {
    isShuffleRef.current = isShuffle;
  }, [isShuffle]);

  useEffect(() => {
    queueRef.current = queue;
  }, [queue]);

  useEffect(() => {
    queueIndexRef.current = queueIndex;
  }, [queueIndex]);

  // Handle Track End (called when song finishes)
  const handleTrackEnded = () => {
    const rMode = repeatModeRef.current;
    if (rMode === 'one' && audioRef.current) {
      audioRef.current.currentTime = 0;
      audioRef.current.play().then(() => setIsPlaying(true)).catch(() => {});
      return;
    }

    const q = queueRef.current;
    const qIndex = queueIndexRef.current;
    const isShuff = isShuffleRef.current;

    if (q.length === 0) {
      setIsPlaying(false);
      return;
    }

    if (isShuff) {
      const nextIdx = Math.floor(Math.random() * q.length);
      setQueueIndex(nextIdx);
      playSong(q[nextIdx]);
      return;
    }

    const nextIndex = qIndex + 1;
    if (nextIndex < q.length) {
      setQueueIndex(nextIndex);
      playSong(q[nextIndex]);
    } else if (rMode === 'all') {
      setQueueIndex(0);
      playSong(q[0]);
    } else {
      setIsPlaying(false);
    }
  };

  // One-time initialization of persistent Audio instance
  useEffect(() => {
    const audio = new Audio();
    audio.preload = 'auto';
    audio.volume = volume;
    audioRef.current = audio;

    const onTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
      const song = currentSongRef.current;
      const uProfile = userProfileRef.current;
      if (
        song &&
        audio.currentTime > 15 &&
        playLoggedRef.current !== song.id
      ) {
        playLoggedRef.current = song.id;
        musicRepository.incrementPlayCount(song.id);
        if (uProfile?.uid) {
          musicRepository.recordListeningHistory(uProfile.uid, song);
        }
      }
    };

    const onLoadedMetadata = () => {
      setDuration(audio.duration || 0);
      setIsLoading(false);
    };

    const onCanPlay = () => {
      setIsLoading(false);
    };

    const onWaiting = () => {
      setIsLoading(true);
    };

    const onPlay = () => {
      setIsPlaying(true);
      setIsLoading(false);
      setAudioError(null);
    };

    const onPause = () => {
      setIsPlaying(false);
    };

    const onEnded = () => {
      handleTrackEnded();
    };

    const onError = () => {
      setIsLoading(false);
      setIsPlaying(false);
      const song = currentSongRef.current;
      if (song && audio.src) {
        console.warn('Audio element error encountered for URL:', audio.src);
        // Automatic fallback: try alternative stable streaming audio if primary URL is blocked
        if (!audio.src.includes('SoundHelix')) {
          const fallback = VERIFIED_FALLBACK_STREAMS[0];
          console.log('Switching to verified audio stream fallback:', fallback);
          audio.src = fallback;
          audio.play().catch(err => {
            if (err?.name !== 'AbortError') {
              setAudioError('Click Play to start music.');
            }
          });
        } else {
          setAudioError('Audio streaming is currently unavailable. Click to retry.');
        }
      }
    };

    audio.addEventListener('timeupdate', onTimeUpdate);
    audio.addEventListener('loadedmetadata', onLoadedMetadata);
    audio.addEventListener('canplay', onCanPlay);
    audio.addEventListener('waiting', onWaiting);
    audio.addEventListener('play', onPlay);
    audio.addEventListener('pause', onPause);
    audio.addEventListener('ended', onEnded);
    audio.addEventListener('error', onError);

    return () => {
      audio.pause();
      audio.removeEventListener('timeupdate', onTimeUpdate);
      audio.removeEventListener('loadedmetadata', onLoadedMetadata);
      audio.removeEventListener('canplay', onCanPlay);
      audio.removeEventListener('waiting', onWaiting);
      audio.removeEventListener('play', onPlay);
      audio.removeEventListener('pause', onPause);
      audio.removeEventListener('ended', onEnded);
      audio.removeEventListener('error', onError);
    };
  }, []); // Run once on mount!

  // Synchronize audio volume
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
    localStorage.setItem('sonora_volume', String(volume));
  }, [volume, isMuted]);

  // Save current song & queue to localStorage
  useEffect(() => {
    if (currentSong) {
      localStorage.setItem('sonora_last_song', JSON.stringify(currentSong));
    }
  }, [currentSong]);

  useEffect(() => {
    localStorage.setItem('sonora_queue', JSON.stringify(queue));
  }, [queue]);

  const playSong = (song: Song, contextQueue?: Song[]) => {
    setAudioError(null);
    setCurrentSong(song);
    currentSongRef.current = song;
    playLoggedRef.current = null;

    let targetQueue = queue;
    if (contextQueue && contextQueue.length > 0) {
      targetQueue = contextQueue;
      setQueue(contextQueue);
      const idx = contextQueue.findIndex(s => s.id === song.id);
      setQueueIndex(idx !== -1 ? idx : 0);
    } else if (!queue.some(s => s.id === song.id)) {
      targetQueue = [song, ...queue];
      setQueue(targetQueue);
      setQueueIndex(0);
    } else {
      const idx = queue.findIndex(s => s.id === song.id);
      setQueueIndex(idx !== -1 ? idx : 0);
    }

    if (audioRef.current) {
      setIsLoading(true);
      const sourceUrl = song.audioUrl || VERIFIED_FALLBACK_STREAMS[0];
      if (audioRef.current.src !== sourceUrl) {
        audioRef.current.src = sourceUrl;
      }
      audioRef.current.currentTime = 0;

      const playPromise = audioRef.current.play();
      if (playPromise !== undefined) {
        playPromise
          .then(() => {
            setIsPlaying(true);
            setIsLoading(false);
          })
          .catch(err => {
            if (err?.name === 'AbortError') return;
            console.warn('Browser play notice:', err);
            setIsLoading(false);
            setAudioError('Click Play button below to start audio.');
          });
      }
    }
  };

  const togglePlay = () => {
    if (!currentSong) {
      if (queue.length > 0) {
        playSong(queue[0]);
      }
      return;
    }
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      if (!audioRef.current.src && currentSong) {
        audioRef.current.src = currentSong.audioUrl;
      }
      audioRef.current
        .play()
        .then(() => {
          setIsPlaying(true);
          setAudioError(null);
        })
        .catch(err => {
          console.warn('Play error:', err);
          setAudioError('Could not start playback. Click to retry.');
        });
    }
  };

  const pause = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      setIsPlaying(false);
    }
  };

  const resume = () => {
    if (audioRef.current) {
      audioRef.current
        .play()
        .then(() => setIsPlaying(true))
        .catch(() => {});
    }
  };

  const seek = (seconds: number) => {
    if (audioRef.current) {
      audioRef.current.currentTime = seconds;
      setCurrentTime(seconds);
    }
  };

  const setVolume = (vol: number) => {
    const clamped = Math.max(0, Math.min(1, vol));
    setVolumeState(clamped);
    if (clamped > 0 && isMuted) {
      setIsMuted(false);
    }
  };

  const toggleMute = () => {
    if (isMuted) {
      setIsMuted(false);
      setVolumeState(prevVolume || 0.5);
    } else {
      setPrevVolume(volume);
      setIsMuted(true);
    }
  };

  const playNext = () => {
    if (queue.length === 0) return;

    if (isShuffle) {
      const randomIndex = Math.floor(Math.random() * queue.length);
      setQueueIndex(randomIndex);
      playSong(queue[randomIndex]);
      return;
    }

    const nextIndex = queueIndex + 1;
    if (nextIndex < queue.length) {
      setQueueIndex(nextIndex);
      playSong(queue[nextIndex]);
    } else if (repeatMode === 'all') {
      setQueueIndex(0);
      playSong(queue[0]);
    } else {
      setIsPlaying(false);
      if (audioRef.current) audioRef.current.currentTime = 0;
    }
  };

  const playPrevious = () => {
    if (!audioRef.current) return;
    if (audioRef.current.currentTime > 3) {
      audioRef.current.currentTime = 0;
      setCurrentTime(0);
      return;
    }

    if (queue.length === 0) return;
    const prevIndex = queueIndex - 1;
    if (prevIndex >= 0) {
      setQueueIndex(prevIndex);
      playSong(queue[prevIndex]);
    } else if (repeatMode === 'all') {
      const lastIndex = queue.length - 1;
      setQueueIndex(lastIndex);
      playSong(queue[lastIndex]);
    }
  };

  const toggleShuffle = () => {
    setIsShuffle(prev => !prev);
  };

  const toggleRepeat = () => {
    setRepeatMode(prev => {
      if (prev === 'off') return 'all';
      if (prev === 'all') return 'one';
      return 'off';
    });
  };

  const addToQueue = (song: Song) => {
    setQueue(prev => [...prev, song]);
  };

  const removeFromQueue = (index: number) => {
    setQueue(prev => prev.filter((_, i) => i !== index));
    if (index === queueIndex) {
      playNext();
    } else if (index < queueIndex) {
      setQueueIndex(prev => prev - 1);
    }
  };

  const clearQueue = () => {
    setQueue(currentSong ? [currentSong] : []);
    setQueueIndex(0);
  };

  const clearAudioError = () => {
    setAudioError(null);
  };

  // Keyboard shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      if (target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable) {
        return;
      }

      switch (e.code) {
        case 'Space':
          e.preventDefault();
          togglePlay();
          break;
        case 'KeyM':
          e.preventDefault();
          toggleMute();
          break;
        case 'ArrowLeft':
          e.preventDefault();
          seek(Math.max(0, currentTime - 5));
          break;
        case 'ArrowRight':
          e.preventDefault();
          seek(Math.min(duration, currentTime + 5));
          break;
        case 'KeyN':
          if (e.shiftKey) {
            e.preventDefault();
            playNext();
          }
          break;
        case 'KeyP':
          if (e.shiftKey) {
            e.preventDefault();
            playPrevious();
          }
          break;
        default:
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPlaying, currentTime, duration, isMuted, volume]);

  return (
    <PlayerContext.Provider
      value={{
        currentSong,
        isPlaying,
        isLoading,
        currentTime,
        duration,
        volume: isMuted ? 0 : volume,
        isMuted,
        isShuffle,
        repeatMode,
        queue,
        queueIndex,
        isQueueOpen,
        audioError,
        playSong,
        togglePlay,
        pause,
        resume,
        seek,
        setVolume,
        toggleMute,
        playNext,
        playPrevious,
        toggleShuffle,
        toggleRepeat,
        addToQueue,
        removeFromQueue,
        clearQueue,
        setIsQueueOpen,
        clearAudioError,
      }}
    >
      {children}
    </PlayerContext.Provider>
  );
};

export const usePlayer = () => {
  const context = useContext(PlayerContext);
  if (!context) {
    throw new Error('usePlayer must be used within a PlayerProvider');
  }
  return context;
};
