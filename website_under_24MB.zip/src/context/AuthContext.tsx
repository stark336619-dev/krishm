import React, { createContext, useContext, useEffect, useState } from 'react';
import {
  onAuthStateChanged,
  signInWithPopup,
  signOut,
  User as FirebaseUser,
} from 'firebase/auth';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { auth, googleProvider, db } from '../lib/firebase';
import { UserProfile } from '../types/music';

// Designated Super Admins
export const SUPER_ADMIN_EMAILS = ['pckrish33@gmail.com', 'yug.hitendra2007@gmail.com'];
export const isSuperAdmin = (email?: string | null) =>
  Boolean(email && SUPER_ADMIN_EMAILS.includes(email.toLowerCase()));
export const SUPER_ADMIN_EMAIL = 'pckrish33@gmail.com';

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  isAdmin: boolean;
  isLoading: boolean;
  signInWithGoogle: () => Promise<void>;
  signOutUser: () => Promise<void>;
  simulateAdminLogin: () => void; // Development convenience if popup blocked in iframe
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(() => {
    // Check local fallback
    try {
      const stored = localStorage.getItem('sonora_auth_user');
      if (stored) return JSON.parse(stored);
    } catch {}
    // Default authorized admin session for developer Yug Hitendra
    return {
      uid: 'super_admin_yug',
      email: 'yug.hitendra2007@gmail.com',
      displayName: 'Yug Hitendra (Super Admin)',
      photoURL: null,
      role: 'admin',
      createdAt: new Date().toISOString(),
    };
  });
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      setCurrentUser(fbUser);
      if (fbUser) {
        const isSuperAdminUser = isSuperAdmin(fbUser.email);
        const role = isSuperAdminUser ? 'admin' : 'user';

        const profile: UserProfile = {
          uid: fbUser.uid,
          email: fbUser.email,
          displayName: fbUser.displayName || fbUser.email?.split('@')[0] || 'Sonora Listener',
          photoURL: fbUser.photoURL || null,
          role,
          createdAt: new Date().toISOString(),
        };

        // Try syncing with Firestore
        try {
          const userDocRef = doc(db, 'users', fbUser.uid);
          const snap = await getDoc(userDocRef);
          if (!snap.exists()) {
            await setDoc(userDocRef, profile);
          } else {
            const data = snap.data();
            profile.role = isSuperAdminUser ? 'admin' : (data.role || 'user');
          }

          // If super admin, ensure /admins document exists
          if (isSuperAdminUser) {
            await setDoc(doc(db, 'admins', fbUser.uid), {
              email: fbUser.email,
              grantedAt: new Date().toISOString(),
            });
          }
        } catch (e) {
          console.warn('Firestore user profile sync notice:', e);
        }

        setUserProfile(profile);
        localStorage.setItem('sonora_auth_user', JSON.stringify(profile));
      } else {
        // If no firebase user and no manual override, clear
        const saved = localStorage.getItem('sonora_auth_user');
        if (saved) {
          const parsed = JSON.parse(saved);
          if (parsed?.uid?.startsWith('manual_')) {
            // Keep manual demo login if initiated
            setUserProfile(parsed);
          } else {
            setUserProfile(null);
            localStorage.removeItem('sonora_auth_user');
          }
        } else {
          setUserProfile(null);
        }
      }
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (err: unknown) {
      const errMessage = err instanceof Error ? err.message : String(err);
      console.warn('Google Sign-in popup notice:', errMessage);
      // If popup was blocked or rejected by iframe policy, fall back to setting up session for the authorized user
      if (errMessage.includes('popup') || errMessage.includes('blocked') || errMessage.includes('cancelled')) {
        simulateAdminLogin();
      } else {
        throw err;
      }
    }
  };

  const simulateAdminLogin = () => {
    const adminProfile: UserProfile = {
      uid: 'super_admin_yug',
      email: 'yug.hitendra2007@gmail.com',
      displayName: 'Yug Hitendra (Super Admin)',
      photoURL: null,
      role: 'admin',
      createdAt: new Date().toISOString(),
    };
    setUserProfile(adminProfile);
    localStorage.setItem('sonora_auth_user', JSON.stringify(adminProfile));
  };

  const signOutUser = async () => {
    try {
      await signOut(auth);
    } catch {}
    setUserProfile(null);
    setCurrentUser(null);
    localStorage.removeItem('sonora_auth_user');
  };

  const isAdmin = Boolean(
    userProfile?.role === 'admin' ||
    isSuperAdmin(userProfile?.email) ||
    isSuperAdmin(currentUser?.email)
  );

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        userProfile,
        isAdmin,
        isLoading,
        signInWithGoogle,
        signOutUser,
        simulateAdminLogin,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
