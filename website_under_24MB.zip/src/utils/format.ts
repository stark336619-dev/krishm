export function formatDuration(seconds: number): string {
  if (isNaN(seconds) || seconds < 0) return '0:00';
  const mins = Math.floor(seconds / 60);
  const secs = Math.floor(seconds % 60);
  return `${mins}:${secs < 10 ? '0' : ''}${secs}`;
}

export function formatNumber(num: number): string {
  return new Intl.NumberFormat('en-US').format(num);
}

export function formatTimeAgo(dateString: string): string {
  try {
    const date = new Date(dateString);
    const now = new Date();
    const diffSec = Math.floor((now.getTime() - date.getTime()) / 1000);

    if (diffSec < 60) return 'Just now';
    if (diffSec < 3600) return `${Math.floor(diffSec / 60)} min ago`;
    if (diffSec < 86400) return `${Math.floor(diffSec / 3600)}h ago`;
    if (diffSec < 2592000) return `${Math.floor(diffSec / 86400)}d ago`;
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  } catch {
    return 'Recently';
  }
}

// Generates an inline SVG data-uri gradient artwork with geometric vinyl accents
export function getFallbackCoverArt(title: string, category: 'song' | 'album' | 'playlist' | 'artist' = 'song'): string {
  // Simple hash for deterministic color palettes
  let hash = 0;
  for (let i = 0; i < title.length; i++) {
    hash = title.charCodeAt(i) + ((hash << 5) - hash);
  }

  const palettes = [
    { start: '#1db954', mid: '#0d5926', end: '#071f0f' },
    { start: '#2e77d0', mid: '#153f75', end: '#0a192f' },
    { start: '#8e2de2', mid: '#4a00e0', end: '#14032d' },
    { start: '#f12711', mid: '#f5af19', end: '#3a1103' },
    { start: '#11998e', mid: '#38ef7d', end: '#042e18' },
    { start: '#654ea3', mid: '#eaafc8', end: '#241438' },
  ];

  const palette = palettes[Math.abs(hash) % palettes.length];
  const char = title.trim().charAt(0).toUpperCase() || 'S';

  const svg = `
  <svg xmlns="http://www.w3.org/2000/svg" width="300" height="300" viewBox="0 0 300 300">
    <defs>
      <radialGradient id="g" cx="70%" cy="30%" r="90%">
        <stop offset="0%" stop-color="${palette.start}" />
        <stop offset="50%" stop-color="${palette.mid}" />
        <stop offset="100%" stop-color="${palette.end}" />
      </radialGradient>
      <linearGradient id="shine" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.15" />
        <stop offset="100%" stop-color="#000000" stop-opacity="0.5" />
      </linearGradient>
    </defs>
    <rect width="300" height="300" fill="url(#g)" />
    <circle cx="150" cy="150" r="100" stroke="#ffffff" stroke-opacity="0.08" stroke-width="2" fill="none" />
    <circle cx="150" cy="150" r="60" stroke="#ffffff" stroke-opacity="0.1" stroke-width="1.5" fill="none" />
    <circle cx="150" cy="150" r="24" fill="#000000" fill-opacity="0.3" />
    <rect width="300" height="300" fill="url(#shine)" />
    <text x="150" y="165" font-family="'Plus Jakarta Sans', sans-serif" font-weight="700" font-size="44" fill="#ffffff" text-anchor="middle" opacity="0.85">${char}</text>
  </svg>
  `.trim();

  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}
