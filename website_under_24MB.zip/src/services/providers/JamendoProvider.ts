import { ProviderTrack, ProviderStatus } from '../../types/providers';

const JAMENDO_PUBLIC_CLIENT_ID = 'c3c9e6bb'; // Default Jamendo public client ID

export class JamendoProvider {
  id = 'jamendo' as const;
  name = 'Jamendo Music (Creative Commons)';
  private clientId: string;

  constructor() {
    this.clientId =
      localStorage.getItem('sonora_jamendo_client_id') ||
      JAMENDO_PUBLIC_CLIENT_ID;
  }

  setClientId(id: string) {
    this.clientId = id.trim();
    if (this.clientId) {
      localStorage.setItem('sonora_jamendo_client_id', this.clientId);
    } else {
      localStorage.removeItem('sonora_jamendo_client_id');
      this.clientId = JAMENDO_PUBLIC_CLIENT_ID;
    }
  }

  getClientId(): string {
    return this.clientId;
  }

  isConfigured(): boolean {
    return Boolean(this.clientId);
  }

  getStatus(): ProviderStatus {
    return {
      id: 'jamendo',
      name: 'Jamendo Music',
      isConfigured: this.isConfigured(),
      health: this.isConfigured() ? 'healthy' : 'unconfigured',
      lastChecked: new Date().toISOString(),
      requiresCredentials: false,
      attributionText: 'Music powered by Jamendo. Licensed under Creative Commons.',
      attributionUrl: 'https://www.jamendo.com',
      setupInstructions:
        'Jamendo provides free, legal Creative Commons music streaming. You can obtain a custom Client ID for higher rate limits at https://developer.jamendo.com.',
    };
  }

  async search(query: string, limit = 20): Promise<ProviderTrack[]> {
    if (!this.isConfigured() || !query.trim()) return [];

    try {
      const url = `https://api.jamendo.com/v3.0/tracks/?client_id=${this.clientId}&format=json&limit=${limit}&namesearch=${encodeURIComponent(
        query
      )}&include=licenses&audioformat=mp32`;

      const res = await fetch(url);
      if (!res.ok) {
        console.warn('Jamendo API returned status:', res.status);
        return [];
      }

      const data = await res.json();
      if (!data.results || !Array.isArray(data.results)) return [];

      return data.results.map((item: any) => this.mapTrack(item));
    } catch (err) {
      console.warn('Jamendo search failed:', err);
      return [];
    }
  }

  async getTrending(limit = 20): Promise<ProviderTrack[]> {
    try {
      const url = `https://api.jamendo.com/v3.0/tracks/?client_id=${this.clientId}&format=json&limit=${limit}&order=popularity_week_desc&include=licenses&audioformat=mp32`;

      const res = await fetch(url);
      if (!res.ok) return [];

      const data = await res.json();
      if (!data.results) return [];

      return data.results.map((item: any) => this.mapTrack(item));
    } catch (err) {
      console.warn('Jamendo trending fetch failed:', err);
      return [];
    }
  }

  async getByTag(tag: string, limit = 20): Promise<ProviderTrack[]> {
    try {
      const url = `https://api.jamendo.com/v3.0/tracks/?client_id=${this.clientId}&format=json&limit=${limit}&tags=${encodeURIComponent(
        tag
      )}&order=popularity_total_desc&include=licenses&audioformat=mp32`;

      const res = await fetch(url);
      if (!res.ok) return [];

      const data = await res.json();
      if (!data.results) return [];

      return data.results.map((item: any) => this.mapTrack(item));
    } catch {
      return [];
    }
  }

  private mapTrack(item: any): ProviderTrack {
    return {
      id: `jamendo_${item.id}`,
      title: item.name,
      artist: item.artist_name,
      artistId: item.artist_id,
      album: item.album_name,
      albumId: item.album_id,
      coverUrl: item.album_image || item.image || '',
      audioUrl: item.audio, // Authorized Creative Commons streaming URL
      duration: Number(item.duration) || 180,
      provider: 'jamendo',
      providerId: String(item.id),
      externalUrl: item.shareurl || `https://www.jamendo.com/track/${item.id}`,
      hasFullPlayback: true,
      license: item.license_ccurl ? 'Creative Commons' : 'Jamendo Free License',
      releaseDate: item.releasedate,
      playCount: 0,
    };
  }
}

export const jamendoProvider = new JamendoProvider();
