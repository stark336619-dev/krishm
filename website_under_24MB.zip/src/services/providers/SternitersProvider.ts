import { ProviderTrack, ProviderStatus } from '../../types/providers';

export interface HomeFeedData {
  trending: ProviderTrack[];
  gujarati: ProviderTrack[];
  punjabi: ProviderTrack[];
  romance: ProviderTrack[];
  lofi: ProviderTrack[];
  classics: ProviderTrack[];
  artists: Array<{ id: string; name: string; query: string; image: string }>;
}

export class SternitersMusicProvider {
  id = 'sterniters' as const;
  name = 'STERNITERS 320kbps Lossless Music Engine';

  isConfigured(): boolean {
    return true;
  }

  getStatus(): ProviderStatus {
    return {
      id: 'sterniters',
      name: 'STERNITERS Lossless Music Engine (JioSaavn + Regional)',
      isConfigured: true,
      health: 'healthy',
      lastChecked: new Date().toISOString(),
      requiresCredentials: false,
      attributionText: 'Full high-fidelity 320kbps CD audio streams, synced lyrics & metadata powered by STERNITERS v61 Engine.',
      attributionUrl: 'https://www.jiosaavn.com',
      setupInstructions:
        'Ready out of the box with zero user configuration required. Automatically delivers full song playback (not 30-sec previews) for Gujarati, Hindi, Punjabi, Bollywood, English, Tamil, and Telugu songs.',
    };
  }

  private mapSongToTrack(s: any): ProviderTrack {
    return {
      id: s.id || `saavn_${s.rawId || s.providerId}`,
      title: s.title,
      artist: s.artist,
      album: s.album || 'Single',
      coverUrl: s.coverUrl || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&auto=format&fit=crop&q=80',
      audioUrl: s.audioUrl || `/api/music/stream-proxy?id=${s.rawId || s.id}`,
      duration: s.duration || 180,
      provider: 'sterniters',
      providerId: s.rawId || s.id,
      externalUrl: `https://www.jiosaavn.com/song/${encodeURIComponent(s.title)}/${s.rawId || s.id}`,
      hasFullPlayback: true,
      license: 'Full 320kbps Lossless Playback (STERNITERS Engine)',
      language: s.language || 'Hindi',
      genre: s.genre || 'Music',
      releaseDate: s.releaseDate,
      playCount: s.playCount || 1000,
    };
  }

  async search(query: string, options?: { language?: string; limit?: number }): Promise<ProviderTrack[]> {
    if (!query.trim()) return [];
    const limit = options?.limit || 20;

    let finalQuery = query.trim();
    if (options?.language && options.language !== 'All' && !finalQuery.toLowerCase().includes(options.language.toLowerCase())) {
      finalQuery = `${options.language} ${finalQuery}`;
    }

    try {
      const res = await fetch(`/api/music/search?q=${encodeURIComponent(finalQuery)}&n=${limit}`);
      if (!res.ok) return [];

      const data = await res.json();
      if (!data.results || !Array.isArray(data.results)) return [];

      return data.results.map((item: any) => this.mapSongToTrack(item));
    } catch (err) {
      console.warn('Sterniters search error:', err);
      return [];
    }
  }

  async getTrendingByLanguage(language = 'Hindi', limit = 20): Promise<ProviderTrack[]> {
    try {
      const res = await fetch(`/api/music/trending?lang=${encodeURIComponent(language.toLowerCase())}&limit=${limit}`);
      if (!res.ok) return [];

      const data = await res.json();
      if (!data.results || !Array.isArray(data.results)) return [];

      return data.results.map((item: any) => this.mapSongToTrack(item));
    } catch (err) {
      console.warn('Sterniters trending error:', err);
      return [];
    }
  }

  async getHomeFeed(): Promise<HomeFeedData | null> {
    try {
      const res = await fetch('/api/music/home-feed');
      if (!res.ok) return null;

      const data = await res.json();
      return {
        trending: (data.trending || []).map((s: any) => this.mapSongToTrack(s)),
        gujarati: (data.gujarati || []).map((s: any) => this.mapSongToTrack(s)),
        punjabi: (data.punjabi || []).map((s: any) => this.mapSongToTrack(s)),
        romance: (data.romance || []).map((s: any) => this.mapSongToTrack(s)),
        lofi: (data.lofi || []).map((s: any) => this.mapSongToTrack(s)),
        classics: (data.classics || []).map((s: any) => this.mapSongToTrack(s)),
        artists: data.artists || [],
      };
    } catch (err) {
      console.warn('Failed to fetch home feed:', err);
      return null;
    }
  }

  async getLyrics(songId: string): Promise<{ lyrics: string | null; lines: string[]; snippet?: string } | null> {
    try {
      const res = await fetch(`/api/music/lyrics?id=${encodeURIComponent(songId)}`);
      if (!res.ok) return null;
      const data = await res.json();
      return {
        lyrics: data.lyrics || null,
        lines: data.lines || [],
        snippet: data.snippet,
      };
    } catch {
      return null;
    }
  }

  getDownloadUrl(songId: string, title: string, artist: string): string {
    const cleanId = songId.replace(/^saavn_/, '');
    return `/api/music/download?id=${encodeURIComponent(cleanId)}&title=${encodeURIComponent(title)}&artist=${encodeURIComponent(artist)}`;
  }
}

export const sternitersProvider = new SternitersMusicProvider();
