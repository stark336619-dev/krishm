import { ProviderTrack, ProviderStatus } from '../../types/providers';

export class SpotifyProvider {
  id = 'spotify' as const;
  name = 'Spotify Web API';
  private clientId: string | null = null;
  private clientSecret: string | null = null;
  private accessToken: string | null = null;
  private tokenExpiresAt = 0;

  constructor() {
    this.clientId = localStorage.getItem('sonora_spotify_client_id') || null;
    this.clientSecret = localStorage.getItem('sonora_spotify_client_secret') || null;
  }

  setCredentials(clientId: string, clientSecret?: string) {
    this.clientId = clientId.trim() || null;
    if (this.clientId) {
      localStorage.setItem('sonora_spotify_client_id', this.clientId);
    } else {
      localStorage.removeItem('sonora_spotify_client_id');
    }

    if (clientSecret !== undefined) {
      this.clientSecret = clientSecret.trim() || null;
      if (this.clientSecret) {
        localStorage.setItem('sonora_spotify_client_secret', this.clientSecret);
      } else {
        localStorage.removeItem('sonora_spotify_client_secret');
      }
    }

    // Invalidate token
    this.accessToken = null;
    this.tokenExpiresAt = 0;
  }

  isConfigured(): boolean {
    return Boolean(this.clientId);
  }

  getStatus(): ProviderStatus {
    return {
      id: 'spotify',
      name: 'Spotify Web API',
      isConfigured: this.isConfigured(),
      health: this.isConfigured() ? 'healthy' : 'unconfigured',
      lastChecked: new Date().toISOString(),
      requiresCredentials: true,
      attributionText: 'Content provided via Spotify Web API. Spotify is a registered trademark of Spotify AB.',
      attributionUrl: 'https://open.spotify.com',
      setupInstructions:
        'To connect Spotify, visit https://developer.spotify.com/dashboard, create an application, and add your Client ID and Client Secret in Admin Settings or as SPOTIFY_CLIENT_ID / SPOTIFY_CLIENT_SECRET environment variables.',
    };
  }

  private async getAccessToken(): Promise<string | null> {
    // 1. Check if user connected their Spotify account via OAuth PKCE
    const userToken = localStorage.getItem('sonora_spotify_user_access_token');
    const userExpiresAt = Number(localStorage.getItem('sonora_spotify_user_expires_at') || '0');
    if (userToken && Date.now() < userExpiresAt) {
      return userToken;
    }

    if (this.accessToken && Date.now() < this.tokenExpiresAt) {
      return this.accessToken;
    }

    // 2. Try server proxy client credentials token
    try {
      const serverRes = await fetch('/api/spotify/token', { method: 'POST' });
      if (serverRes.ok) {
        const data = await serverRes.json();
        if (data.access_token) {
          this.accessToken = data.access_token;
          this.tokenExpiresAt = Date.now() + (data.expires_in - 60) * 1000;
          return this.accessToken;
        }
      }
    } catch {
      // Continue to fallback
    }

    if (this.clientId && this.clientSecret) {
      try {
        const body = new URLSearchParams({
          grant_type: 'client_credentials',
        });
        const creds = btoa(`${this.clientId}:${this.clientSecret}`);
        const res = await fetch('https://accounts.spotify.com/api/token', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/x-www-form-urlencoded',
            Authorization: `Basic ${creds}`,
          },
          body,
        });

        if (res.ok) {
          const data = await res.json();
          this.accessToken = data.access_token;
          this.tokenExpiresAt = Date.now() + (data.expires_in - 60) * 1000;
          return this.accessToken;
        }
      } catch (err) {
        console.warn('Spotify token fetch error:', err);
      }
    }

    return null;
  }

  async search(query: string, limit = 20): Promise<ProviderTrack[]> {
    if (!this.isConfigured()) return [];

    const token = await this.getAccessToken();
    if (!token) return [];

    try {
      const url = `https://api.spotify.com/v1/search?q=${encodeURIComponent(
        query
      )}&type=track&limit=${limit}`;

      const res = await fetch(url, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });

      if (!res.ok) {
        console.warn('Spotify search failed:', res.status);
        return [];
      }

      const data = await res.json();
      if (!data.tracks?.items) return [];

      return data.tracks.items.map((item: any) => this.mapTrack(item));
    } catch (err) {
      console.warn('Spotify search exception:', err);
      return [];
    }
  }

  async getNewReleases(limit = 20): Promise<ProviderTrack[]> {
    if (!this.isConfigured()) return [];

    const token = await this.getAccessToken();
    if (!token) return [];

    try {
      const url = `https://api.spotify.com/v1/browse/new-releases?limit=${limit}`;
      const res = await fetch(url, {
        headers: { Authorization: `Bearer ${token}` },
      });

      if (!res.ok) return [];

      const data = await res.json();
      if (!data.albums?.items) return [];

      return data.albums.items.map((album: any) => ({
        id: `spotify_album_${album.id}`,
        title: album.name,
        artist: album.artists?.map((a: any) => a.name).join(', ') || 'Unknown Artist',
        album: album.name,
        albumId: album.id,
        coverUrl: album.images?.[0]?.url || '',
        duration: 0,
        provider: 'spotify',
        providerId: album.id,
        externalUrl: album.external_urls?.spotify || 'https://open.spotify.com',
        hasFullPlayback: false,
        embedUrl: `https://open.spotify.com/embed/album/${album.id}`,
        license: 'All Rights Reserved (Spotify)',
        releaseDate: album.release_date,
      }));
    } catch {
      return [];
    }
  }

  private mapTrack(item: any): ProviderTrack {
    return {
      id: `spotify_${item.id}`,
      title: item.name,
      artist: item.artists?.map((a: any) => a.name).join(', ') || 'Unknown Artist',
      artistId: item.artists?.[0]?.id,
      album: item.album?.name,
      albumId: item.album?.id,
      coverUrl: item.album?.images?.[0]?.url || '',
      duration: Math.round((item.duration_ms || 180000) / 1000),
      provider: 'spotify',
      providerId: item.id,
      externalUrl: item.external_urls?.spotify || `https://open.spotify.com/track/${item.id}`,
      hasFullPlayback: false, // In compliance with Spotify policies: full playback opens on Spotify or uses official embed
      embedUrl: `https://open.spotify.com/embed/track/${item.id}`,
      license: 'All Rights Reserved (Play on Spotify)',
      releaseDate: item.album?.release_date,
      playCount: item.popularity || 0,
    };
  }
}

export const spotifyProvider = new SpotifyProvider();
