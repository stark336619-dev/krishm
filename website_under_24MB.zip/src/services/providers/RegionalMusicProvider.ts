import { ProviderTrack, ProviderStatus } from '../../types/providers';

export class RegionalMusicProvider {
  id = 'itunes' as const;
  name = 'Regional & Global Music (Official Streams)';

  isConfigured(): boolean {
    return true; // Public official API requiring no confidential secrets
  }

  getStatus(): ProviderStatus {
    return {
      id: 'itunes',
      name: 'Regional & Multi-Language Music Catalog',
      isConfigured: true,
      health: 'healthy',
      lastChecked: new Date().toISOString(),
      requiresCredentials: false,
      attributionText: 'Audio previews & metadata provided via Apple iTunes Search API.',
      attributionUrl: 'https://music.apple.com',
      setupInstructions:
        'Ready out of the box with zero configuration required. Supports regional Indian music (Gujarati, Hindi, Punjabi, Tamil, Telugu, Marathi, Bengali) and international catalogs.',
    };
  }

  async search(query: string, options?: { language?: string; limit?: number }): Promise<ProviderTrack[]> {
    if (!query.trim()) return [];
    const limit = options?.limit || 25;

    let finalQuery = query.trim();
    if (options?.language && options.language !== 'All') {
      finalQuery = `${options.language} ${finalQuery}`;
    }

    try {
      const url = `https://itunes.apple.com/search?term=${encodeURIComponent(
        finalQuery
      )}&entity=song&limit=${limit}`;

      const res = await fetch(url);
      if (!res.ok) return [];

      const data = await res.json();
      if (!data.results || !Array.isArray(data.results)) return [];

      return data.results.map((item: any) => this.mapTrack(item, options?.language));
    } catch (err) {
      console.warn('Regional music search error:', err);
      return [];
    }
  }

  async getTrendingByLanguage(language: string, limit = 20): Promise<ProviderTrack[]> {
    const langQueries: Record<string, string> = {
      Gujarati: 'Gujarati hits trending songs',
      Hindi: 'Bollywood Hindi trending top hits',
      Punjabi: 'Punjabi top hits songs',
      Tamil: 'Tamil top hits songs',
      Telugu: 'Telugu top hits songs',
      Marathi: 'Marathi hit songs',
      Bengali: 'Bengali top hit songs',
      English: 'Top Global Pop Hits 2025',
    };

    const term = langQueries[language] || `${language} top songs`;

    try {
      const url = `https://itunes.apple.com/search?term=${encodeURIComponent(
        term
      )}&entity=song&limit=${limit}`;

      const res = await fetch(url);
      if (!res.ok) return [];

      const data = await res.json();
      if (!data.results) return [];

      return data.results.map((item: any) => this.mapTrack(item, language));
    } catch (err) {
      console.warn(`Trending fetch failed for language ${language}:`, err);
      return [];
    }
  }

  private mapTrack(item: any, language?: string): ProviderTrack {
    // Convert 100x100 artwork to higher resolution 600x600 if supported
    const rawArtwork = item.artworkUrl100 || '';
    const highResArtwork = rawArtwork.replace('100x100bb.jpg', '600x600bb.jpg');

    return {
      id: `itunes_${item.trackId}`,
      title: item.trackName || 'Unknown Title',
      artist: item.artistName || 'Unknown Artist',
      artistId: item.artistId ? String(item.artistId) : undefined,
      album: item.collectionName || 'Single',
      albumId: item.collectionId ? String(item.collectionId) : undefined,
      coverUrl: highResArtwork || rawArtwork,
      audioUrl: item.previewUrl, // Authorized official preview stream
      duration: Math.round((item.trackTimeMillis || 180000) / 1000),
      provider: 'itunes',
      providerId: String(item.trackId),
      externalUrl: item.trackViewUrl || item.collectionViewUrl || 'https://music.apple.com',
      hasFullPlayback: Boolean(item.previewUrl),
      license: 'Official Preview Stream (Apple Music)',
      language: language || 'Regional',
      genre: item.primaryGenreName,
      releaseDate: item.releaseDate ? item.releaseDate.split('T')[0] : undefined,
      playCount: 0,
    };
  }
}

export const regionalMusicProvider = new RegionalMusicProvider();
