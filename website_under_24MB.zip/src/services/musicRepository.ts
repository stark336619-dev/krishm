import {
  collection,
  doc,
  getDocs,
  getDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  query,
  where,
  orderBy,
  limit,
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import {
  Song,
  Album,
  Artist,
  Playlist,
  ListeningHistoryItem,
  AdminAuditLog,
} from '../types/music';

const LOCAL_STORAGE_KEYS = {
  SONGS: 'sonora_songs',
  ALBUMS: 'sonora_albums',
  ARTISTS: 'sonora_artists',
  PLAYLISTS: 'sonora_playlists',
  LIKES: 'sonora_likes',
  HISTORY: 'sonora_history',
  AUDIT_LOGS: 'sonora_audit_logs',
};

// Curated royalty-free tracks with guaranteed CORS-friendly direct streaming streams
export const DEMO_SONGS_SEED: Omit<Song, 'id' | 'createdAt' | 'updatedAt' | 'playCount'>[] = [
  {
    title: 'Neon Horizon',
    artist: 'Aether Pulse',
    album: 'Synthetic Dreams',
    duration: 372,
    genre: 'Synthwave',
    language: 'Instrumental',
    releaseDate: '2025-01-15',
    isExplicit: false,
    isFeatured: true,
    isPublished: true,
    coverUrl: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    description: 'Nostalgic analog synthesizers driving through a midnight coastal expressway.',
  },
  {
    title: 'Midnight Coffee',
    artist: 'Luna Eclipse',
    album: 'Late Hours',
    duration: 423,
    genre: 'Lo-Fi Chill',
    language: 'Instrumental',
    releaseDate: '2025-02-10',
    isExplicit: false,
    isFeatured: true,
    isPublished: true,
    coverUrl: 'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
    description: 'Warm vinyl crackle, Fender Rhodes chords, and rainy coffee shop ambience.',
  },
  {
    title: 'Solar Echoes',
    artist: 'Starlight Collective',
    album: 'Cosmic Drift',
    duration: 345,
    genre: 'Electronic Ambient',
    language: 'English',
    releaseDate: '2025-03-01',
    isExplicit: false,
    isFeatured: false,
    isPublished: true,
    coverUrl: 'https://images.unsplash.com/photo-1509198397868-475647b2a1e5?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
    description: 'Ethereal vocal pads and deep pulsating basslines exploring outer planetary orbits.',
  },
  {
    title: 'Velvet Groove',
    artist: 'Marcus Sterling',
    album: 'Soul Session No. 4',
    duration: 302,
    genre: 'Neo-Soul / Funk',
    language: 'English',
    releaseDate: '2024-11-20',
    isExplicit: false,
    isFeatured: true,
    isPublished: true,
    coverUrl: 'https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
    description: 'Punchy bass riffs, crisp snares, and soulful brass stabs.',
  },
  {
    title: 'Northern Pines',
    artist: 'Aura Folk',
    album: 'Wilderness Tape',
    duration: 310,
    genre: 'Indie Acoustic',
    language: 'English',
    releaseDate: '2024-12-05',
    isExplicit: false,
    isFeatured: false,
    isPublished: true,
    coverUrl: 'https://images.unsplash.com/photo-1448375240586-882707db888b?w=600&auto=format&fit=crop&q=80',
    audioUrl: 'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
    description: 'Gentle fingerpicked steel-string acoustic guitar and morning mountain air.',
  },
];

function getLocalData<T>(key: string, defaultValue: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (!raw) return defaultValue;
    return JSON.parse(raw);
  } catch {
    return defaultValue;
  }
}

function setLocalData<T>(key: string, data: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.warn(`LocalStorage write error for ${key}:`, e);
  }
}

function fixLegacyAudioUrl(song: Song): Song {
  if (song.audioUrl && (song.audioUrl.includes('pixabay.com') || song.audioUrl.includes('download/audio'))) {
    const fallbacks = [
      'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
      'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3',
      'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3',
      'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-4.mp3',
      'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-8.mp3',
    ];
    let hash = 0;
    for (let i = 0; i < song.title.length; i++) hash += song.title.charCodeAt(i);
    return { ...song, audioUrl: fallbacks[Math.abs(hash) % fallbacks.length] };
  }
  return song;
}

export const musicRepository = {
  // ---- SONGS ----
  async getSongs(includeUnpublished = false): Promise<Song[]> {
    try {
      const colRef = collection(db, 'songs');
      let q;
      if (includeUnpublished) {
        q = query(colRef, orderBy('createdAt', 'desc'));
      } else {
        q = query(colRef, where('isPublished', '==', true), orderBy('createdAt', 'desc'));
      }
      const snapshot = await getDocs(q);
      const remoteSongs = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Song));

      // Merge and update local backup
      const localSongs = getLocalData<Song[]>(LOCAL_STORAGE_KEYS.SONGS, []);
      const mergedMap = new Map<string, Song>();
      localSongs.forEach(s => mergedMap.set(s.id, fixLegacyAudioUrl(s)));
      remoteSongs.forEach(s => mergedMap.set(s.id, fixLegacyAudioUrl(s)));
      const mergedList = Array.from(mergedMap.values());
      setLocalData(LOCAL_STORAGE_KEYS.SONGS, mergedList);

      return includeUnpublished ? mergedList : mergedList.filter(s => s.isPublished);
    } catch (err) {
      console.warn('Firestore fetch failed, serving from local cache:', err);
      const local = getLocalData<Song[]>(LOCAL_STORAGE_KEYS.SONGS, []).map(fixLegacyAudioUrl);
      return includeUnpublished ? local : local.filter(s => s.isPublished);
    }
  },

  async getSongById(id: string): Promise<Song | null> {
    try {
      const snap = await getDoc(doc(db, 'songs', id));
      if (snap.exists()) {
        return fixLegacyAudioUrl({ id: snap.id, ...snap.data() } as Song);
      }
    } catch {
      // fallback
    }
    const local = getLocalData<Song[]>(LOCAL_STORAGE_KEYS.SONGS, []).map(fixLegacyAudioUrl);
    return local.find(s => s.id === id) || null;
  },

  async createSong(data: Omit<Song, 'id' | 'createdAt' | 'updatedAt' | 'playCount'>): Promise<Song> {
    const id = 'song_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
    const now = new Date().toISOString();
    const newSong: Song = {
      ...data,
      id,
      playCount: 0,
      createdAt: now,
      updatedAt: now,
    };

    // Save to local cache first for instant responsiveness
    const local = getLocalData<Song[]>(LOCAL_STORAGE_KEYS.SONGS, []);
    local.unshift(newSong);
    setLocalData(LOCAL_STORAGE_KEYS.SONGS, local);

    try {
      await setDoc(doc(db, 'songs', id), newSong);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `songs/${id}`);
    }

    return newSong;
  },

  async updateSong(id: string, updates: Partial<Song>): Promise<void> {
    const now = new Date().toISOString();
    const finalUpdates = { ...updates, updatedAt: now };

    // Update local cache
    const local = getLocalData<Song[]>(LOCAL_STORAGE_KEYS.SONGS, []);
    const idx = local.findIndex(s => s.id === id);
    if (idx !== -1) {
      local[idx] = { ...local[idx], ...finalUpdates };
      setLocalData(LOCAL_STORAGE_KEYS.SONGS, local);
    }

    try {
      await updateDoc(doc(db, 'songs', id), finalUpdates);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `songs/${id}`);
    }
  },

  async deleteSong(id: string): Promise<void> {
    const local = getLocalData<Song[]>(LOCAL_STORAGE_KEYS.SONGS, []);
    const filtered = local.filter(s => s.id !== id);
    setLocalData(LOCAL_STORAGE_KEYS.SONGS, filtered);

    try {
      await deleteDoc(doc(db, 'songs', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `songs/${id}`);
    }
  },

  async incrementPlayCount(songId: string): Promise<void> {
    const local = getLocalData<Song[]>(LOCAL_STORAGE_KEYS.SONGS, []);
    const song = local.find(s => s.id === songId);
    if (song) {
      song.playCount = (song.playCount || 0) + 1;
      setLocalData(LOCAL_STORAGE_KEYS.SONGS, local);
      try {
        await updateDoc(doc(db, 'songs', songId), {
          playCount: song.playCount,
        });
      } catch (err) {
        // silent fail on playcount to not interrupt audio
        console.warn('Failed to increment play count on server:', err);
      }
    }
  },

  // ---- ALBUMS ----
  async getAlbums(): Promise<Album[]> {
    try {
      const snap = await getDocs(collection(db, 'albums'));
      const remote = snap.docs.map(d => ({ id: d.id, ...d.data() } as Album));
      const local = getLocalData<Album[]>(LOCAL_STORAGE_KEYS.ALBUMS, []);
      const map = new Map<string, Album>();
      local.forEach(a => map.set(a.id, a));
      remote.forEach(a => map.set(a.id, a));
      const list = Array.from(map.values());
      setLocalData(LOCAL_STORAGE_KEYS.ALBUMS, list);
      return list;
    } catch {
      return getLocalData<Album[]>(LOCAL_STORAGE_KEYS.ALBUMS, []);
    }
  },

  async createAlbum(data: Omit<Album, 'id' | 'createdAt'>): Promise<Album> {
    const id = 'album_' + Date.now();
    const newAlbum: Album = {
      ...data,
      id,
      createdAt: new Date().toISOString(),
    };
    const local = getLocalData<Album[]>(LOCAL_STORAGE_KEYS.ALBUMS, []);
    local.unshift(newAlbum);
    setLocalData(LOCAL_STORAGE_KEYS.ALBUMS, local);

    try {
      await setDoc(doc(db, 'albums', id), newAlbum);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `albums/${id}`);
    }
    return newAlbum;
  },

  // ---- ARTISTS ----
  async getArtists(): Promise<Artist[]> {
    try {
      const snap = await getDocs(collection(db, 'artists'));
      const remote = snap.docs.map(d => ({ id: d.id, ...d.data() } as Artist));
      const local = getLocalData<Artist[]>(LOCAL_STORAGE_KEYS.ARTISTS, []);
      const map = new Map<string, Artist>();
      local.forEach(a => map.set(a.id, a));
      remote.forEach(a => map.set(a.id, a));
      const list = Array.from(map.values());
      setLocalData(LOCAL_STORAGE_KEYS.ARTISTS, list);
      return list;
    } catch {
      return getLocalData<Artist[]>(LOCAL_STORAGE_KEYS.ARTISTS, []);
    }
  },

  async createArtist(data: Omit<Artist, 'id' | 'createdAt'>): Promise<Artist> {
    const id = 'artist_' + Date.now();
    const newArtist: Artist = {
      ...data,
      id,
      createdAt: new Date().toISOString(),
    };
    const local = getLocalData<Artist[]>(LOCAL_STORAGE_KEYS.ARTISTS, []);
    local.unshift(newArtist);
    setLocalData(LOCAL_STORAGE_KEYS.ARTISTS, local);

    try {
      await setDoc(doc(db, 'artists', id), newArtist);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `artists/${id}`);
    }
    return newArtist;
  },

  // ---- PLAYLISTS ----
  async getPlaylists(userId?: string): Promise<Playlist[]> {
    try {
      const snap = await getDocs(collection(db, 'playlists'));
      const remote = snap.docs.map(d => ({ id: d.id, ...d.data() } as Playlist));
      const local = getLocalData<Playlist[]>(LOCAL_STORAGE_KEYS.PLAYLISTS, []);
      const map = new Map<string, Playlist>();
      local.forEach(p => map.set(p.id, p));
      remote.forEach(p => map.set(p.id, p));
      const list = Array.from(map.values());
      setLocalData(LOCAL_STORAGE_KEYS.PLAYLISTS, list);
      return userId ? list.filter(p => p.isPublic || p.ownerId === userId) : list.filter(p => p.isPublic);
    } catch {
      const local = getLocalData<Playlist[]>(LOCAL_STORAGE_KEYS.PLAYLISTS, []);
      return userId ? local.filter(p => p.isPublic || p.ownerId === userId) : local.filter(p => p.isPublic);
    }
  },

  async getPlaylistById(id: string): Promise<Playlist | null> {
    try {
      const snap = await getDoc(doc(db, 'playlists', id));
      if (snap.exists()) {
        return { id: snap.id, ...snap.data() } as Playlist;
      }
    } catch {}
    const local = getLocalData<Playlist[]>(LOCAL_STORAGE_KEYS.PLAYLISTS, []);
    return local.find(p => p.id === id) || null;
  },

  async createPlaylist(data: Omit<Playlist, 'id' | 'createdAt' | 'updatedAt'>): Promise<Playlist> {
    const id = 'playlist_' + Date.now();
    const now = new Date().toISOString();
    const newPlaylist: Playlist = {
      ...data,
      id,
      createdAt: now,
      updatedAt: now,
    };
    const local = getLocalData<Playlist[]>(LOCAL_STORAGE_KEYS.PLAYLISTS, []);
    local.unshift(newPlaylist);
    setLocalData(LOCAL_STORAGE_KEYS.PLAYLISTS, local);

    try {
      await setDoc(doc(db, 'playlists', id), newPlaylist);
    } catch (err) {
      handleFirestoreError(err, OperationType.CREATE, `playlists/${id}`);
    }
    return newPlaylist;
  },

  async updatePlaylist(id: string, updates: Partial<Playlist>): Promise<void> {
    const now = new Date().toISOString();
    const finalUpdates = { ...updates, updatedAt: now };

    const local = getLocalData<Playlist[]>(LOCAL_STORAGE_KEYS.PLAYLISTS, []);
    const idx = local.findIndex(p => p.id === id);
    if (idx !== -1) {
      local[idx] = { ...local[idx], ...finalUpdates };
      setLocalData(LOCAL_STORAGE_KEYS.PLAYLISTS, local);
    }

    try {
      await updateDoc(doc(db, 'playlists', id), finalUpdates);
    } catch (err) {
      handleFirestoreError(err, OperationType.UPDATE, `playlists/${id}`);
    }
  },

  async deletePlaylist(id: string): Promise<void> {
    const local = getLocalData<Playlist[]>(LOCAL_STORAGE_KEYS.PLAYLISTS, []);
    setLocalData(LOCAL_STORAGE_KEYS.PLAYLISTS, local.filter(p => p.id !== id));
    try {
      await deleteDoc(doc(db, 'playlists', id));
    } catch (err) {
      handleFirestoreError(err, OperationType.DELETE, `playlists/${id}`);
    }
  },

  // ---- LIKES ----
  async getUserLikes(userId: string): Promise<string[]> {
    try {
      const q = query(collection(db, 'likes'), where('userId', '==', userId));
      const snap = await getDocs(q);
      const remoteIds = snap.docs.map(d => d.data().songId as string);
      const localMap = getLocalData<Record<string, string[]>>(LOCAL_STORAGE_KEYS.LIKES, {});
      const localIds = localMap[userId] || [];
      const set = new Set([...remoteIds, ...localIds]);
      localMap[userId] = Array.from(set);
      setLocalData(LOCAL_STORAGE_KEYS.LIKES, localMap);
      return Array.from(set);
    } catch {
      const localMap = getLocalData<Record<string, string[]>>(LOCAL_STORAGE_KEYS.LIKES, {});
      return localMap[userId] || [];
    }
  },

  async toggleLike(userId: string, songId: string): Promise<boolean> {
    const docId = `${userId}_${songId}`;
    const localMap = getLocalData<Record<string, string[]>>(LOCAL_STORAGE_KEYS.LIKES, {});
    const currentLikes = new Set(localMap[userId] || []);
    let isNowLiked = false;

    if (currentLikes.has(songId)) {
      currentLikes.delete(songId);
      isNowLiked = false;
      try {
        await deleteDoc(doc(db, 'likes', docId));
      } catch {}
    } else {
      currentLikes.add(songId);
      isNowLiked = true;
      try {
        await setDoc(doc(db, 'likes', docId), {
          userId,
          songId,
          addedAt: new Date().toISOString(),
        });
      } catch {}
    }

    localMap[userId] = Array.from(currentLikes);
    setLocalData(LOCAL_STORAGE_KEYS.LIKES, localMap);
    return isNowLiked;
  },

  // ---- LISTENING HISTORY ----
  async recordListeningHistory(userId: string, song: Song): Promise<void> {
    const id = 'hist_' + Date.now();
    const item: ListeningHistoryItem = {
      id,
      userId,
      songId: song.id,
      songTitle: song.title,
      artist: song.artist,
      playedAt: new Date().toISOString(),
    };
    const localHistory = getLocalData<ListeningHistoryItem[]>(LOCAL_STORAGE_KEYS.HISTORY, []);
    localHistory.unshift(item);
    if (localHistory.length > 50) localHistory.pop();
    setLocalData(LOCAL_STORAGE_KEYS.HISTORY, localHistory);

    try {
      await setDoc(doc(db, 'history', id), item);
    } catch {}
  },

  async getUserHistory(userId: string): Promise<ListeningHistoryItem[]> {
    try {
      const q = query(
        collection(db, 'history'),
        where('userId', '==', userId),
        orderBy('playedAt', 'desc'),
        limit(30)
      );
      const snap = await getDocs(q);
      if (!snap.empty) {
        return snap.docs.map(d => ({ id: d.id, ...d.data() } as ListeningHistoryItem));
      }
    } catch {}
    const localHistory = getLocalData<ListeningHistoryItem[]>(LOCAL_STORAGE_KEYS.HISTORY, []);
    return localHistory.filter(h => h.userId === userId);
  },

  // ---- AUDIT LOGS ----
  async recordAuditLog(data: Omit<AdminAuditLog, 'id' | 'timestamp'>): Promise<void> {
    const id = 'audit_' + Date.now();
    const log: AdminAuditLog = {
      ...data,
      id,
      timestamp: new Date().toISOString(),
    };
    const localLogs = getLocalData<AdminAuditLog[]>(LOCAL_STORAGE_KEYS.AUDIT_LOGS, []);
    localLogs.unshift(log);
    setLocalData(LOCAL_STORAGE_KEYS.AUDIT_LOGS, localLogs.slice(0, 100));

    try {
      await setDoc(doc(db, 'adminAuditLogs', id), log);
    } catch {}
  },

  async getAdminAuditLogs(): Promise<AdminAuditLog[]> {
    try {
      const q = query(collection(db, 'adminAuditLogs'), orderBy('timestamp', 'desc'), limit(50));
      const snap = await getDocs(q);
      if (!snap.empty) {
        return snap.docs.map(d => ({ id: d.id, ...d.data() } as AdminAuditLog));
      }
    } catch {}
    return getLocalData<AdminAuditLog[]>(LOCAL_STORAGE_KEYS.AUDIT_LOGS, []);
  },

  // ---- SEED DEMO TRACKS HELPER ----
  async seedDemoTracks(): Promise<{ songsCount: number; albumsCount: number; artistsCount: number }> {
    const createdSongs: Song[] = [];
    for (const item of DEMO_SONGS_SEED) {
      const song = await this.createSong(item);
      createdSongs.push(song);
    }

    // Seed distinct artists
    const artistNames = Array.from(new Set(createdSongs.map(s => s.artist)));
    for (const name of artistNames) {
      await this.createArtist({
        name,
        genres: ['Electronic', 'Chillout'],
        monthlyListeners: Math.floor(Math.random() * 250000) + 50000,
        isVerified: true,
        bio: `${name} is an independent producer crafting immersive soundscapes with SONORA.`,
      });
    }

    // Seed album
    await this.createAlbum({
      title: 'SONORA Genesis Vol. 1',
      artist: 'Various Artists',
      releaseYear: 2025,
      genre: 'Soundtrack',
      songIds: createdSongs.map(s => s.id),
    });

    // Seed a featured playlist
    await this.createPlaylist({
      title: 'SONORA Spotlight 2025',
      description: 'The definitive sound of SONORA. Atmospheric synthwave, lo-fi beats, and soulful chillout.',
      ownerId: 'system_curator',
      ownerName: 'SONORA Editorial',
      songIds: createdSongs.map(s => s.id),
      isPublic: true,
      isFeatured: true,
    });

    return {
      songsCount: createdSongs.length,
      albumsCount: 1,
      artistsCount: artistNames.length,
    };
  },

  // Clear catalog (for testing zero states)
  async clearAllCatalog(): Promise<void> {
    setLocalData(LOCAL_STORAGE_KEYS.SONGS, []);
    setLocalData(LOCAL_STORAGE_KEYS.ALBUMS, []);
    setLocalData(LOCAL_STORAGE_KEYS.ARTISTS, []);
    setLocalData(LOCAL_STORAGE_KEYS.PLAYLISTS, []);
  },
};
