import {
  ProviderTrack,
  MusicProviderSource,
  ProviderStatus,
  UnifiedSearchResult,
} from '../types/providers';
import { jamendoProvider } from './providers/JamendoProvider';
import { regionalMusicProvider } from './providers/RegionalMusicProvider';
import { spotifyProvider } from './providers/SpotifyProvider';
import { sternitersProvider, HomeFeedData } from './providers/SternitersProvider';
import { musicRepository } from './musicRepository';
import { db } from '../lib/firebase';
import { doc, getDoc, setDoc, deleteDoc } from 'firebase/firestore';

export const SUPPORTED_LANGUAGES = [
  { id: 'All', label: 'All Languages', native: 'All' },
  { id: 'Gujarati', label: 'Gujarati', native: 'ગુજરાતી' },
  { id: 'Hindi', label: 'Hindi', native: 'हिन्दी' },
  { id: 'Punjabi', label: 'Punjabi', native: 'ਪੰਜਾਬੀ' },
  { id: 'Tamil', label: 'Tamil', native: 'தமிழ்' },
  { id: 'Telugu', label: 'Telugu', native: 'తెలుగు' },
  { id: 'Marathi', label: 'Marathi', native: 'मराठी' },
  { id: 'Bengali', label: 'Bengali', native: 'বাংলা' },
  { id: 'English', label: 'English', native: 'English' },
];

const CACHE_TTL_HOURS = 12;

class UnifiedMusicService {
  // In-memory runtime cache for rapid instant queries
  private memoryCache = new Map<string, { data: ProviderTrack[]; expires: number }>();

  getProvidersStatus(): ProviderStatus[] {
    return [
      sternitersProvider.getStatus(),
      regionalMusicProvider.getStatus(),
      jamendoProvider.getStatus(),
      spotifyProvider.getStatus(),
    ];
  }

  // Unified Multi-Provider Search
  async search(
    query: string,
    options?: {
      language?: string;
      provider?: MusicProviderSource;
      limit?: number;
      signal?: AbortSignal;
    }
  ): Promise<UnifiedSearchResult> {
    const trimmed = query.trim();
    if (!trimmed) {
      return { tracks: [], total: 0, providersUsed: [] };
    }

    const language = options?.language || 'All';
    const cacheKey = `search_${language}_${trimmed.toLowerCase()}_${options?.provider || 'all'}`;

    // Check memory cache
    const cached = this.memoryCache.get(cacheKey);
    if (cached && Date.now() < cached.expires) {
      return {
        tracks: cached.data,
        total: cached.data.length,
        providersUsed: Array.from(new Set(cached.data.map(t => t.provider))),
      };
    }

    const tracks: ProviderTrack[] = [];
    const providersUsed: MusicProviderSource[] = [];

    // Parallel search across authorized providers
    const promises: Promise<ProviderTrack[]>[] = [];

    // 1. STERNITERS Full Lossless Music Engine (JioSaavn + Regional 320kbps)
    if (!options?.provider || options.provider === 'sterniters') {
      promises.push(
        sternitersProvider
          .search(trimmed, { language, limit: options?.limit || 20 })
          .then(res => {
            if (res.length > 0) providersUsed.push('sterniters');
            return res;
          })
          .catch(() => [])
      );
    }

    // 2. Regional / Multi-Language Music Catalog (Gujarati, Hindi, Punjabi, etc.)
    if (!options?.provider || options.provider === 'itunes') {
      promises.push(
        regionalMusicProvider
          .search(trimmed, { language, limit: options?.limit || 20 })
          .then(res => {
            if (res.length > 0) providersUsed.push('itunes');
            return res;
          })
          .catch(() => [])
      );
    }

    // 2. Jamendo Creative Commons legal music
    if (!options?.provider || options.provider === 'jamendo') {
      promises.push(
        jamendoProvider
          .search(trimmed, options?.limit || 15)
          .then(res => {
            if (res.length > 0) providersUsed.push('jamendo');
            return res;
          })
          .catch(() => [])
      );
    }

    // 3. Spotify Web API (if configured)
    if ((!options?.provider || options.provider === 'spotify') && spotifyProvider.isConfigured()) {
      promises.push(
        spotifyProvider
          .search(trimmed, options?.limit || 10)
          .then(res => {
            if (res.length > 0) providersUsed.push('spotify');
            return res;
          })
          .catch(() => [])
      );
    }

    // 4. Local User Uploads from Sonora
    if (!options?.provider || options.provider === 'local') {
      promises.push(
        musicRepository
          .getSongs(false)
          .then(songs => {
            const q = trimmed.toLowerCase();
            const matched = songs.filter(
              s =>
                s.title.toLowerCase().includes(q) ||
                s.artist.toLowerCase().includes(q) ||
                (s.album && s.album.toLowerCase().includes(q))
            );
            if (matched.length > 0) providersUsed.push('local');
            return matched.map(s => ({
              id: s.id,
              title: s.title,
              artist: s.artist,
              album: s.album,
              coverUrl: s.coverUrl || '',
              audioUrl: s.audioUrl,
              duration: s.duration,
              provider: 'local' as const,
              providerId: s.id,
              externalUrl: '#',
              hasFullPlayback: true,
              license: 'Sonora Local Catalog',
              language: s.language,
              releaseDate: s.releaseDate,
            }));
          })
          .catch(() => [])
      );
    }

    const results = await Promise.all(promises);
    results.forEach(list => tracks.push(...list));

    // Deduplicate by title & artist
    const seen = new Set<string>();
    const uniqueTracks = tracks.filter(t => {
      const key = `${t.title.toLowerCase()}_${t.artist.toLowerCase()}`;
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    });

    // Save to memory cache
    this.memoryCache.set(cacheKey, {
      data: uniqueTracks,
      expires: Date.now() + CACHE_TTL_HOURS * 3600 * 1000,
    });

    // Asynchronously cache in Firestore (if available)
    this.saveToFirestoreCache(cacheKey, uniqueTracks, language).catch(() => {});

    return {
      tracks: uniqueTracks,
      total: uniqueTracks.length,
      providersUsed,
    };
  }

  // Curated Home Feed from STERNITERS Engine
  async getHomeFeed(): Promise<HomeFeedData | null> {
    return sternitersProvider.getHomeFeed();
  }

  // Lyrics Resolver
  async getLyrics(songId: string): Promise<{ lyrics: string | null; lines: string[]; snippet?: string } | null> {
    return sternitersProvider.getLyrics(songId);
  }

  // Automatic Discovery Feeds for Homepage
  async getDiscoveryFeed(language = 'All'): Promise<{
    trending: ProviderTrack[];
    spotlight: ProviderTrack[];
    curated: ProviderTrack[];
  }> {
    const cacheKey = `discovery_feed_${language}`;
    const cached = this.memoryCache.get(cacheKey);
    if (cached && Date.now() < cached.expires) {
      return {
        trending: cached.data.slice(0, 10),
        spotlight: cached.data.slice(10, 18),
        curated: cached.data.slice(18, 26),
      };
    }

    const [sternitersTrending, regionalTracks, jamendoTracks, localSongs] = await Promise.all([
      sternitersProvider.getTrendingByLanguage(language === 'All' ? 'Hindi' : language, 20).catch(() => []),
      regionalMusicProvider.getTrendingByLanguage(language, 12).catch(() => []),
      jamendoProvider.getTrending(10).catch(() => []),
      musicRepository.getSongs(false).catch(() => []),
    ]);

    const mappedLocal: ProviderTrack[] = localSongs.map(s => ({
      id: s.id,
      title: s.title,
      artist: s.artist,
      album: s.album,
      coverUrl: s.coverUrl || '',
      audioUrl: s.audioUrl,
      duration: s.duration,
      provider: 'local',
      providerId: s.id,
      externalUrl: '#',
      hasFullPlayback: true,
      license: 'Sonora Catalog',
    }));

    // Deduplicate by ID and (title+artist)
    const combinedTracks: ProviderTrack[] = [];
    const seenTrackIds = new Set<string>();
    const seenTrackTitles = new Set<string>();

    for (const t of [...sternitersTrending, ...mappedLocal, ...regionalTracks, ...jamendoTracks]) {
      if (!t || !t.id) continue;
      const key = `${t.title.toLowerCase().trim()}___${t.artist.toLowerCase().trim()}`;
      if (!seenTrackIds.has(t.id) && !seenTrackTitles.has(key)) {
        seenTrackIds.add(t.id);
        seenTrackTitles.add(key);
        combinedTracks.push(t);
      }
    }

    this.memoryCache.set(cacheKey, {
      data: combinedTracks,
      expires: Date.now() + 4 * 3600 * 1000,
    });

    return {
      trending: sternitersTrending.length > 0 ? sternitersTrending.slice(0, 10) : combinedTracks.slice(0, 10),
      spotlight: regionalTracks.slice(0, 8),
      curated: jamendoTracks.slice(0, 8),
    };
  }

  clearCache() {
    this.memoryCache.clear();
  }

  private async saveToFirestoreCache(
    key: string,
    tracks: ProviderTrack[],
    language: string
  ) {
    try {
      const sanitizedKey = key.replace(/[^a-zA-Z0-9_-]/g, '_').slice(0, 80);
      const docRef = doc(db, 'cachedMusicMetadata', sanitizedKey);
      await setDoc(docRef, {
        key,
        language,
        tracks: tracks.slice(0, 30),
        cachedAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + CACHE_TTL_HOURS * 3600 * 1000).toISOString(),
      });
    } catch {
      // Non-critical cache error
    }
  }
}

export const unifiedMusicService = new UnifiedMusicService();
