export type MusicProviderSource = 'jamendo' | 'spotify' | 'itunes' | 'local' | 'sterniters';

export interface ProviderTrack {
  id: string;
  title: string;
  artist: string;
  artistId?: string;
  album?: string;
  albumId?: string;
  coverUrl: string;
  audioUrl?: string; // Only populated if authorized direct stream is permitted
  duration: number; // in seconds
  provider: MusicProviderSource;
  providerId: string;
  externalUrl: string; // Destination URL on provider's official platform
  hasFullPlayback: boolean; // True for Jamendo CC streams, false for Spotify metadata (which directs to Spotify)
  embedUrl?: string; // Official embed player URL (e.g. Spotify embed iframe)
  license?: string; // Creative Commons, All Rights Reserved, Preview, etc.
  language?: string; // Gujarati, Hindi, English, Punjabi, etc.
  genre?: string;
  releaseDate?: string;
  playCount?: number;
}

export interface ProviderStatus {
  id: MusicProviderSource;
  name: string;
  isConfigured: boolean;
  health: 'healthy' | 'degraded' | 'unconfigured';
  lastChecked: string;
  requiresCredentials: boolean;
  setupInstructions?: string;
  attributionText: string;
  attributionUrl: string;
}

export interface UnifiedSearchResult {
  tracks: ProviderTrack[];
  total: number;
  providersUsed: MusicProviderSource[];
}

export interface CachedMetadataItem {
  id: string;
  key: string; // Query or cache key
  data: ProviderTrack[];
  provider: MusicProviderSource;
  language?: string;
  cachedAt: string;
  expiresAt: string;
}
