export interface Song {
  id: string;
  title: string;
  artist: string;
  artistIds?: string[];
  album?: string;
  albumId?: string;
  coverUrl?: string;
  audioUrl: string;
  duration: number; // in seconds
  genre?: string;
  language?: string;
  releaseDate?: string;
  lyrics?: string;
  description?: string;
  isExplicit?: boolean;
  isFeatured?: boolean;
  isPublished: boolean;
  playCount: number;
  createdAt?: string;
  updatedAt?: string;
  provider?: 'jamendo' | 'spotify' | 'itunes' | 'local' | 'sterniters';
  providerId?: string;
  externalUrl?: string;
  hasFullPlayback?: boolean;
  embedUrl?: string;
  license?: string;
  quality?: string;
  rawId?: string;
}

export interface Album {
  id: string;
  title: string;
  artist: string;
  artistId?: string;
  coverUrl?: string;
  releaseYear?: number;
  genre?: string;
  songIds: string[];
  createdAt: string;
}

export interface Artist {
  id: string;
  name: string;
  photoUrl?: string;
  bio?: string;
  genres: string[];
  monthlyListeners: number;
  isVerified?: boolean;
  createdAt: string;
}

export interface Playlist {
  id: string;
  title: string;
  description?: string;
  coverUrl?: string;
  ownerId: string;
  ownerName: string;
  songIds: string[];
  isPublic: boolean;
  isFeatured?: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface Like {
  id: string;
  userId: string;
  songId: string;
  addedAt: string;
}

export interface ListeningHistoryItem {
  id: string;
  userId: string;
  songId: string;
  songTitle: string;
  artist: string;
  playedAt: string;
}

export interface UserProfile {
  uid: string;
  email: string | null;
  displayName: string | null;
  photoURL: string | null;
  role: 'admin' | 'user';
  isSuspended?: boolean;
  createdAt: string;
}

export interface AdminAuditLog {
  id: string;
  adminId: string;
  adminEmail: string;
  action: string;
  targetEntity: string;
  targetId: string;
  details: string;
  timestamp: string;
}

export type PlaybackRepeatMode = 'off' | 'all' | 'one';

export interface PlayerState {
  currentSong: Song | null;
  isPlaying: boolean;
  currentTime: number;
  duration: number;
  volume: number;
  isMuted: boolean;
  isShuffle: boolean;
  repeatMode: PlaybackRepeatMode;
  queue: Song[];
  history: Song[];
  queueIndex: number;
}
