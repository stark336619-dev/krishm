import React, { useState, useEffect } from 'react';
import { Play, Shuffle, Clock, Disc } from 'lucide-react';
import { Album, Song } from '../types/music';
import { musicRepository } from '../services/musicRepository';
import { usePlayer } from '../context/PlayerContext';
import { SongRow } from '../components/common/SongRow';
import { formatDuration, getFallbackCoverArt } from '../utils/format';

interface AlbumPageProps {
  albumId: string;
  onNavigate: (path: string) => void;
}

export const AlbumPage: React.FC<AlbumPageProps> = ({ albumId, onNavigate }) => {
  const { playSong, toggleShuffle } = usePlayer();
  const [album, setAlbum] = useState<Album | null>(null);
  const [songs, setSongs] = useState<Song[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchAlbumData = async () => {
      setIsLoading(true);
      const [allAlbums, allSongs] = await Promise.all([
        musicRepository.getAlbums(),
        musicRepository.getSongs(false),
      ]);
      const current = allAlbums.find(a => a.id === albumId);
      if (current) {
        setAlbum(current);
        const albumSongs = allSongs.filter(
          s => current.songIds.includes(s.id) || s.album === current.title
        );
        setSongs(albumSongs);
      }
      setIsLoading(false);
    };
    fetchAlbumData();
  }, [albumId]);

  if (isLoading) {
    return (
      <div className="p-10 text-center text-xs text-[#a7a7a7]">
        Loading album...
      </div>
    );
  }

  if (!album) {
    return (
      <div className="p-10 text-center space-y-3">
        <h2 className="text-xl font-bold text-white">Album not found</h2>
        <button
          onClick={() => onNavigate('/')}
          className="text-xs text-[#1db954] hover:underline"
        >
          Return Home
        </button>
      </div>
    );
  }

  const totalDuration = songs.reduce((acc, s) => acc + s.duration, 0);

  const handlePlayAll = () => {
    if (songs.length > 0) {
      playSong(songs[0], songs);
    }
  };

  const handleShufflePlay = () => {
    if (songs.length > 0) {
      toggleShuffle();
      const randomIndex = Math.floor(Math.random() * songs.length);
      playSong(songs[randomIndex], songs);
    }
  };

  return (
    <div className="pb-32">
      {/* Header Banner */}
      <div className="bg-gradient-to-b from-[#2a303c] to-[#121212] p-6 md:p-10 flex flex-col sm:flex-row items-end gap-6 border-b border-white/5">
        <div className="w-44 h-44 rounded-xl overflow-hidden shadow-2xl shrink-0 bg-[#242424]">
          <img
            src={album.coverUrl || getFallbackCoverArt(album.title, 'album')}
            alt={album.title}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="flex flex-col gap-2 min-w-0">
          <span className="text-xs font-bold uppercase tracking-wider text-white">
            Album
          </span>
          <h1 className="text-3xl md:text-5xl font-extrabold text-white tracking-tight truncate">
            {album.title}
          </h1>
          <div className="flex items-center gap-2 text-xs text-white/80 font-medium mt-1">
            <span
              onClick={() => onNavigate(`/artists/${album.artistId || album.artist}`)}
              className="text-white font-bold hover:underline cursor-pointer"
            >
              {album.artist}
            </span>
            {album.releaseYear && (
              <>
                <span aria-hidden="true">·</span>
                <span>{album.releaseYear}</span>
              </>
            )}
            <span aria-hidden="true">·</span>
            <span>{songs.length} songs</span>
            {songs.length > 0 && (
              <>
                <span aria-hidden="true">·</span>
                <span>{formatDuration(totalDuration)}</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Action Controls */}
      <div className="px-6 md:px-10 py-6 flex items-center gap-4">
        <button
          onClick={handlePlayAll}
          disabled={songs.length === 0}
          className="w-14 h-14 rounded-full bg-[#1db954] text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-transform shadow-xl disabled:opacity-40 disabled:cursor-not-allowed"
        >
          <Play className="w-6 h-6 fill-black ml-1" />
        </button>

        <button
          onClick={handleShufflePlay}
          disabled={songs.length === 0}
          className="p-3 text-[#a7a7a7] hover:text-white transition-colors disabled:opacity-40"
        >
          <Shuffle className="w-6 h-6" />
        </button>
      </div>

      {/* Tracklist */}
      <div className="px-6 md:px-10">
        {songs.length === 0 ? (
          <div className="bg-[#181818] rounded-xl p-10 text-center max-w-md mx-auto border border-white/5 space-y-3">
            <Disc className="w-10 h-10 text-[#727272] mx-auto" />
            <h3 className="text-base font-bold text-white">No tracks in this album yet</h3>
          </div>
        ) : (
          <div className="space-y-1">
            <div className="grid grid-cols-12 px-4 py-2 border-b border-white/10 text-xs font-medium text-[#a7a7a7] uppercase tracking-wider mb-2">
              <span className="col-span-1">#</span>
              <span className="col-span-10">Title</span>
              <div className="col-span-1 text-right flex justify-end">
                <Clock className="w-4 h-4" />
              </div>
            </div>

            {songs.map((song, idx) => (
              <SongRow
                key={`${song.id}_alb_${idx}`}
                song={song}
                index={idx}
                contextQueue={songs}
                showAlbum={false}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
