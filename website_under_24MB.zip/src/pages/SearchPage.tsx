import React, { useState, useEffect, useMemo } from 'react';
import {
  Search as SearchIcon,
  X,
  Clock,
  Music2,
  Disc,
  Mic2,
  ListMusic,
  Play,
} from 'lucide-react';
import { Song, Album, Artist, Playlist } from '../types/music';
import { musicRepository } from '../services/musicRepository';
import { unifiedMusicService, SUPPORTED_LANGUAGES } from '../services/unifiedMusicService';
import { ProviderTrack } from '../types/providers';
import { usePlayer } from '../context/PlayerContext';
import { SongRow } from '../components/common/SongRow';
import { SongCard } from '../components/common/SongCard';
import { AlbumCard } from '../components/common/AlbumCard';
import { ArtistCard } from '../components/common/ArtistCard';
import { PlaylistCard } from '../components/common/PlaylistCard';
import { getFallbackCoverArt } from '../utils/format';

function trackToSong(t: ProviderTrack): Song {
  return {
    id: t.id,
    title: t.title,
    artist: t.artist,
    album: t.album,
    albumId: t.albumId,
    coverUrl: t.coverUrl,
    audioUrl: t.audioUrl || '',
    duration: t.duration,
    genre: t.genre,
    language: t.language,
    releaseDate: t.releaseDate,
    isPublished: true,
    playCount: t.playCount || 0,
    provider: t.provider,
    providerId: t.providerId,
    externalUrl: t.externalUrl,
    hasFullPlayback: t.hasFullPlayback,
    embedUrl: t.embedUrl,
    license: t.license,
  };
}

interface SearchPageProps {
  onNavigate: (path: string) => void;
  query: string;
  onQueryChange: (q: string) => void;
}

type SearchTab = 'all' | 'songs' | 'artists' | 'albums' | 'playlists';

export const SearchPage: React.FC<SearchPageProps> = ({
  onNavigate,
  query,
  onQueryChange,
}) => {
  const { playSong } = usePlayer();
  const [activeTab, setActiveTab] = useState<SearchTab>('all');
  const [songs, setSongs] = useState<Song[]>([]);
  const [albums, setAlbums] = useState<Album[]>([]);
  const [artists, setArtists] = useState<Artist[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      const stored = localStorage.getItem('sonora_recent_searches');
      return stored ? JSON.parse(stored) : [];
    } catch {
      return [];
    }
  });

  useEffect(() => {
    const fetchData = async () => {
      const [s, al, ar, pl] = await Promise.all([
        musicRepository.getSongs(false),
        musicRepository.getAlbums(),
        musicRepository.getArtists(),
        musicRepository.getPlaylists(),
      ]);
      setSongs(s);
      setAlbums(al);
      setArtists(ar);
      setPlaylists(pl);
    };
    fetchData();
  }, []);

  // Save to recent searches when query is typed
  useEffect(() => {
    const trimmed = query.trim();
    if (trimmed.length > 2) {
      const timer = setTimeout(() => {
        setRecentSearches(prev => {
          const filtered = prev.filter(item => item.toLowerCase() !== trimmed.toLowerCase());
          const updated = [trimmed, ...filtered].slice(0, 8);
          localStorage.setItem('sonora_recent_searches', JSON.stringify(updated));
          return updated;
        });
      }, 1200);
      return () => clearTimeout(timer);
    }
  }, [query]);

  const clearRecentSearches = () => {
    setRecentSearches([]);
    localStorage.removeItem('sonora_recent_searches');
  };

  const removeRecentSearch = (item: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setRecentSearches(prev => {
      const filtered = prev.filter(i => i !== item);
      localStorage.setItem('sonora_recent_searches', JSON.stringify(filtered));
      return filtered;
    });
  };

  const [providerSongs, setProviderSongs] = useState<Song[]>([]);
  const [isSearchingProviders, setIsSearchingProviders] = useState(false);
  const [searchLanguage, setSearchLanguage] = useState('All');

  // Debounced multi-provider search
  useEffect(() => {
    const trimmed = query.trim();
    if (trimmed.length < 2) {
      setProviderSongs([]);
      return;
    }

    const controller = new AbortController();
    setIsSearchingProviders(true);

    const timeoutId = setTimeout(() => {
      unifiedMusicService
        .search(trimmed, { language: searchLanguage, signal: controller.signal })
        .then(res => {
          setProviderSongs(res.tracks.map(trackToSong));
          setIsSearchingProviders(false);
        })
        .catch(() => {
          setIsSearchingProviders(false);
        });
    }, 350);

    return () => {
      clearTimeout(timeoutId);
      controller.abort();
    };
  }, [query, searchLanguage]);

  // Filtered local collections
  const filteredSongs = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return songs.filter(
      s =>
        s.title.toLowerCase().includes(q) ||
        s.artist.toLowerCase().includes(q) ||
        (s.album && s.album.toLowerCase().includes(q)) ||
        (s.genre && s.genre.toLowerCase().includes(q))
    );
  }, [songs, query]);

  const filteredArtists = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return artists.filter(a => a.name.toLowerCase().includes(q));
  }, [artists, query]);

  const filteredAlbums = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return albums.filter(
      al => al.title.toLowerCase().includes(q) || al.artist.toLowerCase().includes(q)
    );
  }, [albums, query]);

  const filteredPlaylists = useMemo(() => {
    if (!query.trim()) return [];
    const q = query.toLowerCase();
    return playlists.filter(p => p.title.toLowerCase().includes(q));
  }, [playlists, query]);

  // Combined songs (local DB + live provider results deduplicated)
  const allMatchedSongs = useMemo(() => {
    const seenIds = new Set<string>();
    const seenTitles = new Set<string>();
    const combined: Song[] = [];

    // Local matches first
    filteredSongs.forEach(s => {
      if (!s || !s.id) return;
      const key = `${s.title.toLowerCase().trim()}___${s.artist.toLowerCase().trim()}`;
      if (!seenIds.has(s.id) && !seenTitles.has(key)) {
        seenIds.add(s.id);
        seenTitles.add(key);
        combined.push(s);
      }
    });

    // Provider matches
    providerSongs.forEach(s => {
      if (!s || !s.id) return;
      const key = `${s.title.toLowerCase().trim()}___${s.artist.toLowerCase().trim()}`;
      if (!seenIds.has(s.id) && !seenTitles.has(key)) {
        seenIds.add(s.id);
        seenTitles.add(key);
        combined.push(s);
      }
    });

    return combined;
  }, [filteredSongs, providerSongs]);

  const hasResults =
    allMatchedSongs.length > 0 ||
    filteredArtists.length > 0 ||
    filteredAlbums.length > 0 ||
    filteredPlaylists.length > 0;

  const topResultSong = allMatchedSongs[0];

  return (
    <div className="p-6 md:p-8 space-y-6 pb-32">
      {/* Language filter & Category Tabs */}
      {query.trim().length > 0 && (
        <div className="space-y-3">
          {/* Language filter pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 custom-scroll">
            <span className="text-[11px] text-[#a7a7a7] shrink-0 font-medium">Language:</span>
            {SUPPORTED_LANGUAGES.map(lang => (
              <button
                key={lang.id}
                onClick={() => setSearchLanguage(lang.id)}
                className={`px-3 py-1 rounded-full text-[11px] font-semibold transition-colors shrink-0 ${
                  searchLanguage === lang.id
                    ? 'bg-[#1db954] text-black font-bold'
                    : 'bg-[#1e1e1e] text-[#a7a7a7] hover:text-white hover:bg-[#282828]'
                }`}
              >
                {lang.native}
              </button>
            ))}
            {isSearchingProviders && (
              <span className="text-[10px] text-[#1db954] animate-pulse shrink-0 ml-2">
                Searching music catalogs...
              </span>
            )}
          </div>

          {/* Category Tabs */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 custom-scroll">
            {(
              [
                { id: 'all', label: 'All' },
                { id: 'songs', label: `Songs (${allMatchedSongs.length})` },
                { id: 'artists', label: `Artists (${filteredArtists.length})` },
                { id: 'albums', label: `Albums (${filteredAlbums.length})` },
                { id: 'playlists', label: `Playlists (${filteredPlaylists.length})` },
              ] as const
            ).map(tab => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-colors shrink-0 ${
                  activeTab === tab.id
                    ? 'bg-white text-black'
                    : 'bg-[#242424] text-white hover:bg-[#303030]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* Zero query view: Recent Searches & Browse Categories */}
      {!query.trim() && (
        <div className="space-y-8">
          {recentSearches.length > 0 && (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-white flex items-center gap-2">
                  <Clock className="w-4 h-4 text-[#a7a7a7]" />
                  <span>Recent searches</span>
                </h3>
                <button
                  onClick={clearRecentSearches}
                  className="text-xs text-[#a7a7a7] hover:text-white"
                >
                  Clear all
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {recentSearches.map(item => (
                  <div
                    key={item}
                    onClick={() => onQueryChange(item)}
                    className="flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-[#242424] hover:bg-[#333333] text-xs text-white cursor-pointer transition-colors group"
                  >
                    <span>{item}</span>
                    <button
                      onClick={e => removeRecentSearch(item, e)}
                      className="text-[#727272] group-hover:text-white"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Browse Genres & Categories */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-white tracking-tight">
              Browse All
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
              {[
                { name: 'Synthwave', bg: 'from-fuchsia-800 to-purple-950' },
                { name: 'Lo-Fi Chill', bg: 'from-amber-700 to-stone-900' },
                { name: 'Electronic', bg: 'from-blue-700 to-slate-950' },
                { name: 'Neo-Soul', bg: 'from-emerald-700 to-emerald-950' },
                { name: 'Indie Folk', bg: 'from-rose-800 to-red-950' },
                { name: 'Ambient', bg: 'from-indigo-800 to-slate-900' },
                { name: 'Jazz & Funk', bg: 'from-orange-700 to-yellow-950' },
                { name: 'Classical', bg: 'from-teal-800 to-cyan-950' },
              ].map(cat => (
                <div
                  key={cat.name}
                  onClick={() => onQueryChange(cat.name)}
                  className={`h-28 rounded-xl bg-gradient-to-br ${cat.bg} p-4 cursor-pointer hover:scale-105 active:scale-95 transition-all shadow-md relative overflow-hidden flex flex-col justify-between`}
                >
                  <h3 className="text-sm font-bold text-white tracking-tight">
                    {cat.name}
                  </h3>
                  <div className="self-end opacity-20">
                    <Music2 className="w-10 h-10 text-white" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Search Results */}
      {query.trim().length > 0 && (
        <div className="space-y-8">
          {!hasResults ? (
            <div className="bg-[#181818] rounded-xl p-12 text-center max-w-lg mx-auto border border-white/5 space-y-3">
              <SearchIcon className="w-10 h-10 text-[#727272] mx-auto" />
              <h3 className="text-base font-bold text-white">
                No results found for "{query}"
              </h3>
              <p className="text-xs text-[#a7a7a7]">
                Please make sure your words are spelled correctly or use fewer or different keywords.
              </p>
            </div>
          ) : (
            <>
              {/* Top Result + Top Songs (shown on 'all' tab) */}
              {activeTab === 'all' && topResultSong && (
                <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                  {/* Top Result Card */}
                  <div className="lg:col-span-2 space-y-3">
                    <h3 className="text-base font-bold text-white">Top Result</h3>
                    <div
                      onClick={() => playSong(topResultSong, allMatchedSongs)}
                      className="group bg-[#181818] hover:bg-[#282828] p-5 rounded-2xl cursor-pointer transition-all flex flex-col justify-between relative shadow-xl h-56"
                    >
                      <img
                        src={
                          topResultSong.coverUrl ||
                          getFallbackCoverArt(topResultSong.title)
                        }
                        alt={topResultSong.title}
                        className="w-24 h-24 rounded-lg object-cover shadow-md"
                      />
                      <div>
                        <h4 className="text-xl font-bold text-white truncate">
                          {topResultSong.title}
                        </h4>
                        <div className="flex items-center gap-2 text-xs text-[#a7a7a7] mt-1">
                          <span className="font-medium text-white">
                            {topResultSong.artist}
                          </span>
                          <span aria-hidden="true">·</span>
                          <span className="text-[10px] bg-black/40 px-2 py-0.5 rounded-full uppercase tracking-wider font-semibold">
                            Song
                          </span>
                        </div>
                      </div>

                      <button
                        onClick={e => {
                          e.stopPropagation();
                          playSong(topResultSong, allMatchedSongs);
                        }}
                        className="absolute bottom-5 right-5 w-12 h-12 rounded-full bg-[#1db954] text-black flex items-center justify-center shadow-2xl opacity-0 translate-y-2 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-200 hover:scale-105"
                      >
                        <Play className="w-5 h-5 fill-black ml-0.5" />
                      </button>
                    </div>
                  </div>

                  {/* Songs list */}
                  <div className="lg:col-span-3 space-y-3">
                    <h3 className="text-base font-bold text-white">Songs</h3>
                    <div className="space-y-1">
                      {allMatchedSongs.slice(0, 4).map((s, idx) => (
                        <SongRow
                          key={`${s.id}_top_${idx}`}
                          song={s}
                          index={idx}
                          contextQueue={allMatchedSongs}
                          showAlbum={false}
                        />
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {/* Dedicated Songs Tab */}
              {(activeTab === 'all' || activeTab === 'songs') &&
                allMatchedSongs.length > 0 &&
                activeTab === 'songs' && (
                  <div className="space-y-3">
                    <h3 className="text-base font-bold text-white">All Matching Songs</h3>
                    <div className="space-y-1">
                      {allMatchedSongs.map((s, idx) => (
                        <SongRow
                          key={`${s.id}_all_${idx}`}
                          song={s}
                          index={idx}
                          contextQueue={allMatchedSongs}
                        />
                      ))}
                    </div>
                  </div>
                )}

              {/* Artists Section */}
              {(activeTab === 'all' || activeTab === 'artists') &&
                filteredArtists.length > 0 && (
                  <div className="space-y-3">
                    <h3 className="text-base font-bold text-white">Artists</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                      {filteredArtists.map(artist => (
                        <ArtistCard
                          key={artist.id}
                          artist={artist}
                          onClick={() => onNavigate(`/artists/${artist.id}`)}
                        />
                      ))}
                    </div>
                  </div>
                )}

              {/* Albums Section */}
              {(activeTab === 'all' || activeTab === 'albums') &&
                filteredAlbums.length > 0 && (
                  <div className="space-y-3">
                    <h3 className="text-base font-bold text-white">Albums</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                      {filteredAlbums.map(album => (
                        <AlbumCard
                          key={album.id}
                          album={album}
                          onClick={() => onNavigate(`/albums/${album.id}`)}
                        />
                      ))}
                    </div>
                  </div>
                )}

              {/* Playlists Section */}
              {(activeTab === 'all' || activeTab === 'playlists') &&
                filteredPlaylists.length > 0 && (
                  <div className="space-y-3">
                    <h3 className="text-base font-bold text-white">Playlists</h3>
                    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
                      {filteredPlaylists.map(playlist => (
                        <PlaylistCard
                          key={playlist.id}
                          playlist={playlist}
                          onClick={() => onNavigate(`/playlists/${playlist.id}`)}
                        />
                      ))}
                    </div>
                  </div>
                )}
            </>
          )}
        </div>
      )}
    </div>
  );
};
