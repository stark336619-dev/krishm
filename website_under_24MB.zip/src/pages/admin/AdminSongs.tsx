import React, { useState, useEffect, useMemo } from 'react';
import {
  Music,
  Plus,
  Search,
  Edit,
  Trash2,
  Play,
  Pause,
  Eye,
  EyeOff,
  ArrowUpDown,
  CheckSquare,
  Square,
  AlertTriangle,
  ExternalLink,
  Copy,
  Check,
  Image as ImageIcon,
  Download,
  RefreshCw,
  Database,
  Radio,
  FileSpreadsheet,
} from 'lucide-react';
import { Song } from '../../types/music';
import { musicRepository } from '../../services/musicRepository';
import { usePlayer } from '../../context/PlayerContext';
import { useAuth } from '../../context/AuthContext';
import { formatDuration, formatNumber, formatTimeAgo, getFallbackCoverArt } from '../../utils/format';

interface AdminSongsProps {
  onNavigate: (path: string) => void;
}

type SortField = 'title' | 'artist' | 'playCount' | 'createdAt';
type SortOrder = 'asc' | 'desc';
type CatalogSource = 'all' | 'database' | 'trending' | 'romance' | 'garba';

export const AdminSongs: React.FC<AdminSongsProps> = ({ onNavigate }) => {
  const { currentSong, isPlaying, playSong, togglePlay } = usePlayer();
  const { userProfile } = useAuth();

  // State
  const [dbSongs, setDbSongs] = useState<Song[]>([]);
  const [liveSongs, setLiveSongs] = useState<Song[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'published' | 'draft'>('all');
  const [sourceFilter, setSourceFilter] = useState<CatalogSource>('all');
  const [sortField, setSortField] = useState<SortField>('createdAt');
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc');

  // Copy feedback state: key = `${type}_${songId}`
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Bulk selection
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  // Delete modal state
  const [songToDelete, setSongToDelete] = useState<Song | null>(null);

  // Save to DB in-progress state
  const [savingId, setSavingId] = useState<string | null>(null);

  // Pagination
  const [currentPage, setCurrentPage] = useState(1);
  const [pageSize, setPageSize] = useState(15);

  // Load database and live catalog songs
  const loadAllSongs = async (showRefreshIndicator = false) => {
    if (showRefreshIndicator) setIsRefreshing(true);
    else setIsLoading(true);

    try {
      // 1. Fetch saved songs from Firestore
      const saved = await musicRepository.getSongs(true);
      setDbSongs(saved);

      // 2. Fetch live discovery songs from backend API
      const fetchedLive: Song[] = [];

      try {
        const [homeRes, romanceRes, garbaRes] = await Promise.all([
          fetch('/backend.php?action=home&limit=80').then(r => (r.ok ? r.json() : null)),
          fetch('/backend.php?action=romance_station&limit=60').then(r => (r.ok ? r.json() : null)),
          fetch('/backend.php?action=search&q=garba&limit=30').then(r => (r.ok ? r.json() : null)),
        ]);

        const rawList = [
          ...(Array.isArray(homeRes?.results) ? homeRes.results : []),
          ...(Array.isArray(romanceRes?.results) ? romanceRes.results : []),
          ...(Array.isArray(romanceRes?.arijit) ? romanceRes.arijit : []),
          ...(Array.isArray(garbaRes?.results) ? garbaRes.results : []),
        ];

        const seenIds = new Set<string>();
        for (const item of rawList) {
          const id = item.id || item.rawId;
          if (!id || seenIds.has(id)) continue;
          seenIds.add(id);

          const fullStreamUrl = item.stream_url?.startsWith('http')
            ? item.stream_url
            : `${window.location.origin}${item.stream_url || `/backend.php?action=stream_proxy&id=${id}`}`;

          fetchedLive.push({
            id: `live_${id}`,
            rawId: id,
            title: item.title || 'Untitled',
            artist: item.artist || (Array.isArray(item.artists) ? item.artists.join(', ') : 'Various Artists'),
            album: item.album || 'Single',
            coverUrl: item.image || item.coverUrl || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&auto=format&fit=crop&q=80',
            audioUrl: fullStreamUrl,
            duration: item.duration || 180,
            genre: item.genre || 'Bollywood',
            language: item.language || 'Hindi',
            isPublished: true,
            playCount: item.play_count || item.playCount || 1000,
            provider: 'sterniters',
            quality: item.quality || '320kbps Lossless',
            createdAt: new Date().toISOString(),
          });
        }
      } catch (err) {
        console.error('Failed to fetch live discovery songs:', err);
      }

      setLiveSongs(fetchedLive);
    } catch (err) {
      console.error('Error loading songs in admin:', err);
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  };

  useEffect(() => {
    loadAllSongs();
  }, []);

  // Copy helper
  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => {
      setCopiedKey(null);
    }, 2000);
  };

  // Export all links as CSV
  const handleExportLinksCsv = () => {
    const rows = [
      ['Title', 'Artist', 'Album', 'Language', 'Duration (sec)', 'Song Audio Stream URL', 'Cover JPG URL'],
      ...filteredSongs.map(s => [
        `"${s.title.replace(/"/g, '""')}"`,
        `"${s.artist.replace(/"/g, '""')}"`,
        `"${(s.album || '').replace(/"/g, '""')}"`,
        `"${s.language || 'Hindi'}"`,
        s.duration,
        `"${s.audioUrl}"`,
        `"${s.coverUrl || ''}"`,
      ]),
    ];

    const csvContent = 'data:text/csv;charset=utf-8,' + rows.map(e => e.join(',')).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', `sonora_songs_links_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Save a live discovery song to Firestore Database
  const handleSaveToDb = async (song: Song) => {
    setSavingId(song.id);
    try {
      const cleanSong: Omit<Song, 'id' | 'createdAt' | 'updatedAt' | 'playCount'> = {
        title: song.title,
        artist: song.artist,
        album: song.album || 'Single',
        coverUrl: song.coverUrl,
        audioUrl: song.audioUrl,
        duration: song.duration,
        genre: song.genre || 'Soundtrack',
        language: song.language || 'Hindi',
        isPublished: true,
        provider: 'sterniters',
        providerId: song.rawId || song.id,
        rawId: song.rawId || song.id,
        quality: '320kbps Lossless',
      };

      const newSong = await musicRepository.createSong(cleanSong);
      await musicRepository.recordAuditLog({
        adminId: userProfile?.uid || 'admin',
        adminEmail: userProfile?.email || 'admin@sonora.app',
        action: 'CREATE_SONG',
        targetEntity: 'song',
        targetId: newSong.id,
        details: `Saved live track "${song.title}" by ${song.artist} to Firestore`,
      });

      // Reload
      await loadAllSongs();
    } catch (err) {
      console.error('Failed to save song to DB:', err);
    } finally {
      setSavingId(null);
    }
  };

  // Combine and filter songs
  const combinedSongs = useMemo(() => {
    if (sourceFilter === 'database') {
      return dbSongs;
    }
    if (sourceFilter === 'trending') {
      return liveSongs.filter(s => s.genre !== 'Romantic' && !s.title.toLowerCase().includes('garba'));
    }
    if (sourceFilter === 'romance') {
      return liveSongs.filter(
        s =>
          s.title.toLowerCase().includes('love') ||
          s.title.toLowerCase().includes('tum') ||
          s.artist.toLowerCase().includes('arijit') ||
          s.artist.toLowerCase().includes('atif')
      );
    }
    if (sourceFilter === 'garba') {
      return liveSongs.filter(
        s =>
          s.title.toLowerCase().includes('garba') ||
          s.language?.toLowerCase() === 'gujarati' ||
          s.artist.toLowerCase().includes('kinjal')
      );
    }

    // Default: 'all' -> Merge dbSongs + liveSongs (dedup by rawId / title)
    const list = [...dbSongs];
    const seenTitles = new Set(dbSongs.map(s => `${s.title.toLowerCase()}_${s.artist.toLowerCase()}`));

    for (const s of liveSongs) {
      const key = `${s.title.toLowerCase()}_${s.artist.toLowerCase()}`;
      if (!seenTitles.has(key)) {
        seenTitles.add(key);
        list.push(s);
      }
    }

    return list;
  }, [dbSongs, liveSongs, sourceFilter]);

  const handleSort = (field: SortField) => {
    if (sortField === field) {
      setSortOrder(prev => (prev === 'asc' ? 'desc' : 'asc'));
    } else {
      setSortField(field);
      setSortOrder('desc');
    }
  };

  const filteredSongs = useMemo(() => {
    let result = [...combinedSongs];

    if (search.trim()) {
      const q = search.toLowerCase();
      result = result.filter(
        s =>
          s.title.toLowerCase().includes(q) ||
          s.artist.toLowerCase().includes(q) ||
          (s.album && s.album.toLowerCase().includes(q)) ||
          (s.language && s.language.toLowerCase().includes(q)) ||
          (s.audioUrl && s.audioUrl.toLowerCase().includes(q)) ||
          (s.coverUrl && s.coverUrl.toLowerCase().includes(q))
      );
    }

    if (statusFilter === 'published') {
      result = result.filter(s => s.isPublished);
    } else if (statusFilter === 'draft') {
      result = result.filter(s => !s.isPublished);
    }

    result.sort((a, b) => {
      let cmp = 0;
      if (sortField === 'title') cmp = a.title.localeCompare(b.title);
      else if (sortField === 'artist') cmp = a.artist.localeCompare(b.artist);
      else if (sortField === 'playCount') cmp = (a.playCount || 0) - (b.playCount || 0);
      else if (sortField === 'createdAt')
        cmp = new Date(a.createdAt || 0).getTime() - new Date(b.createdAt || 0).getTime();

      return sortOrder === 'asc' ? cmp : -cmp;
    });

    return result;
  }, [combinedSongs, search, statusFilter, sortField, sortOrder]);

  const totalPages = Math.ceil(filteredSongs.length / pageSize) || 1;
  const paginatedSongs = filteredSongs.slice((currentPage - 1) * pageSize, currentPage * pageSize);

  const toggleSelectAll = () => {
    if (selectedIds.size === paginatedSongs.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(paginatedSongs.map(s => s.id)));
    }
  };

  const toggleSelect = (id: string) => {
    setSelectedIds(prev => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  };

  const handleTogglePublish = async (song: Song) => {
    if (song.id.startsWith('live_')) {
      alert('This song is currently streaming from the live discovery catalog. Click "Save to DB" to store and customize its draft/published status.');
      return;
    }
    const updated = !song.isPublished;
    await musicRepository.updateSong(song.id, { isPublished: updated });
    await musicRepository.recordAuditLog({
      adminId: userProfile?.uid || 'admin',
      adminEmail: userProfile?.email || 'admin@sonora.app',
      action: updated ? 'PUBLISH_SONG' : 'UNPUBLISH_SONG',
      targetEntity: 'song',
      targetId: song.id,
      details: `Changed publish status of "${song.title}" to ${updated}`,
    });
    loadAllSongs();
  };

  const confirmDelete = async () => {
    if (!songToDelete) return;
    if (songToDelete.id.startsWith('live_')) {
      setLiveSongs(prev => prev.filter(s => s.id !== songToDelete.id));
      setSongToDelete(null);
      return;
    }
    await musicRepository.deleteSong(songToDelete.id);
    await musicRepository.recordAuditLog({
      adminId: userProfile?.uid || 'admin',
      adminEmail: userProfile?.email || 'admin@sonora.app',
      action: 'DELETE_SONG',
      targetEntity: 'song',
      targetId: songToDelete.id,
      details: `Deleted song "${songToDelete.title}" by ${songToDelete.artist}`,
    });
    setSongToDelete(null);
    loadAllSongs();
  };

  return (
    <div className="space-y-6">
      {/* Header with Title and Global Actions */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-gradient-to-r from-[#181818] via-[#1a1528] to-[#181818] p-6 rounded-3xl border border-white/5 shadow-2xl">
        <div>
          <div className="flex items-center gap-3">
            <h2 className="text-2xl font-black text-white tracking-tight">
              SONG CATALOG & AUDIO LINKS
            </h2>
            <span className="bg-[#1db954]/20 text-[#1db954] text-xs font-bold px-2.5 py-0.5 rounded-full border border-[#1db954]/30">
              Admin Link Hub
            </span>
          </div>
          <p className="text-xs text-[#a7a7a7] mt-1.5 leading-relaxed">
            તમામ ગીતોની ડાયરેક્ટ ઓડિયો લિંક્સ (Song Stream Links) અને કવર ફોટો લિંક્સ (JPG Links) એક જ જગ્યાએ જુઓ, પ્લે કરો અને કોપી કરો.
          </p>
          <div className="flex flex-wrap items-center gap-3 mt-3 text-[11px] font-mono text-[#a7a7a7]">
            <span className="flex items-center gap-1.5 text-white bg-white/5 px-2.5 py-1 rounded-lg">
              <Music className="w-3.5 h-3.5 text-[#1db954]" />
              <strong>{filteredSongs.length}</strong> Total Songs
            </span>
            <span className="flex items-center gap-1.5 text-[#a7a7a7] bg-white/5 px-2.5 py-1 rounded-lg">
              <Database className="w-3.5 h-3.5 text-purple-400" />
              <strong>{dbSongs.length}</strong> Saved in DB
            </span>
            <span className="flex items-center gap-1.5 text-[#a7a7a7] bg-white/5 px-2.5 py-1 rounded-lg">
              <Radio className="w-3.5 h-3.5 text-cyan-400" />
              <strong>{liveSongs.length}</strong> Live Discovery Hits
            </span>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          {/* Refresh Catalog */}
          <button
            onClick={() => loadAllSongs(true)}
            disabled={isRefreshing}
            className="flex items-center gap-2 bg-[#282828] hover:bg-[#333333] text-white font-medium text-xs px-3.5 py-2 rounded-full border border-white/10 transition-colors disabled:opacity-50"
            title="Refresh latest songs from API"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-[#1db954]' : ''}`} />
            <span>Refresh</span>
          </button>

          {/* Export CSV */}
          <button
            onClick={handleExportLinksCsv}
            className="flex items-center gap-2 bg-[#282828] hover:bg-[#333333] text-white font-medium text-xs px-3.5 py-2 rounded-full border border-white/10 transition-colors"
            title="Export all song links & JPG links to CSV file"
          >
            <FileSpreadsheet className="w-3.5 h-3.5 text-emerald-400" />
            <span>Export Links (.CSV)</span>
          </button>

          {/* Add New Song */}
          <button
            onClick={() => onNavigate('/admin/songs/new')}
            className="flex items-center gap-2 bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-4 py-2 rounded-full hover:scale-105 transition-transform shadow-lg shadow-[#1db954]/20"
          >
            <Plus className="w-4 h-4" />
            <span>Add New Song</span>
          </button>
        </div>
      </div>

      {/* Catalog Source Pills */}
      <div className="flex flex-wrap items-center gap-2 border-b border-white/5 pb-3">
        <span className="text-xs text-[#727272] font-semibold uppercase tracking-wider mr-1">
          Catalog Source:
        </span>
        {[
          { key: 'all', label: 'All Songs (તમામ ગીતો)', icon: Music },
          { key: 'database', label: 'Database Only (Firestore)', icon: Database },
          { key: 'trending', label: 'Trending & Hits (JioSaavn)', icon: Radio },
          { key: 'romance', label: 'Romance & Arijit Hits', icon: Music },
          { key: 'garba', label: 'Garba & Gujarati Special', icon: Music },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = sourceFilter === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => {
                setSourceFilter(tab.key as CatalogSource);
                setCurrentPage(1);
              }}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all ${
                isActive
                  ? 'bg-white text-black shadow-md'
                  : 'bg-[#181818] text-[#a7a7a7] hover:text-white hover:bg-[#222222] border border-white/5'
              }`}
            >
              <Icon className={`w-3.5 h-3.5 ${isActive ? 'text-black' : 'text-[#727272]'}`} />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="w-4 h-4 text-[#727272] absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => {
              setSearch(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search by title, artist, album, language, or URL..."
            className="w-full bg-[#181818] border border-white/10 text-white text-xs pl-10 pr-4 py-2.5 rounded-full focus:outline-none focus:border-[#1db954] transition-colors"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Status Segmented Buttons */}
          <div className="bg-[#181818] p-1 rounded-full border border-white/10 flex items-center gap-1 text-xs">
            {(['all', 'published', 'draft'] as const).map(tab => (
              <button
                key={tab}
                onClick={() => {
                  setStatusFilter(tab);
                  setCurrentPage(1);
                }}
                className={`px-3 py-1 rounded-full font-medium transition-colors capitalize ${
                  statusFilter === tab
                    ? 'bg-[#1db954] text-black font-bold'
                    : 'text-[#a7a7a7] hover:text-white'
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          {/* Page Size Selector */}
          <select
            value={pageSize}
            onChange={e => {
              setPageSize(Number(e.target.value));
              setCurrentPage(1);
            }}
            className="bg-[#181818] border border-white/10 text-[#a7a7a7] hover:text-white text-xs px-3 py-1.5 rounded-full focus:outline-none"
          >
            <option value={10}>10 per page</option>
            <option value={15}>15 per page</option>
            <option value={25}>25 per page</option>
            <option value={50}>50 per page</option>
          </select>
        </div>
      </div>

      {/* Songs Table with Direct Links */}
      <div className="bg-[#141414] rounded-2xl border border-white/10 overflow-hidden shadow-2xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#1c1c1c] text-[#a7a7a7] uppercase tracking-wider text-[11px] border-b border-white/10">
              <tr>
                <th className="p-3 pl-4 w-10">
                  <button onClick={toggleSelectAll} className="text-[#a7a7a7] hover:text-white">
                    {selectedIds.size === paginatedSongs.length && paginatedSongs.length > 0 ? (
                      <CheckSquare className="w-4 h-4 text-[#1db954]" />
                    ) : (
                      <Square className="w-4 h-4" />
                    )}
                  </button>
                </th>
                <th
                  onClick={() => handleSort('title')}
                  className="p-3 cursor-pointer hover:text-white transition-colors min-w-[200px]"
                >
                  <div className="flex items-center gap-1.5">
                    <span>Song Info</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="p-3 min-w-[240px]">
                  <div className="flex items-center gap-1.5 text-cyan-400 font-bold">
                    <Music className="w-3.5 h-3.5" />
                    <span>Song Audio Link (સ્ટ્રીમ લિંક)</span>
                  </div>
                </th>
                <th className="p-3 min-w-[220px]">
                  <div className="flex items-center gap-1.5 text-purple-400 font-bold">
                    <ImageIcon className="w-3.5 h-3.5" />
                    <span>Cover JPG Link (ફોટો લિંક)</span>
                  </div>
                </th>
                <th
                  onClick={() => handleSort('playCount')}
                  className="p-3 cursor-pointer hover:text-white transition-colors text-right"
                >
                  <div className="flex items-center justify-end gap-1.5">
                    <span>Plays</span>
                    <ArrowUpDown className="w-3 h-3" />
                  </div>
                </th>
                <th className="p-3 text-center">Source</th>
                <th className="p-3 pr-4 text-right">Actions</th>
              </tr>
            </thead>

            <tbody className="divide-y divide-white/5 font-sans">
              {isLoading ? (
                <tr>
                  <td colSpan={7} className="p-16 text-center text-[#727272]">
                    <div className="flex flex-col items-center justify-center gap-3">
                      <RefreshCw className="w-6 h-6 animate-spin text-[#1db954]" />
                      <p className="text-xs text-[#a7a7a7]">Loading songs and direct streaming links...</p>
                    </div>
                  </td>
                </tr>
              ) : paginatedSongs.length === 0 ? (
                <tr>
                  <td colSpan={7} className="p-16 text-center text-[#727272]">
                    No songs found matching your criteria.
                  </td>
                </tr>
              ) : (
                paginatedSongs.map(song => {
                  const isSelected = selectedIds.has(song.id);
                  const isCurrent = currentSong?.id === song.id;
                  const isLive = song.id.startsWith('live_');

                  const audioKey = `audio_${song.id}`;
                  const jpgKey = `jpg_${song.id}`;

                  const isAudioCopied = copiedKey === audioKey;
                  const isJpgCopied = copiedKey === jpgKey;

                  // Absolute URLs
                  const fullAudioUrl = song.audioUrl.startsWith('http')
                    ? song.audioUrl
                    : `${window.location.origin}${song.audioUrl}`;
                  const fullCoverUrl = song.coverUrl || getFallbackCoverArt(song.title);

                  return (
                    <tr
                      key={song.id}
                      className={`hover:bg-[#1a1a1a] transition-colors ${
                        isSelected ? 'bg-[#222222]' : ''
                      }`}
                    >
                      {/* Checkbox */}
                      <td className="p-3 pl-4">
                        <button
                          onClick={() => toggleSelect(song.id)}
                          className="text-[#a7a7a7] hover:text-white"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-[#1db954]" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                      </td>

                      {/* Song Info (Artwork, Title, Artist, Duration) */}
                      <td className="p-3">
                        <div className="flex items-center gap-3">
                          <div className="relative group shrink-0">
                            <img
                              src={fullCoverUrl}
                              alt={song.title}
                              className="w-12 h-12 rounded-lg object-cover border border-white/10 group-hover:opacity-75 transition-opacity"
                            />
                            <button
                              onClick={() => {
                                if (isCurrent) togglePlay();
                                else playSong(song);
                              }}
                              className="absolute inset-0 flex items-center justify-center bg-black/50 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                              {isCurrent && isPlaying ? (
                                <Pause className="w-5 h-5 text-[#1db954]" />
                              ) : (
                                <Play className="w-5 h-5 text-white" />
                              )}
                            </button>
                          </div>

                          <div className="min-w-0 space-y-0.5">
                            <p className="font-bold text-white text-xs truncate max-w-xs hover:text-[#1db954] transition-colors">
                              {song.title}
                            </p>
                            <p className="text-[11px] text-[#a7a7a7] truncate max-w-xs">
                              {song.artist}
                            </p>
                            <div className="flex items-center gap-2 text-[10px] text-[#727272]">
                              <span>{formatDuration(song.duration)}</span>
                              <span>•</span>
                              <span className="bg-white/5 px-1.5 py-0.5 rounded text-[10px] text-zinc-400">
                                {song.language || 'Hindi'}
                              </span>
                              {song.quality && (
                                <span className="bg-emerald-500/10 text-emerald-400 font-mono px-1.5 py-0.5 rounded">
                                  {song.quality}
                                </span>
                              )}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Song Audio Link (Playable stream link + Copy button + Open link) */}
                      <td className="p-3">
                        <div className="bg-[#1f1f1f] p-2 rounded-xl border border-white/5 space-y-1.5 max-w-xs">
                          <div className="flex items-center justify-between gap-1 text-[11px]">
                            <span className="text-[#a7a7a7] font-mono text-[10px] truncate max-w-[170px]" title={fullAudioUrl}>
                              {song.audioUrl}
                            </span>
                            <div className="flex items-center gap-1 shrink-0">
                              {/* Copy Audio Link */}
                              <button
                                onClick={() => handleCopy(fullAudioUrl, audioKey)}
                                className={`flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-bold transition-all ${
                                  isAudioCopied
                                    ? 'bg-[#1db954] text-black'
                                    : 'bg-[#282828] text-white hover:bg-[#333333]'
                                }`}
                                title="Copy direct audio URL to clipboard"
                              >
                                {isAudioCopied ? (
                                  <>
                                    <Check className="w-3 h-3" />
                                    <span>Copied!</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-3 h-3 text-[#1db954]" />
                                    <span>Copy Audio</span>
                                  </>
                                )}
                              </button>

                              {/* Open Audio in new tab */}
                              <a
                                href={fullAudioUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="p-1 text-[#727272] hover:text-white hover:bg-white/5 rounded"
                                title="Open audio stream directly"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                            </div>
                          </div>

                          <div className="flex items-center justify-between text-[10px] text-[#727272] font-mono border-t border-white/5 pt-1">
                            <span className="text-cyan-400">Audio Stream: 320kbps</span>
                            <button
                              onClick={() => {
                                if (isCurrent) togglePlay();
                                else playSong(song);
                              }}
                              className="text-white hover:text-[#1db954] font-semibold flex items-center gap-1"
                            >
                              <Play className="w-2.5 h-2.5" />
                              <span>{isCurrent && isPlaying ? 'Playing' : 'Listen'}</span>
                            </button>
                          </div>
                        </div>
                      </td>

                      {/* Cover JPG Link (Image link + Copy button + Thumbnail link) */}
                      <td className="p-3">
                        <div className="bg-[#1f1f1f] p-2 rounded-xl border border-white/5 space-y-1.5 max-w-xs">
                          <div className="flex items-center justify-between gap-1 text-[11px]">
                            <span className="text-[#a7a7a7] font-mono text-[10px] truncate max-w-[170px]" title={fullCoverUrl}>
                              {fullCoverUrl}
                            </span>
                            <div className="flex items-center gap-1 shrink-0">
                              {/* Copy JPG Link */}
                              <button
                                onClick={() => handleCopy(fullCoverUrl, jpgKey)}
                                className={`flex items-center gap-1 px-2 py-1 rounded-md text-[10px] font-bold transition-all ${
                                  isJpgCopied
                                    ? 'bg-purple-500 text-white'
                                    : 'bg-[#282828] text-white hover:bg-[#333333]'
                                }`}
                                title="Copy 500x500 JPG cover URL to clipboard"
                              >
                                {isJpgCopied ? (
                                  <>
                                    <Check className="w-3 h-3" />
                                    <span>Copied!</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-3 h-3 text-purple-400" />
                                    <span>Copy JPG</span>
                                  </>
                                )}
                              </button>

                              {/* Open JPG in new tab */}
                              <a
                                href={fullCoverUrl}
                                target="_blank"
                                rel="noreferrer"
                                className="p-1 text-[#727272] hover:text-white hover:bg-white/5 rounded"
                                title="Open full resolution JPG image"
                              >
                                <ExternalLink className="w-3.5 h-3.5" />
                              </a>
                            </div>
                          </div>

                          <div className="flex items-center justify-between text-[10px] text-[#727272] font-mono border-t border-white/5 pt-1">
                            <span className="text-purple-400">Artwork: 500x500 JPG</span>
                            <a
                              href={fullCoverUrl}
                              target="_blank"
                              rel="noreferrer"
                              className="text-white hover:text-purple-300 font-semibold flex items-center gap-1"
                            >
                              <span>View Image</span>
                              <ExternalLink className="w-2.5 h-2.5" />
                            </a>
                          </div>
                        </div>
                      </td>

                      {/* Play Count */}
                      <td className="p-3 text-right text-white font-mono tabular-nums font-semibold">
                        {formatNumber(song.playCount || 0)}
                      </td>

                      {/* Source Badge (Database vs Live) */}
                      <td className="p-3 text-center">
                        {isLive ? (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                            <Radio className="w-3 h-3" />
                            <span>Live API</span>
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2.5 py-0.5 rounded-full bg-purple-500/10 text-purple-400 border border-purple-500/20">
                            <Database className="w-3 h-3" />
                            <span>Database</span>
                          </span>
                        )}
                      </td>

                      {/* Actions */}
                      <td className="p-3 pr-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {/* Save to DB (for live songs) */}
                          {isLive && (
                            <button
                              onClick={() => handleSaveToDb(song)}
                              disabled={savingId === song.id}
                              className="flex items-center gap-1 bg-[#282828] hover:bg-white/10 text-white px-2.5 py-1 rounded-full text-[10px] font-semibold transition-colors disabled:opacity-50"
                              title="Save this live track into Firestore Database"
                            >
                              <Database className={`w-3 h-3 text-purple-400 ${savingId === song.id ? 'animate-spin' : ''}`} />
                              <span>{savingId === song.id ? 'Saving...' : 'Save to DB'}</span>
                            </button>
                          )}

                          {/* Edit (for saved songs) */}
                          {!isLive && (
                            <button
                              onClick={() => onNavigate(`/admin/songs/${song.id}/edit`)}
                              title="Edit song metadata"
                              className="p-1.5 text-[#a7a7a7] hover:text-white rounded-lg hover:bg-white/5 transition-colors"
                            >
                              <Edit className="w-4 h-4" />
                            </button>
                          )}

                          {/* Delete */}
                          <button
                            onClick={() => setSongToDelete(song)}
                            title="Delete song"
                            className="p-1.5 text-[#a7a7a7] hover:text-red-400 rounded-lg hover:bg-white/5 transition-colors"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination Bar */}
        <div className="p-4 bg-[#181818] border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-[#a7a7a7]">
          <span>
            Showing {filteredSongs.length > 0 ? (currentPage - 1) * pageSize + 1 : 0}–
            {Math.min(filteredSongs.length, currentPage * pageSize)} of {filteredSongs.length} songs
          </span>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="px-3 py-1.5 rounded-full bg-[#282828] text-white hover:bg-[#333333] disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              Previous
            </button>
            <span className="font-mono tabular-nums text-white px-2">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="px-3 py-1.5 rounded-full bg-[#282828] text-white hover:bg-[#333333] disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            >
              Next
            </button>
          </div>
        </div>
      </div>

      {/* Delete Confirmation Modal */}
      {songToDelete && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#242424] border border-white/10 rounded-2xl p-6 max-w-sm w-full space-y-4 shadow-2xl">
            <div className="w-12 h-12 rounded-full bg-red-500/10 text-red-400 flex items-center justify-center mx-auto">
              <AlertTriangle className="w-6 h-6" />
            </div>
            <div className="text-center space-y-1">
              <h3 className="text-base font-bold text-white">Delete Track?</h3>
              <p className="text-xs text-[#a7a7a7]">
                Are you sure you want to remove <strong className="text-white">"{songToDelete.title}"</strong> by {songToDelete.artist}?
              </p>
            </div>
            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setSongToDelete(null)}
                className="px-4 py-2 rounded-full text-xs font-semibold text-white hover:bg-white/10"
              >
                Cancel
              </button>
              <button
                onClick={confirmDelete}
                className="bg-red-500 hover:bg-red-600 text-white font-bold text-xs px-5 py-2 rounded-full transition-colors"
              >
                Delete Song
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
