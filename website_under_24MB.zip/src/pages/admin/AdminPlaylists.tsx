import React, { useState, useEffect } from 'react';
import { ListMusic, Plus, Star, Globe, Lock, Trash2, X } from 'lucide-react';
import { Playlist, Song } from '../../types/music';
import { musicRepository } from '../../services/musicRepository';
import { useAuth } from '../../context/AuthContext';
import { getFallbackCoverArt } from '../../utils/format';

interface AdminPlaylistsProps {
  onNavigate: (path: string) => void;
}

export const AdminPlaylists: React.FC<AdminPlaylistsProps> = ({ onNavigate }) => {
  const { userProfile } = useAuth();
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [allSongs, setAllSongs] = useState<Song[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [coverUrl, setCoverUrl] = useState('');
  const [isFeatured, setIsFeatured] = useState(true);
  const [selectedSongIds, setSelectedSongIds] = useState<string[]>([]);

  const loadData = async () => {
    const [p, s] = await Promise.all([
      musicRepository.getPlaylists(),
      musicRepository.getSongs(true),
    ]);
    setPlaylists(p);
    setAllSongs(s);
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleToggleFeatured = async (playlist: Playlist) => {
    const nextVal = !playlist.isFeatured;
    await musicRepository.updatePlaylist(playlist.id, { isFeatured: nextVal });
    await musicRepository.recordAuditLog({
      adminId: userProfile?.uid || 'admin',
      adminEmail: userProfile?.email || 'admin@sonora.app',
      action: nextVal ? 'FEATURE_PLAYLIST' : 'UNFEATURE_PLAYLIST',
      targetEntity: 'playlist',
      targetId: playlist.id,
      details: `Updated featured status of "${playlist.title}" to ${nextVal}`,
    });
    loadData();
  };

  const handleTogglePublic = async (playlist: Playlist) => {
    const nextVal = !playlist.isPublic;
    await musicRepository.updatePlaylist(playlist.id, { isPublic: nextVal });
    loadData();
  };

  const handleDelete = async (playlist: Playlist) => {
    if (window.confirm(`Delete playlist "${playlist.title}"?`)) {
      await musicRepository.deletePlaylist(playlist.id);
      loadData();
    }
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    await musicRepository.createPlaylist({
      title: title.trim(),
      description: description.trim(),
      coverUrl: coverUrl.trim() || undefined,
      ownerId: userProfile?.uid || 'admin',
      ownerName: 'SONORA Editorial',
      songIds: selectedSongIds,
      isPublic: true,
      isFeatured,
    });

    setIsModalOpen(false);
    setTitle('');
    setDescription('');
    setCoverUrl('');
    setSelectedSongIds([]);
    loadData();
  };

  const toggleSong = (id: string) => {
    setSelectedSongIds(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Playlists</h2>
          <p className="text-xs text-[#a7a7a7]">
            Editorial playlists and featured homepage carousels
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-4 py-2 rounded-full hover:scale-105 transition-transform"
        >
          <Plus className="w-4 h-4" />
          <span>New Editorial Playlist</span>
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {playlists.map(pl => (
          <div
            key={pl.id}
            className="bg-[#181818] p-4 rounded-xl border border-white/5 flex gap-4 items-center justify-between"
          >
            <div
              onClick={() => onNavigate(`/playlists/${pl.id}`)}
              className="flex items-center gap-3 min-w-0 cursor-pointer flex-1"
            >
              <img
                src={pl.coverUrl || getFallbackCoverArt(pl.title, 'playlist')}
                alt={pl.title}
                className="w-14 h-14 rounded-lg object-cover shrink-0"
              />
              <div className="min-w-0">
                <h4 className="text-xs font-bold text-white truncate hover:underline">
                  {pl.title}
                </h4>
                <p className="text-[11px] text-[#a7a7a7] truncate">
                  {pl.songIds?.length || 0} tracks · By {pl.ownerName}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5 shrink-0">
              <button
                onClick={() => handleToggleFeatured(pl)}
                title={pl.isFeatured ? 'Featured on Home' : 'Not featured'}
                className={`p-1.5 rounded-lg border transition-colors ${
                  pl.isFeatured
                    ? 'bg-[#1db954]/20 text-[#1db954] border-[#1db954]/30'
                    : 'text-[#727272] border-white/10 hover:text-white'
                }`}
              >
                <Star className="w-4 h-4 fill-current" />
              </button>

              <button
                onClick={() => handleTogglePublic(pl)}
                title={pl.isPublic ? 'Public' : 'Private'}
                className="p-1.5 text-[#a7a7a7] hover:text-white rounded-lg border border-white/10"
              >
                {pl.isPublic ? <Globe className="w-4 h-4" /> : <Lock className="w-4 h-4" />}
              </button>

              <button
                onClick={() => handleDelete(pl)}
                className="p-1.5 text-[#a7a7a7] hover:text-red-400 rounded-lg border border-white/10"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Create Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#242424] border border-white/10 rounded-2xl p-6 max-w-lg w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-base font-bold text-white">Create Editorial Playlist</h3>
              <button onClick={() => setIsModalOpen(false)} className="text-[#a7a7a7] hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">Description</label>
                <textarea
                  value={description}
                  onChange={e => setDescription(e.target.value)}
                  rows={2}
                  className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">Cover Artwork URL</label>
                <input
                  type="url"
                  value={coverUrl}
                  onChange={e => setCoverUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
                  Add Songs ({selectedSongIds.length} selected)
                </label>
                <div className="max-h-36 overflow-y-auto bg-[#181818] border border-white/10 rounded-lg p-2 space-y-1 custom-scroll">
                  {allSongs.map(s => (
                    <label
                      key={s.id}
                      className="flex items-center gap-2 p-1.5 hover:bg-[#202020] rounded cursor-pointer text-xs text-white"
                    >
                      <input
                        type="checkbox"
                        checked={selectedSongIds.includes(s.id)}
                        onChange={() => toggleSong(s.id)}
                        className="accent-[#1db954]"
                      />
                      <span className="truncate">{s.title} · {s.artist}</span>
                    </label>
                  ))}
                </div>
              </div>

              <label className="flex items-center gap-2 cursor-pointer text-xs text-white">
                <input
                  type="checkbox"
                  checked={isFeatured}
                  onChange={e => setIsFeatured(e.target.checked)}
                  className="accent-[#1db954]"
                />
                <span>Feature on Sonora Homepage</span>
              </label>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-full text-xs font-semibold text-white hover:bg-white/10"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-5 py-2 rounded-full"
                >
                  Create Playlist
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
