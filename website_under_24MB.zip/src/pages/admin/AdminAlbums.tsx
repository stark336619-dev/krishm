import React, { useState, useEffect } from 'react';
import { Disc, Plus, Trash2, Edit2, X } from 'lucide-react';
import { Album, Song } from '../../types/music';
import { musicRepository } from '../../services/musicRepository';
import { useAuth } from '../../context/AuthContext';
import { getFallbackCoverArt } from '../../utils/format';

interface AdminAlbumsProps {
  onNavigate: (path: string) => void;
}

export const AdminAlbums: React.FC<AdminAlbumsProps> = ({ onNavigate }) => {
  const { userProfile } = useAuth();
  const [albums, setAlbums] = useState<Album[]>([]);
  const [allSongs, setAllSongs] = useState<Song[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // New Album Modal
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [releaseYear, setReleaseYear] = useState(new Date().getFullYear());
  const [genre, setGenre] = useState('Electronic');
  const [coverUrl, setCoverUrl] = useState('');
  const [selectedSongIds, setSelectedSongIds] = useState<string[]>([]);

  const loadData = async () => {
    setIsLoading(true);
    const [al, s] = await Promise.all([
      musicRepository.getAlbums(),
      musicRepository.getSongs(true),
    ]);
    setAlbums(al);
    setAllSongs(s);
    setIsLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleCreateAlbum = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !artist.trim()) return;

    await musicRepository.createAlbum({
      title: title.trim(),
      artist: artist.trim(),
      releaseYear: Number(releaseYear),
      genre,
      coverUrl: coverUrl.trim() || undefined,
      songIds: selectedSongIds,
    });

    await musicRepository.recordAuditLog({
      adminId: userProfile?.uid || 'admin',
      adminEmail: userProfile?.email || 'admin@sonora.app',
      action: 'CREATE_ALBUM',
      targetEntity: 'album',
      targetId: title,
      details: `Created album "${title}" by ${artist}`,
    });

    setIsModalOpen(false);
    setTitle('');
    setArtist('');
    setCoverUrl('');
    setSelectedSongIds([]);
    loadData();
  };

  const toggleSongSelection = (id: string) => {
    setSelectedSongIds(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Albums & EPs</h2>
          <p className="text-xs text-[#a7a7a7]">Organize tracks into full-length records</p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-4 py-2 rounded-full hover:scale-105 transition-transform"
        >
          <Plus className="w-4 h-4" />
          <span>New Album</span>
        </button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {albums.map(album => (
          <div
            key={album.id}
            onClick={() => onNavigate(`/albums/${album.id}`)}
            className="group bg-[#181818] hover:bg-[#282828] p-3.5 rounded-xl border border-white/5 cursor-pointer transition-colors relative"
          >
            <div className="aspect-square w-full rounded-lg overflow-hidden bg-[#242424] mb-3">
              <img
                src={album.coverUrl || getFallbackCoverArt(album.title, 'album')}
                alt={album.title}
                className="w-full h-full object-cover"
              />
            </div>
            <h4 className="text-xs font-bold text-white truncate">{album.title}</h4>
            <p className="text-[11px] text-[#a7a7a7] truncate">{album.artist}</p>
            <span className="text-[10px] text-[#727272]">
              {album.releaseYear} · {album.songIds?.length || 0} tracks
            </span>
          </div>
        ))}
      </div>

      {/* Create Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#242424] border border-white/10 rounded-2xl p-6 max-w-lg w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-base font-bold text-white">Create New Album</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-[#a7a7a7] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateAlbum} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
                  Album Title
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={e => setTitle(e.target.value)}
                  className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
                  required
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
                    Artist
                  </label>
                  <input
                    type="text"
                    value={artist}
                    onChange={e => setArtist(e.target.value)}
                    className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
                    required
                  />
                </div>
                <div>
                  <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
                    Release Year
                  </label>
                  <input
                    type="number"
                    value={releaseYear}
                    onChange={e => setReleaseYear(Number(e.target.value))}
                    className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
                  />
                </div>
              </div>

              <div>
                <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
                  Cover Image URL
                </label>
                <input
                  type="url"
                  value={coverUrl}
                  onChange={e => setCoverUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
                />
              </div>

              {/* Associate Songs */}
              <div>
                <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
                  Include Songs ({selectedSongIds.length} selected)
                </label>
                <div className="max-h-36 overflow-y-auto bg-[#181818] border border-white/10 rounded-lg p-2 space-y-1 custom-scroll">
                  {allSongs.map(s => (
                    <label
                      key={s.id}
                      className="flex items-center gap-2 p-1.5 hover:bg-[#202020] rounded cursor-pointer text-xs text-white"
                    >
                      <input
                        type="checkbox"
                        checked={selectedSongIds.includes(s.id)}
                        onChange={() => toggleSongSelection(s.id)}
                        className="accent-[#1db954]"
                      />
                      <span className="truncate">
                        {s.title} · {s.artist}
                      </span>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-full text-xs font-semibold text-white hover:bg-white/10"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-5 py-2 rounded-full"
                >
                  Create Album
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
