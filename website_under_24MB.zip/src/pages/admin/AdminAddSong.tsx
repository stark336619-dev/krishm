import React, { useState, useRef } from 'react';
import {
  Upload,
  Link as LinkIcon,
  Music,
  Image,
  CheckCircle2,
  AlertCircle,
  Play,
  Pause,
  ArrowLeft,
  Sparkles,
} from 'lucide-react';
import { Song, Album, Artist } from '../../types/music';
import { musicRepository } from '../../services/musicRepository';
import { useAuth } from '../../context/AuthContext';
import { formatDuration } from '../../utils/format';

interface AdminAddSongProps {
  onNavigate: (path: string) => void;
  editSongId?: string;
}

export const AdminAddSong: React.FC<AdminAddSongProps> = ({
  onNavigate,
  editSongId,
}) => {
  const { userProfile } = useAuth();

  // Form State
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [album, setAlbum] = useState('');
  const [audioUrl, setAudioUrl] = useState('');
  const [coverUrl, setCoverUrl] = useState('');
  const [duration, setDuration] = useState(0);
  const [genre, setGenre] = useState('Electronic');
  const [language, setLanguage] = useState('English');
  const [releaseDate, setReleaseDate] = useState(
    new Date().toISOString().split('T')[0]
  );
  const [lyrics, setLyrics] = useState('');
  const [description, setDescription] = useState('');
  const [isExplicit, setIsExplicit] = useState(false);
  const [isFeatured, setIsFeatured] = useState(false);
  const [isPublished, setIsPublished] = useState(true);

  // Status & Validation
  const [isSaving, setIsSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);
  const [audioTesting, setAudioTesting] = useState(false);
  const [audioTestError, setAudioTestError] = useState<string | null>(null);
  const [isPlayingTest, setIsPlayingTest] = useState(false);
  const testAudioRef = useRef<HTMLAudioElement | null>(null);

  // File Upload Handlers
  const handleAudioFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate audio file format
    const allowedTypes = ['audio/mpeg', 'audio/mp3', 'audio/wav', 'audio/aac', 'audio/ogg', 'audio/m4a', 'audio/x-m4a'];
    if (!allowedTypes.includes(file.type) && !file.name.match(/\.(mp3|wav|ogg|aac|m4a)$/i)) {
      setErrorMsg('Please select a valid audio file (MP3, WAV, AAC, M4A, or OGG).');
      return;
    }

    const objectUrl = URL.createObjectURL(file);
    setAudioUrl(objectUrl);
    setErrorMsg(null);

    // Auto extract duration
    const tempAudio = new Audio();
    tempAudio.src = objectUrl;
    tempAudio.onloadedmetadata = () => {
      setDuration(Math.round(tempAudio.duration));
    };
  };

  const handleCoverFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      setErrorMsg('Please select a valid image file (JPEG, PNG, WEBP).');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setCoverUrl(reader.result);
      }
    };
    reader.readAsDataURL(file);
  };

  // Test Direct Audio URL
  const handleVerifyAudioUrl = () => {
    if (!audioUrl.trim()) return;
    setAudioTesting(true);
    setAudioTestError(null);

    const testAudio = new Audio();
    testAudio.src = audioUrl;
    testAudio.onloadedmetadata = () => {
      setAudioTesting(false);
      setDuration(Math.round(testAudio.duration));
    };
    testAudio.onerror = () => {
      setAudioTesting(false);
      setAudioTestError('Could not verify audio stream. Verify the URL permits streaming.');
    };
  };

  const toggleTestPlayback = () => {
    if (!audioUrl) return;
    if (!testAudioRef.current) {
      testAudioRef.current = new Audio(audioUrl);
      testAudioRef.current.onended = () => setIsPlayingTest(false);
    }

    if (isPlayingTest) {
      testAudioRef.current.pause();
      setIsPlayingTest(false);
    } else {
      testAudioRef.current.src = audioUrl;
      testAudioRef.current
        .play()
        .then(() => setIsPlayingTest(true))
        .catch(e => {
          setAudioTestError('Playback blocked or unsupported format.');
          setIsPlayingTest(false);
        });
    }
  };

  const handleSubmit = async (publishState: boolean) => {
    setErrorMsg(null);
    setSuccessMsg(null);

    if (!title.trim()) {
      setErrorMsg('Song title is required.');
      return;
    }
    if (!artist.trim()) {
      setErrorMsg('Artist name is required.');
      return;
    }
    if (!audioUrl.trim()) {
      setErrorMsg('Direct audio URL or audio file upload is required.');
      return;
    }

    setIsSaving(true);
    try {
      const newSong = await musicRepository.createSong({
        title: title.trim(),
        artist: artist.trim(),
        album: album.trim() || undefined,
        audioUrl: audioUrl.trim(),
        coverUrl: coverUrl.trim() || undefined,
        duration: duration || 180,
        genre: genre.trim(),
        language: language.trim(),
        releaseDate,
        lyrics: lyrics.trim() || undefined,
        description: description.trim() || undefined,
        isExplicit,
        isFeatured,
        isPublished: publishState,
      });

      // Audit log
      await musicRepository.recordAuditLog({
        adminId: userProfile?.uid || 'admin',
        adminEmail: userProfile?.email || 'admin@sonora.app',
        action: 'ADD_SONG',
        targetEntity: 'song',
        targetId: newSong.id,
        details: `Created new song "${newSong.title}" by ${newSong.artist}`,
      });

      setSuccessMsg(`"${newSong.title}" saved successfully!`);
      setTimeout(() => {
        onNavigate('/admin/songs');
      }, 1000);
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to save song to database.');
    } finally {
      setIsSaving(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-white/5">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('/admin/songs')}
            className="p-1.5 rounded-lg bg-[#242424] hover:bg-[#303030] text-[#a7a7a7] hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">
              Add New Song
            </h2>
            <p className="text-xs text-[#a7a7a7]">
              Provide metadata and stream audio sources
            </p>
          </div>
        </div>
      </div>

      {errorMsg && (
        <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-3 bg-[#1db954]/10 border border-[#1db954]/30 rounded-xl text-[#1db954] text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      <div className="space-y-6 bg-[#181818] p-6 rounded-2xl border border-white/5">
        {/* Basic Metadata */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
              Song Title <span className="text-[#1db954]">*</span>
            </label>
            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              placeholder="e.g. Starlight Symphony"
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#1db954]"
              required
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
              Artist Name <span className="text-[#1db954]">*</span>
            </label>
            <input
              type="text"
              value={artist}
              onChange={e => setArtist(e.target.value)}
              placeholder="e.g. Aurora Sound"
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#1db954]"
              required
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
              Album Name (optional)
            </label>
            <input
              type="text"
              value={album}
              onChange={e => setAlbum(e.target.value)}
              placeholder="e.g. Odyssey 2025"
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#1db954]"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
              Genre
            </label>
            <select
              value={genre}
              onChange={e => setGenre(e.target.value)}
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#1db954]"
            >
              <option value="Electronic">Electronic</option>
              <option value="Synthwave">Synthwave</option>
              <option value="Lo-Fi Chill">Lo-Fi Chill</option>
              <option value="Neo-Soul">Neo-Soul</option>
              <option value="Indie Folk">Indie Folk</option>
              <option value="Ambient">Ambient</option>
              <option value="Hip Hop">Hip Hop</option>
              <option value="Rock">Rock</option>
              <option value="Classical">Classical</option>
              <option value="Pop">Pop</option>
            </select>
          </div>
        </div>

        {/* Audio Source Section */}
        <div className="pt-4 border-t border-white/5 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Music className="w-4 h-4 text-[#1db954]" />
                <span>Audio Source (Required)</span>
              </h3>
              <p className="text-[11px] text-[#a7a7a7]">
                Provide a direct streaming URL or upload an audio file
              </p>
            </div>

            {audioUrl && (
              <button
                type="button"
                onClick={toggleTestPlayback}
                className="flex items-center gap-1.5 px-3 py-1 bg-[#282828] hover:bg-[#333333] text-white text-xs font-medium rounded-full border border-white/10"
              >
                {isPlayingTest ? (
                  <>
                    <Pause className="w-3.5 h-3.5 text-[#1db954]" />
                    <span>Pause Preview</span>
                  </>
                ) : (
                  <>
                    <Play className="w-3.5 h-3.5 text-[#1db954]" />
                    <span>Preview Stream</span>
                  </>
                )}
              </button>
            )}
          </div>

          <div className="space-y-3">
            <div>
              <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
                Direct Audio Stream URL (MP3, WAV, AAC, OGG)
              </label>
              <div className="flex gap-2">
                <input
                  type="url"
                  value={audioUrl}
                  onChange={e => setAudioUrl(e.target.value)}
                  placeholder="https://cdn.example.com/audio/track.mp3"
                  className="flex-1 bg-[#202020] border border-white/10 rounded-lg px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-[#1db954]"
                />
                <button
                  type="button"
                  onClick={handleVerifyAudioUrl}
                  disabled={audioTesting || !audioUrl}
                  className="bg-[#282828] hover:bg-[#333333] text-white text-xs font-medium px-4 py-2.5 rounded-lg border border-white/10 whitespace-nowrap"
                >
                  {audioTesting ? 'Testing...' : 'Verify URL'}
                </button>
              </div>
              {audioTestError && (
                <p className="text-[11px] text-red-400 mt-1">{audioTestError}</p>
              )}
            </div>

            <div className="flex items-center gap-3">
              <span className="text-xs text-[#727272]">OR</span>
              <label className="cursor-pointer bg-[#202020] hover:bg-[#282828] border border-white/10 px-4 py-2 rounded-lg text-xs font-medium text-white flex items-center gap-2 transition-colors">
                <Upload className="w-3.5 h-3.5 text-[#1db954]" />
                <span>Upload Audio File</span>
                <input
                  type="file"
                  accept="audio/*"
                  onChange={handleAudioFileUpload}
                  className="hidden"
                />
              </label>
              {duration > 0 && (
                <span className="text-xs text-[#1db954] font-mono tabular-nums">
                  Duration: {formatDuration(duration)} ({duration}s)
                </span>
              )}
            </div>
          </div>
        </div>

        {/* Artwork Section */}
        <div className="pt-4 border-t border-white/5 space-y-3">
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Image className="w-4 h-4 text-purple-400" />
            <span>Album Cover Artwork (Optional)</span>
          </h3>

          <div className="flex flex-col sm:flex-row items-start gap-4">
            {coverUrl ? (
              <img
                src={coverUrl}
                alt="Cover Preview"
                className="w-24 h-24 rounded-lg object-cover border border-white/10 shrink-0"
              />
            ) : (
              <div className="w-24 h-24 rounded-lg bg-[#202020] border border-white/10 flex items-center justify-center text-[#727272] shrink-0">
                <Image className="w-8 h-8 opacity-40" />
              </div>
            )}

            <div className="flex-1 w-full space-y-2">
              <input
                type="url"
                value={coverUrl}
                onChange={e => setCoverUrl(e.target.value)}
                placeholder="https://example.com/cover.jpg"
                className="w-full bg-[#202020] border border-white/10 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
              />
              <label className="inline-flex cursor-pointer bg-[#202020] hover:bg-[#282828] border border-white/10 px-3 py-1.5 rounded-lg text-xs font-medium text-white items-center gap-2 transition-colors">
                <Upload className="w-3 h-3 text-[#1db954]" />
                <span>Upload Image File</span>
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleCoverFileUpload}
                  className="hidden"
                />
              </label>
            </div>
          </div>
        </div>

        {/* Additional Settings */}
        <div className="pt-4 border-t border-white/5 grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
              Language
            </label>
            <input
              type="text"
              value={language}
              onChange={e => setLanguage(e.target.value)}
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
              Release Date
            </label>
            <input
              type="date"
              value={releaseDate}
              onChange={e => setReleaseDate(e.target.value)}
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
            />
          </div>

          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
              Duration (seconds)
            </label>
            <input
              type="number"
              value={duration}
              onChange={e => setDuration(Number(e.target.value))}
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3 py-2 text-xs text-white font-mono tabular-nums focus:outline-none focus:border-[#1db954]"
            />
          </div>
        </div>

        {/* Toggles */}
        <div className="pt-4 border-t border-white/5 flex flex-wrap items-center gap-6">
          <label className="flex items-center gap-2 cursor-pointer text-xs text-white">
            <input
              type="checkbox"
              checked={isExplicit}
              onChange={e => setIsExplicit(e.target.checked)}
              className="w-4 h-4 accent-[#1db954] rounded"
            />
            <span>Explicit Content (18+)</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer text-xs text-white">
            <input
              type="checkbox"
              checked={isFeatured}
              onChange={e => setIsFeatured(e.target.checked)}
              className="w-4 h-4 accent-[#1db954] rounded"
            />
            <span>Feature on Homepage Spotlight</span>
          </label>

          <label className="flex items-center gap-2 cursor-pointer text-xs text-white">
            <input
              type="checkbox"
              checked={isPublished}
              onChange={e => setIsPublished(e.target.checked)}
              className="w-4 h-4 accent-[#1db954] rounded"
            />
            <span>Publish Immediately (Publicly Visible)</span>
          </label>
        </div>

        {/* Lyrics */}
        <div className="pt-4 border-t border-white/5 space-y-1">
          <label className="text-xs font-semibold text-[#a7a7a7] block">
            Lyrics (Optional)
          </label>
          <textarea
            value={lyrics}
            onChange={e => setLyrics(e.target.value)}
            rows={4}
            placeholder="Enter song lyrics..."
            className="w-full bg-[#202020] border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-[#1db954] font-mono leading-relaxed"
          />
        </div>

        {/* Action Buttons */}
        <div className="pt-4 border-t border-white/5 flex items-center justify-end gap-3">
          <button
            type="button"
            onClick={() => onNavigate('/admin/songs')}
            className="px-5 py-2.5 rounded-full text-xs font-semibold text-white hover:bg-white/10 transition-colors"
          >
            Cancel
          </button>

          <button
            type="button"
            onClick={() => handleSubmit(false)}
            disabled={isSaving}
            className="px-5 py-2.5 rounded-full text-xs font-semibold bg-[#282828] text-white hover:bg-[#333333] border border-white/10 transition-colors disabled:opacity-50"
          >
            Save as Draft
          </button>

          <button
            type="button"
            onClick={() => handleSubmit(true)}
            disabled={isSaving}
            className="px-6 py-2.5 rounded-full text-xs font-bold bg-[#1db954] hover:bg-[#1ed760] text-black hover:scale-105 active:scale-95 transition-all shadow-lg shadow-[#1db954]/20 disabled:opacity-50"
          >
            {isSaving ? 'Saving Track...' : 'Publish Song'}
          </button>
        </div>
      </div>
    </div>
  );
};
