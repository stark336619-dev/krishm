import React, { useState, useEffect } from 'react';
import { Mic2, Plus, X, CheckCircle2 } from 'lucide-react';
import { Artist } from '../../types/music';
import { musicRepository } from '../../services/musicRepository';
import { useAuth } from '../../context/AuthContext';
import { formatNumber, getFallbackCoverArt } from '../../utils/format';

interface AdminArtistsProps {
  onNavigate: (path: string) => void;
}

export const AdminArtists: React.FC<AdminArtistsProps> = ({ onNavigate }) => {
  const { userProfile } = useAuth();
  const [artists, setArtists] = useState<Artist[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [name, setName] = useState('');
  const [photoUrl, setPhotoUrl] = useState('');
  const [genres, setGenres] = useState('Electronic, Synthwave');
  const [monthlyListeners, setMonthlyListeners] = useState(75000);
  const [bio, setBio] = useState('');
  const [isVerified, setIsVerified] = useState(true);

  const loadArtists = async () => {
    const data = await musicRepository.getArtists();
    setArtists(data);
  };

  useEffect(() => {
    loadArtists();
  }, []);

  const handleCreateArtist = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    await musicRepository.createArtist({
      name: name.trim(),
      photoUrl: photoUrl.trim() || undefined,
      genres: genres.split(',').map(g => g.trim()),
      monthlyListeners: Number(monthlyListeners),
      bio: bio.trim() || undefined,
      isVerified,
    });

    await musicRepository.recordAuditLog({
      adminId: userProfile?.uid || 'admin',
      adminEmail: userProfile?.email || 'admin@sonora.app',
      action: 'CREATE_ARTIST',
      targetEntity: 'artist',
      targetId: name,
      details: `Added new artist "${name}"`,
    });

    setIsModalOpen(false);
    setName('');
    setPhotoUrl('');
    setBio('');
    loadArtists();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Artists</h2>
          <p className="text-xs text-[#a7a7a7]">Manage performer profiles and verified creators</p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-4 py-2 rounded-full hover:scale-105 transition-transform"
        >
          <Plus className="w-4 h-4" />
          <span>New Artist</span>
        </button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {artists.map(artist => (
          <div
            key={artist.id}
            onClick={() => onNavigate(`/artists/${artist.id}`)}
            className="group bg-[#181818] hover:bg-[#282828] p-4 rounded-xl border border-white/5 cursor-pointer transition-colors text-center"
          >
            <div className="aspect-square w-24 h-24 mx-auto rounded-full overflow-hidden bg-[#242424] mb-3">
              <img
                src={artist.photoUrl || getFallbackCoverArt(artist.name, 'artist')}
                alt={artist.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="flex items-center justify-center gap-1">
              <h4 className="text-xs font-bold text-white truncate">{artist.name}</h4>
              {artist.isVerified && (
                <CheckCircle2 className="w-3 h-3 text-[#1db954] fill-[#1db954] shrink-0" />
              )}
            </div>
            <span className="text-[10px] text-[#727272] tabular-nums font-mono block mt-1">
              {formatNumber(artist.monthlyListeners || 0)} listeners
            </span>
          </div>
        ))}
      </div>

      {/* Create Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/75 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#242424] border border-white/10 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between pb-3 border-b border-white/10">
              <h3 className="text-base font-bold text-white">Create Artist</h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-[#a7a7a7] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleCreateArtist} className="space-y-4">
              <div>
                <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
                  Artist Name
                </label>
                <input
                  type="text"
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
                  Photo URL
                </label>
                <input
                  type="url"
                  value={photoUrl}
                  onChange={e => setPhotoUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
                  Genres (comma-separated)
                </label>
                <input
                  type="text"
                  value={genres}
                  onChange={e => setGenres(e.target.value)}
                  className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
                  Biography
                </label>
                <textarea
                  value={bio}
                  onChange={e => setBio(e.target.value)}
                  rows={3}
                  className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 rounded-full text-xs font-semibold text-white hover:bg-white/10"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-5 py-2 rounded-full"
                >
                  Save Artist
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
