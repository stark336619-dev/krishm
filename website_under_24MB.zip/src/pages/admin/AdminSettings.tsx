import React, { useState, useEffect } from 'react';
import {
  Settings,
  Shield,
  Trash2,
  Sparkles,
  RefreshCw,
  AlertTriangle,
  Check,
  Copy,
  ExternalLink,
  Key,
  Globe,
  Lock,
  CheckCircle2,
} from 'lucide-react';
import { AdminAuditLog } from '../../types/music';
import { musicRepository } from '../../services/musicRepository';
import { useAuth } from '../../context/AuthContext';
import { formatTimeAgo } from '../../utils/format';

interface AdminSettingsProps {
  brandName: string;
  onBrandNameChange: (name: string) => void;
  onNavigate: (path: string) => void;
}

export const AdminSettings: React.FC<AdminSettingsProps> = ({
  brandName,
  onBrandNameChange,
  onNavigate,
}) => {
  const { userProfile } = useAuth();
  const [logs, setLogs] = useState<AdminAuditLog[]>([]);
  const [nameInput, setNameInput] = useState(brandName);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);

  // Spotify Configuration State
  const [spotifyConfig, setSpotifyConfig] = useState<{
    configured: boolean;
    hasClientSecret: boolean;
    clientId: string | null;
    rawClientId: string | null;
    appUrl: string;
    sharedAppUrl: string;
    exactCallbackUrls: {
      primaryDev: string;
      primaryShared: string;
      aliasDev: string;
      aliasShared: string;
    };
  } | null>(null);

  const [websiteUrlData, setWebsiteUrlData] = useState<{
    customWebsiteUrl: string | null;
    appUrl: string;
    sharedAppUrl: string;
    firebaseAppUrl: string;
    firebaseWebUrl: string;
    activeUrl: string;
    callbackUrl: string;
  } | null>(null);
  const [websiteUrlInput, setWebsiteUrlInput] = useState('');
  const [isSavingUrl, setIsSavingUrl] = useState(false);

  const [inputClientId, setInputClientId] = useState('');
  const [inputClientSecret, setInputClientSecret] = useState('');
  const [isSavingSpotify, setIsSavingSpotify] = useState(false);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const loadWebsiteUrl = async () => {
    try {
      const res = await fetch('/api/website/url');
      if (res.ok) {
        const data = await res.json();
        setWebsiteUrlData(data);
        if (data.customWebsiteUrl) {
          setWebsiteUrlInput(data.customWebsiteUrl);
        } else if (data.activeUrl) {
          setWebsiteUrlInput(data.activeUrl);
        }
      }
    } catch (err) {
      console.warn('Failed to load website URL:', err);
    }
  };

  const handleSaveWebsiteUrl = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSavingUrl(true);
    try {
      const res = await fetch('/api/website/url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: websiteUrlInput.trim() }),
      });
      const data = await res.json();
      if (res.ok) {
        setStatusMsg(data.message || 'Website URL updated successfully.');
        await loadWebsiteUrl();
        await loadSpotifyConfig();
      } else {
        alert(data.error || 'Failed to update website URL.');
      }
    } catch (err: any) {
      alert(err?.message || 'Error updating website URL.');
    } finally {
      setIsSavingUrl(false);
      setTimeout(() => setStatusMsg(null), 3500);
    }
  };

  const handleResetWebsiteUrl = async () => {
    setIsSavingUrl(true);
    try {
      const res = await fetch('/api/website/url', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: '' }),
      });
      const data = await res.json();
      if (res.ok) {
        setStatusMsg('Website URL reset to default.');
        setWebsiteUrlInput('');
        await loadWebsiteUrl();
        await loadSpotifyConfig();
      }
    } catch (err: any) {
      console.warn(err);
    } finally {
      setIsSavingUrl(false);
      setTimeout(() => setStatusMsg(null), 3000);
    }
  };

  const loadSpotifyConfig = async () => {
    try {
      const res = await fetch('/api/spotify/config');
      if (res.ok) {
        const data = await res.json();
        setSpotifyConfig(data);
        if (data.rawClientId) {
          setInputClientId(data.rawClientId);
        }
      }
    } catch (err) {
      console.warn('Failed to load Spotify configuration:', err);
    }
  };

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(label);
    setStatusMsg(`Copied ${label} to clipboard!`);
    setTimeout(() => {
      setCopiedKey(null);
      setStatusMsg(null);
    }, 2500);
  };

  const handleSaveSpotify = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputClientId.trim()) {
      alert('Please enter a Spotify Client ID.');
      return;
    }
    setIsSavingSpotify(true);
    try {
      const res = await fetch('/api/spotify/configure', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          clientId: inputClientId.trim(),
          clientSecret: inputClientSecret.trim(),
        }),
      });
      if (res.ok) {
        setStatusMsg('Spotify credentials updated securely on server.');
        setInputClientSecret('');
        await loadSpotifyConfig();
      } else {
        const data = await res.json();
        alert(data.error || 'Failed to update Spotify credentials.');
      }
    } catch (err: any) {
      alert(err?.message || 'Error communicating with server.');
    } finally {
      setIsSavingSpotify(false);
      setTimeout(() => setStatusMsg(null), 3000);
    }
  };

  const loadLogs = async () => {
    const data = await musicRepository.getAdminAuditLogs();
    setLogs(data);
  };

  useEffect(() => {
    loadLogs();
    loadSpotifyConfig();
    loadWebsiteUrl();
  }, []);

  const handleSaveBrand = (e: React.FormEvent) => {
    e.preventDefault();
    if (!nameInput.trim()) return;
    onBrandNameChange(nameInput.trim());
    setStatusMsg('Brand name updated.');
    setTimeout(() => setStatusMsg(null), 2000);
  };

  const handleClearCatalog = async () => {
    if (
      window.confirm(
        'WARNING: This will wipe all songs, albums, and playlists from the local database to simulate an empty catalog. Proceed?'
      )
    ) {
      await musicRepository.clearAllCatalog();
      await musicRepository.recordAuditLog({
        adminId: userProfile?.uid || 'admin',
        adminEmail: userProfile?.email || 'admin@sonora.app',
        action: 'CLEAR_CATALOG',
        targetEntity: 'system',
        targetId: 'all',
        details: 'Emptied all songs, albums, and playlists from catalog',
      });
      setStatusMsg('Catalog wiped. All collections are now empty.');
      loadLogs();
    }
  };

  const handleSeed = async () => {
    await musicRepository.seedDemoTracks();
    await musicRepository.recordAuditLog({
      adminId: userProfile?.uid || 'admin',
      adminEmail: userProfile?.email || 'admin@sonora.app',
      action: 'SEED_DEMO_CATALOG',
      targetEntity: 'system',
      targetId: 'demo_pack',
      details: 'Restored sample royalty-free tracks and playlist',
    });
    setStatusMsg('Sample tracks seeded successfully.');
    loadLogs();
  };

  return (
    <div className="max-w-3xl space-y-8">
      <div>
        <h2 className="text-xl font-bold text-white tracking-tight">Platform Settings</h2>
        <p className="text-xs text-[#a7a7a7]">
          Branding, security configurations, and administrative audit trails
        </p>
      </div>

      {statusMsg && (
        <div className="p-3 bg-[#1db954]/10 border border-[#1db954]/30 rounded-xl text-[#1db954] text-xs flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>{statusMsg}</span>
        </div>
      )}

      {/* Platform Branding */}
      <div className="bg-[#181818] p-6 rounded-2xl border border-white/5 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Settings className="w-4 h-4 text-[#1db954]" />
          <span>Platform Branding</span>
        </h3>
        <form onSubmit={handleSaveBrand} className="flex gap-3 max-w-md">
          <input
            type="text"
            value={nameInput}
            onChange={e => setNameInput(e.target.value)}
            className="flex-1 bg-[#202020] border border-white/10 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
            placeholder="Platform Name (e.g. SONORA)"
          />
          <button
            type="submit"
            className="bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-5 py-2 rounded-lg transition-colors"
          >
            Update
          </button>
        </form>
      </div>

      {/* Website URL & Custom Domain Configuration */}
      <div className="bg-[#181818] p-6 rounded-2xl border border-white/5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-[#1db954]/20 flex items-center justify-center text-[#1db954]">
              <Globe className="w-3.5 h-3.5" />
            </div>
            <h3 className="text-sm font-bold text-white">Website Public URL & Custom Domain</h3>
          </div>
          <span className="text-[10px] bg-[#1db954]/10 text-[#1db954] font-semibold px-2 py-0.5 rounded-full border border-[#1db954]/30">
            {websiteUrlData?.customWebsiteUrl ? 'Custom Domain Active' : 'Default Firebase Domain'}
          </span>
        </div>

        <p className="text-xs text-[#a7a7a7]">
          Change the public website URL or set a custom domain for your music app. All OAuth redirects, social sharing links, and callbacks adapt dynamically.
        </p>

        {/* Current Active URL card */}
        <div className="bg-[#202020] p-3.5 rounded-xl border border-white/5 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] text-[#727272] uppercase font-mono tracking-wider">Current Active Website URL</span>
            {websiteUrlData?.activeUrl && (
              <a
                href={websiteUrlData.activeUrl}
                target="_blank"
                rel="noreferrer"
                className="text-[11px] text-[#1db954] hover:underline flex items-center gap-1"
              >
                <span>Open Website</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            )}
          </div>
          <div className="flex items-center justify-between bg-[#141414] px-3 py-2 rounded-lg border border-white/10">
            <span className="text-white font-mono text-xs select-all">
              {websiteUrlData?.activeUrl || 'https://methodical-hall-7bcxw.firebaseapp.com'}
            </span>
            <button
              type="button"
              onClick={() => copyToClipboard(websiteUrlData?.activeUrl || 'https://methodical-hall-7bcxw.firebaseapp.com', 'Website URL')}
              className="text-[#1db954] hover:text-[#1ed760] text-xs font-semibold px-2 py-1"
            >
              {copiedKey === 'Website URL' ? 'Copied!' : 'Copy'}
            </button>
          </div>
        </div>

        {/* Change URL Form */}
        <form onSubmit={handleSaveWebsiteUrl} className="space-y-3 pt-1">
          <label className="block text-xs font-semibold text-white">
            Set New Website URL or Custom Domain
          </label>
          <div className="flex flex-col sm:flex-row gap-2">
            <input
              type="text"
              value={websiteUrlInput}
              onChange={e => setWebsiteUrlInput(e.target.value)}
              className="flex-1 bg-[#202020] border border-white/10 rounded-lg px-3.5 py-2 text-xs text-white focus:outline-none focus:border-[#1db954] font-mono"
              placeholder="e.g. https://mymusic.com or https://new-app.web.app"
            />
            <div className="flex gap-2">
              <button
                type="submit"
                disabled={isSavingUrl}
                className="bg-[#1db954] hover:bg-[#1ed760] disabled:opacity-50 text-black font-bold text-xs px-5 py-2 rounded-lg transition-colors flex items-center gap-1.5"
              >
                {isSavingUrl ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    <span>Saving…</span>
                  </>
                ) : (
                  <span>Save URL</span>
                )}
              </button>
              {websiteUrlData?.customWebsiteUrl && (
                <button
                  type="button"
                  onClick={handleResetWebsiteUrl}
                  disabled={isSavingUrl}
                  className="bg-[#282828] hover:bg-[#333] text-[#a7a7a7] hover:text-white text-xs px-3 py-2 rounded-lg border border-white/10 transition-colors"
                >
                  Reset Default
                </button>
              )}
            </div>
          </div>
          <p className="text-[11px] text-[#727272]">
            Enter your custom domain (e.g. <code>https://yourdomain.com</code>) or new hosting URL.
          </p>
        </form>

        {/* Instructions */}
        <div className="bg-[#1c1c1c] p-3.5 rounded-xl border border-white/5 space-y-2 text-xs">
          <span className="font-semibold text-white block">How to connect a Custom Domain in Firebase Hosting:</span>
          <ol className="list-decimal list-inside space-y-1 text-[#a7a7a7] text-[11px] leading-relaxed">
            <li>Go to <a href="https://console.firebase.google.com/" target="_blank" rel="noreferrer" className="text-[#1db954] hover:underline">Firebase Console</a> &rarr; Select project <strong>methodical-hall-7bcxw</strong>.</li>
            <li>In the left menu, click <strong>Hosting</strong> &rarr; click <strong>Add custom domain</strong>.</li>
            <li>Type your custom domain (e.g., <code>mymusic.com</code> or <code>music.yourdomain.com</code>).</li>
            <li>Copy the DNS TXT and A records provided by Firebase into your domain registrar (GoDaddy, Cloudflare, Namecheap, etc.).</li>
            <li>In Firebase Console &rarr; <strong>Authentication</strong> &rarr; <strong>Settings</strong> &rarr; <strong>Authorized domains</strong>, click <strong>Add domain</strong> and enter your custom domain.</li>
            <li>Enter your custom domain above and click <strong>Save URL</strong> to update the app.</li>
          </ol>
        </div>
      </div>

      {/* Active Music Discovery & Streaming Providers */}
      <div className="bg-[#181818] p-6 rounded-2xl border border-white/5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-5 h-5 rounded-full bg-[#1ed760]/20 flex items-center justify-center text-[#1ed760]">
              <Sparkles className="w-3.5 h-3.5" />
            </div>
            <h3 className="text-sm font-bold text-white">Music Streaming & Discovery Engines</h3>
          </div>
          <span className="text-[10px] bg-[#1ed760]/10 text-[#1ed760] font-semibold px-2 py-0.5 rounded-full border border-[#1ed760]/30">
            Multi-Provider Architecture
          </span>
        </div>
        <p className="text-xs text-[#a7a7a7]">
          SONORA automatically discovers and plays songs across authorized engines with zero manual track entry required.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
          <div className="bg-[#202020] p-3.5 rounded-xl border border-white/5 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#1ed760] animate-pulse" />
                STERNITERS 320kbps Lossless
              </span>
              <span className="text-[10px] text-[#1ed760] font-mono">Full Audio & Lyrics</span>
            </div>
            <p className="text-[11px] text-[#808080] leading-relaxed">
              JioSaavn high-fidelity engine delivering full-length CD playback, byte-range seeking, synchronized lyrics, and direct offline MP3 downloads for Gujarati, Hindi, Punjabi, and Bollywood catalogs.
            </p>
          </div>

          <div className="bg-[#202020] p-3.5 rounded-xl border border-white/5 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#1ed760]" />
                Regional & Multi-Language Catalog
              </span>
              <span className="text-[10px] text-[#a7a7a7] font-mono">Apple Music API</span>
            </div>
            <p className="text-[11px] text-[#808080] leading-relaxed">
              Live official multi-language search and trending charts covering Tamil, Telugu, Marathi, Bengali, and English releases.
            </p>
          </div>

          <div className="bg-[#202020] p-3.5 rounded-xl border border-white/5 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-[#1ed760]" />
                Jamendo Creative Commons
              </span>
              <span className="text-[10px] text-[#a7a7a7] font-mono">CC-Licensed</span>
            </div>
            <p className="text-[11px] text-[#808080] leading-relaxed">
              Direct legal playback and discovery for independent global artists, EDM, chill, and acoustic tracks.
            </p>
          </div>

          <div className="bg-[#202020] p-3.5 rounded-xl border border-white/5 space-y-1.5">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-white flex items-center gap-1.5">
                <span className={`w-2 h-2 rounded-full ${spotifyConfig?.configured ? 'bg-[#1ed760]' : 'bg-amber-400'}`} />
                Spotify Developer Web API
              </span>
              <span className="text-[10px] text-[#a7a7a7] font-mono">
                {spotifyConfig?.configured ? 'Configured' : 'Needs Client Secret'}
              </span>
            </div>
            <p className="text-[11px] text-[#808080] leading-relaxed">
              Official Spotify Web API with PKCE OAuth flow for playlist syncing, artist metadata, and official destination links.
            </p>
          </div>
        </div>
      </div>

      {/* Spotify OAuth & Provider Integration */}
      <div className="bg-[#181818] p-6 rounded-2xl border border-white/5 space-y-6">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-5 h-5 rounded-full bg-[#1db954]/20 flex items-center justify-center text-[#1db954]">
                <Globe className="w-3.5 h-3.5" />
              </div>
              <h3 className="text-sm font-bold text-white">
                Spotify Web API & PKCE OAuth Configuration
              </h3>
            </div>
            <p className="text-xs text-[#a7a7a7] mt-1">
              Enable Spotify music catalog discovery, track metadata, user library sync, and official playback embeds.
            </p>
          </div>

          <span
            className={`text-[10px] font-semibold px-2.5 py-1 rounded-full border ${
              spotifyConfig?.configured
                ? 'bg-[#1db954]/10 text-[#1db954] border-[#1db954]/30'
                : 'bg-amber-500/10 text-amber-400 border-amber-500/30'
            }`}
          >
            {spotifyConfig?.configured ? 'Configured & Active' : 'Credentials Needed'}
          </span>
        </div>

        {/* Exact Redirect URIs for Spotify Dashboard */}
        <div className="bg-[#141414] border border-white/5 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold text-white flex items-center gap-1.5">
              <Key className="w-3.5 h-3.5 text-[#1db954]" />
              <span>Exact Callback / Redirect URIs</span>
            </span>
            <a
              href="https://developer.spotify.com/dashboard"
              target="_blank"
              rel="noreferrer"
              className="text-[11px] text-[#1db954] hover:underline flex items-center gap-1"
            >
              <span>Spotify Developer Dashboard</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
          <p className="text-[11px] text-[#727272]">
            Copy and add these exact Redirect URIs in your Spotify Application Settings. Do not use localhost or placeholder domains.
          </p>

          <div className="space-y-2">
            {/* Primary Firebase Production Callback URL */}
            <div className="flex items-center justify-between bg-[#1f1f1f] px-3 py-2.5 rounded-lg border border-[#1db954]/20 text-xs shadow-sm">
              <div className="min-w-0 pr-2">
                <div className="flex items-center gap-1.5 mb-0.5">
                  <span className="text-[10px] text-[#1db954] uppercase font-mono tracking-wider font-semibold">
                    Production Firebase Redirect URI
                  </span>
                  <span className="text-[9px] bg-[#1db954]/20 text-[#1db954] px-1.5 py-0.2 rounded font-semibold">
                    Primary
                  </span>
                </div>
                <span className="text-white font-mono text-[11px] truncate block select-all">
                  https://methodical-hall-7bcxw.firebaseapp.com/api/spotify/callback
                </span>
              </div>
              <button
                type="button"
                onClick={() =>
                  copyToClipboard(
                    'https://methodical-hall-7bcxw.firebaseapp.com/api/spotify/callback',
                    'Firebase Callback URL'
                  )
                }
                className="shrink-0 flex items-center gap-1 bg-[#1db954] hover:bg-[#1ed760] text-black text-[10px] font-bold px-3 py-1 rounded transition-colors"
              >
                {copiedKey === 'Firebase Callback URL' ? (
                  <>
                    <CheckCircle2 className="w-3 h-3 text-black" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3 text-black" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            {/* Primary Dev URL */}
            <div className="flex items-center justify-between bg-[#1f1f1f] px-3 py-2 rounded-lg border border-white/5 text-xs">
              <div className="min-w-0 pr-2">
                <span className="text-[10px] text-[#a7a7a7] block uppercase font-mono tracking-wider">
                  Development Preview Redirect URI
                </span>
                <span className="text-white font-mono text-[11px] truncate block select-all">
                  {spotifyConfig?.exactCallbackUrls.primaryDev ||
                    'https://ais-dev-byohvlvcbj7hdw36uzskbf-225291614794.asia-southeast1.run.app/api/spotify/callback'}
                </span>
              </div>
              <button
                type="button"
                onClick={() =>
                  copyToClipboard(
                    spotifyConfig?.exactCallbackUrls.primaryDev ||
                      'https://ais-dev-byohvlvcbj7hdw36uzskbf-225291614794.asia-southeast1.run.app/api/spotify/callback',
                    'Dev Callback URL'
                  )
                }
                className="shrink-0 flex items-center gap-1 bg-[#282828] hover:bg-[#333333] text-white text-[10px] font-semibold px-2.5 py-1 rounded border border-white/10 transition-colors"
              >
                {copiedKey === 'Dev Callback URL' ? (
                  <>
                    <CheckCircle2 className="w-3 h-3 text-[#1db954]" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3 text-[#a7a7a7]" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>

            {/* Shared Deployed URL */}
            <div className="flex items-center justify-between bg-[#1f1f1f] px-3 py-2 rounded-lg border border-white/5 text-xs">
              <div className="min-w-0 pr-2">
                <span className="text-[10px] text-[#a7a7a7] block uppercase font-mono tracking-wider">
                  Shared Deployed Redirect URI
                </span>
                <span className="text-white font-mono text-[11px] truncate block select-all">
                  {spotifyConfig?.exactCallbackUrls.primaryShared ||
                    'https://ais-pre-byohvlvcbj7hdw36uzskbf-225291614794.asia-southeast1.run.app/api/spotify/callback'}
                </span>
              </div>
              <button
                type="button"
                onClick={() =>
                  copyToClipboard(
                    spotifyConfig?.exactCallbackUrls.primaryShared ||
                      'https://ais-pre-byohvlvcbj7hdw36uzskbf-225291614794.asia-southeast1.run.app/api/spotify/callback',
                    'Shared Callback URL'
                  )
                }
                className="shrink-0 flex items-center gap-1 bg-[#282828] hover:bg-[#333333] text-white text-[10px] font-semibold px-2.5 py-1 rounded border border-white/10 transition-colors"
              >
                {copiedKey === 'Shared Callback URL' ? (
                  <>
                    <CheckCircle2 className="w-3 h-3 text-[#1db954]" />
                    <span>Copied!</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3 h-3 text-[#a7a7a7]" />
                    <span>Copy</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>

        {/* Credentials Form */}
        <form onSubmit={handleSaveSpotify} className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-white block">
              Spotify Client ID
            </label>
            <input
              type="text"
              value={inputClientId}
              onChange={e => setInputClientId(e.target.value)}
              placeholder="e.g. 7a8b9c0d1e2f3a4b..."
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3.5 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#1db954]"
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <label className="text-xs font-semibold text-white block">
                Spotify Client Secret
              </label>
              <span className="text-[10px] text-[#727272] flex items-center gap-1">
                <Lock className="w-3 h-3 text-[#1db954]" />
                <span>Encrypted on backend only</span>
              </span>
            </div>
            <input
              type="password"
              value={inputClientSecret}
              onChange={e => setInputClientSecret(e.target.value)}
              placeholder={
                spotifyConfig?.hasClientSecret
                  ? '•••••••••••••••• (Secret safely configured on backend)'
                  : 'Enter client secret'
              }
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3.5 py-2 text-xs text-white font-mono focus:outline-none focus:border-[#1db954]"
            />
            <p className="text-[11px] text-[#727272]">
              Client Secret is never sent to or visible in client-side code. It is securely utilized on server-side proxy routes for confidential token exchange.
            </p>
          </div>

          <div className="flex items-center gap-3 pt-1">
            <button
              type="submit"
              disabled={isSavingSpotify}
              className="bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-5 py-2 rounded-lg transition-colors disabled:opacity-50"
            >
              {isSavingSpotify ? 'Saving...' : 'Save Spotify Credentials'}
            </button>
          </div>
        </form>

        {/* Step-by-Step Instructions */}
        <div className="bg-[#141414] border border-white/5 rounded-xl p-4 space-y-2">
          <h4 className="text-xs font-bold text-white">
            Spotify Developer Dashboard Instructions:
          </h4>
          <ol className="text-xs text-[#a7a7a7] space-y-1.5 list-decimal list-inside leading-relaxed">
            <li>
              Open{' '}
              <a
                href="https://developer.spotify.com/dashboard"
                target="_blank"
                rel="noreferrer"
                className="text-[#1db954] underline inline-flex items-center gap-0.5"
              >
                Spotify Developer Dashboard <ExternalLink className="w-3 h-3 inline" />
              </a>{' '}
              and sign in with your Spotify account.
            </li>
            <li>
              Click <strong className="text-white">Create app</strong>. Set App name to <span className="text-white font-mono">SONORA</span> and select <strong className="text-white">Web API</strong>.
            </li>
            <li>
              In your app settings, click <strong className="text-white">Settings</strong>, scroll to <strong className="text-white">Redirect URIs</strong>, paste the Development & Shared Callback URLs copied above, and click <strong className="text-white">Add</strong> then <strong className="text-white">Save</strong>.
            </li>
            <li>
              Copy your <strong className="text-white">Client ID</strong> and <strong className="text-white">Client Secret</strong>, paste them into the form above, and click <strong className="text-white">Save Spotify Credentials</strong>.
            </li>
          </ol>
        </div>
      </div>

      {/* Database Maintenance Tools */}
      <div className="bg-[#181818] p-6 rounded-2xl border border-white/5 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <RefreshCw className="w-4 h-4 text-amber-400" />
          <span>Database & Testing Tools</span>
        </h3>
        <p className="text-xs text-[#a7a7a7] leading-relaxed">
          Quickly toggle between a clean empty database state (to verify zero-state screens and manual track additions) or reload the royalty-free demonstration catalog.
        </p>

        <div className="flex flex-wrap gap-3 pt-2">
          <button
            onClick={handleSeed}
            className="flex items-center gap-2 bg-[#282828] hover:bg-[#333333] text-white font-medium text-xs px-4 py-2 rounded-lg border border-white/10 transition-colors"
          >
            <Sparkles className="w-4 h-4 text-[#1db954]" />
            <span>Load Sample Catalog</span>
          </button>

          <button
            onClick={handleClearCatalog}
            className="flex items-center gap-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 font-medium text-xs px-4 py-2 rounded-lg border border-red-500/20 transition-colors"
          >
            <Trash2 className="w-4 h-4" />
            <span>Wipe Catalog (Test Empty State)</span>
          </button>
        </div>
      </div>

      {/* Audit Logs */}
      <div className="bg-[#181818] p-6 rounded-2xl border border-white/5 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Shield className="w-4 h-4 text-blue-400" />
          <span>Administrative Audit Logs</span>
        </h3>
        <p className="text-xs text-[#a7a7a7]">
          Immutable log of privileged administrator actions and catalogue updates
        </p>

        {logs.length === 0 ? (
          <p className="text-xs text-[#727272] py-4 text-center italic">
            No audit events recorded yet.
          </p>
        ) : (
          <div className="divide-y divide-white/5 max-h-72 overflow-y-auto custom-scroll">
            {logs.map(log => (
              <div key={log.id} className="py-2.5 flex items-center justify-between text-xs">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-semibold text-white font-mono text-[11px] bg-[#242424] px-2 py-0.5 rounded">
                      {log.action}
                    </span>
                    <span className="text-[#a7a7a7]">{log.details}</span>
                  </div>
                  <span className="text-[10px] text-[#727272] block mt-0.5">
                    By {log.adminEmail}
                  </span>
                </div>
                <span className="text-[11px] text-[#727272] shrink-0 font-mono">
                  {formatTimeAgo(log.timestamp)}
                </span>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
