import React from 'react';
import {
  ShieldAlert,
  LayoutDashboard,
  Music,
  PlusCircle,
  Disc,
  Mic2,
  ListMusic,
  Users,
  BarChart3,
  Settings,
  ArrowLeft,
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface AdminLayoutProps {
  currentPath: string;
  onNavigate: (path: string) => void;
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  currentPath,
  onNavigate,
  children,
}) => {
  const { isAdmin, simulateAdminLogin } = useAuth();

  if (!isAdmin) {
    return (
      <div className="p-12 text-center max-w-lg mx-auto space-y-4 my-12">
        <div className="w-16 h-16 rounded-full bg-red-500/10 text-red-400 flex items-center justify-center mx-auto">
          <ShieldAlert className="w-8 h-8" />
        </div>
        <h2 className="text-2xl font-bold text-white">Access Denied</h2>
        <p className="text-xs text-[#a7a7a7] leading-relaxed">
          The KRISH MUSIC Admin Panel is restricted to authorized platform administrators. Your current account does not have administrative privileges.
        </p>
        <div className="pt-4 flex flex-col sm:flex-row items-center justify-center gap-3">
          <button
            onClick={() => simulateAdminLogin()}
            className="bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-5 py-2.5 rounded-full transition-transform hover:scale-105"
          >
            Authenticate as Super Admin
          </button>
          <button
            onClick={() => onNavigate('/')}
            className="bg-[#282828] text-white text-xs px-5 py-2.5 rounded-full border border-white/10 hover:bg-[#333333] transition-colors"
          >
            Return to Music Home
          </button>
        </div>
      </div>
    );
  }

  const tabs = [
    { path: '/admin', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/admin/songs', label: 'Songs & Links', icon: Music },
    { path: '/admin/songs/new', label: 'Add Song', icon: PlusCircle },
    { path: '/admin/albums', label: 'Albums', icon: Disc },
    { path: '/admin/artists', label: 'Artists', icon: Mic2 },
    { path: '/admin/playlists', label: 'Playlists', icon: ListMusic },
    { path: '/admin/users', label: 'Users', icon: Users },
    { path: '/admin/analytics', label: 'Analytics', icon: BarChart3 },
    { path: '/admin/settings', label: 'Settings & Logs', icon: Settings },
  ];

  return (
    <div className="pb-32">
      {/* Admin Top Header */}
      <div className="bg-[#181818] border-b border-white/5 px-6 md:px-8 py-5 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('/')}
            className="p-1.5 rounded-lg bg-[#242424] hover:bg-[#303030] text-[#a7a7a7] hover:text-white transition-colors"
            title="Return to Public App"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-white tracking-tight">
                KRISH MUSIC Control Center
              </h1>
              <span className="text-[10px] font-bold text-[#1db954] bg-[#1db954]/10 px-2 py-0.5 rounded-full border border-[#1db954]/20 uppercase">
                Admin
              </span>
            </div>
            <p className="text-[11px] text-[#a7a7a7]">
              Manage catalogue, media streaming, users, and audit operations
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <a
            href="/"
            className="flex items-center gap-2 bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-4 py-2 rounded-full transition-transform hover:scale-105 shadow-md shadow-[#1db954]/20"
          >
            <span>Open Music Player</span>
          </a>
        </div>
      </div>

      {/* Admin Subnav Tabs */}
      <div className="bg-[#121212] border-b border-white/5 px-6 md:px-8 flex items-center gap-1 overflow-x-auto custom-scroll">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive =
            tab.path === '/admin'
              ? currentPath === '/admin'
              : currentPath.startsWith(tab.path);

          return (
            <button
              key={tab.path}
              onClick={() => onNavigate(tab.path)}
              className={`flex items-center gap-2 px-3.5 py-3 text-xs font-semibold whitespace-nowrap border-b-2 transition-colors ${
                isActive
                  ? 'border-[#1db954] text-white'
                  : 'border-transparent text-[#a7a7a7] hover:text-white hover:border-white/20'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Content Area */}
      <div className="p-6 md:p-8">{children}</div>
    </div>
  );
};
