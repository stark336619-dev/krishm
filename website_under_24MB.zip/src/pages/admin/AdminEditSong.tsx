import React, { useState, useEffect } from 'react';
import { ArrowLeft, Save, AlertCircle, CheckCircle2, Trash2 } from 'lucide-react';
import { Song } from '../../types/music';
import { musicRepository } from '../../services/musicRepository';
import { useAuth } from '../../context/AuthContext';

interface AdminEditSongProps {
  songId: string;
  onNavigate: (path: string) => void;
}

export const AdminEditSong: React.FC<AdminEditSongProps> = ({ songId, onNavigate }) => {
  const { userProfile } = useAuth();
  const [song, setSong] = useState<Song | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');
  const [album, setAlbum] = useState('');
  const [audioUrl, setAudioUrl] = useState('');
  const [coverUrl, setCoverUrl] = useState('');
  const [duration, setDuration] = useState(0);
  const [genre, setGenre] = useState('');
  const [language, setLanguage] = useState('');
  const [releaseDate, setReleaseDate] = useState('');
  const [lyrics, setLyrics] = useState('');
  const [isExplicit, setIsExplicit] = useState(false);
  const [isFeatured, setIsFeatured] = useState(false);
  const [isPublished, setIsPublished] = useState(true);

  const [isSaving, setIsSaving] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  useEffect(() => {
    const fetchSong = async () => {
      setIsLoading(true);
      const data = await musicRepository.getSongById(songId);
      if (data) {
        setSong(data);
        setTitle(data.title);
        setArtist(data.artist);
        setAlbum(data.album || '');
        setAudioUrl(data.audioUrl);
        setCoverUrl(data.coverUrl || '');
        setDuration(data.duration);
        setGenre(data.genre || 'Electronic');
        setLanguage(data.language || 'English');
        setReleaseDate(data.releaseDate || '');
        setLyrics(data.lyrics || '');
        setIsExplicit(Boolean(data.isExplicit));
        setIsFeatured(Boolean(data.isFeatured));
        setIsPublished(Boolean(data.isPublished));
      }
      setIsLoading(false);
    };
    fetchSong();
  }, [songId]);

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim() || !artist.trim() || !audioUrl.trim()) {
      setErrorMsg('Title, Artist, and Audio URL are required.');
      return;
    }

    setIsSaving(true);
    setErrorMsg(null);
    try {
      await musicRepository.updateSong(songId, {
        title: title.trim(),
        artist: artist.trim(),
        album: album.trim() || undefined,
        audioUrl: audioUrl.trim(),
        coverUrl: coverUrl.trim() || undefined,
        duration: duration || 180,
        genre: genre.trim(),
        language: language.trim(),
        releaseDate,
        lyrics: lyrics.trim() || undefined,
        isExplicit,
        isFeatured,
        isPublished,
      });

      await musicRepository.recordAuditLog({
        adminId: userProfile?.uid || 'admin',
        adminEmail: userProfile?.email || 'admin@sonora.app',
        action: 'EDIT_SONG',
        targetEntity: 'song',
        targetId: songId,
        details: `Updated metadata for "${title}"`,
      });

      setSuccessMsg('Song updated successfully.');
      setTimeout(() => onNavigate('/admin/songs'), 800);
    } catch (err: unknown) {
      setErrorMsg(err instanceof Error ? err.message : 'Failed to update song.');
    } finally {
      setIsSaving(false);
    }
  };

  if (isLoading) {
    return <div className="p-8 text-center text-xs text-[#a7a7a7]">Loading song details...</div>;
  }

  if (!song) {
    return (
      <div className="p-8 text-center space-y-3">
        <h3 className="text-base font-bold text-white">Song not found</h3>
        <button
          onClick={() => onNavigate('/admin/songs')}
          className="text-xs text-[#1db954] hover:underline"
        >
          Back to Songs
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center justify-between pb-4 border-b border-white/5">
        <div className="flex items-center gap-3">
          <button
            onClick={() => onNavigate('/admin/songs')}
            className="p-1.5 rounded-lg bg-[#242424] hover:bg-[#303030] text-[#a7a7a7] hover:text-white transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
          </button>
          <div>
            <h2 className="text-xl font-bold text-white tracking-tight">Edit Song</h2>
            <p className="text-xs text-[#a7a7a7]">{song.title}</p>
          </div>
        </div>
      </div>

      {errorMsg && (
        <div className="p-3 bg-red-500/10 border border-red-500/30 rounded-xl text-red-400 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="p-3 bg-[#1db954]/10 border border-[#1db954]/30 rounded-xl text-[#1db954] text-xs flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 shrink-0" />
          <span>{successMsg}</span>
        </div>
      )}

      <form onSubmit={handleSave} className="space-y-4 bg-[#181818] p-6 rounded-2xl border border-white/5">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">Song Title</label>
            <input
              type="text"
              value={title}
              onChange={e => setTitle(e.target.value)}
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
              required
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">Artist Name</label>
            <input
              type="text"
              value={artist}
              onChange={e => setArtist(e.target.value)}
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
              required
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">Album</label>
            <input
              type="text"
              value={album}
              onChange={e => setAlbum(e.target.value)}
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">Genre</label>
            <input
              type="text"
              value={genre}
              onChange={e => setGenre(e.target.value)}
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
            />
          </div>
        </div>

        <div>
          <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">Direct Audio Stream URL</label>
          <input
            type="url"
            value={audioUrl}
            onChange={e => setAudioUrl(e.target.value)}
            className="w-full bg-[#202020] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
            required
          />
        </div>

        <div>
          <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">Cover Artwork URL</label>
          <input
            type="url"
            value={coverUrl}
            onChange={e => setCoverUrl(e.target.value)}
            className="w-full bg-[#202020] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
          />
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">Duration (seconds)</label>
            <input
              type="number"
              value={duration}
              onChange={e => setDuration(Number(e.target.value))}
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3 py-2 text-xs text-white font-mono tabular-nums focus:outline-none focus:border-[#1db954]"
            />
          </div>
          <div>
            <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">Release Date</label>
            <input
              type="date"
              value={releaseDate}
              onChange={e => setReleaseDate(e.target.value)}
              className="w-full bg-[#202020] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
            />
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-6 pt-2">
          <label className="flex items-center gap-2 cursor-pointer text-xs text-white">
            <input
              type="checkbox"
              checked={isExplicit}
              onChange={e => setIsExplicit(e.target.checked)}
              className="w-4 h-4 accent-[#1db954] rounded"
            />
            <span>Explicit (18+)</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer text-xs text-white">
            <input
              type="checkbox"
              checked={isFeatured}
              onChange={e => setIsFeatured(e.target.checked)}
              className="w-4 h-4 accent-[#1db954] rounded"
            />
            <span>Featured</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer text-xs text-white">
            <input
              type="checkbox"
              checked={isPublished}
              onChange={e => setIsPublished(e.target.checked)}
              className="w-4 h-4 accent-[#1db954] rounded"
            />
            <span>Published (Live)</span>
          </label>
        </div>

        <div>
          <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">Lyrics</label>
          <textarea
            value={lyrics}
            onChange={e => setLyrics(e.target.value)}
            rows={4}
            className="w-full bg-[#202020] border border-white/10 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-[#1db954] font-mono"
          />
        </div>

        <div className="flex items-center justify-end gap-3 pt-3">
          <button
            type="button"
            onClick={() => onNavigate('/admin/songs')}
            className="px-4 py-2 rounded-full text-xs font-semibold text-white hover:bg-white/10"
          >
            Cancel
          </button>
          <button
            type="submit"
            disabled={isSaving}
            className="flex items-center gap-2 px-6 py-2 rounded-full text-xs font-bold bg-[#1db954] hover:bg-[#1ed760] text-black transition-transform hover:scale-105"
          >
            <Save className="w-3.5 h-3.5" />
            <span>{isSaving ? 'Saving...' : 'Save Changes'}</span>
          </button>
        </div>
      </form>
    </div>
  );
};
