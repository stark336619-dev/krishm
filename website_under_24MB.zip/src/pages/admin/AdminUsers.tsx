import React, { useState, useEffect } from 'react';
import { Users, Search, ShieldCheck, UserCheck, UserX, AlertCircle } from 'lucide-react';
import { UserProfile } from '../../types/music';
import { useAuth } from '../../context/AuthContext';
import { formatTimeAgo } from '../../utils/format';

export const AdminUsers: React.FC = () => {
  const { userProfile } = useAuth();
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [search, setSearch] = useState('');

  useEffect(() => {
    // Load registered users from local state / firestore
    const currentList: UserProfile[] = [
      {
        uid: 'super_admin_yug',
        email: 'yug.hitendra2007@gmail.com',
        displayName: 'Yug Hitendra',
        photoURL: null,
        role: 'admin',
        isSuspended: false,
        createdAt: '2025-01-01T00:00:00.000Z',
      },
      {
        uid: 'super_admin_krish',
        email: 'pckrish33@gmail.com',
        displayName: 'Krish (Founder & Dev)',
        photoURL: null,
        role: 'admin',
        isSuspended: false,
        createdAt: '2025-01-01T00:00:00.000Z',
      },
      {
        uid: 'user_alex_123',
        email: 'alex.sound@gmail.com',
        displayName: 'Alex Rivers',
        photoURL: null,
        role: 'user',
        isSuspended: false,
        createdAt: '2025-02-14T10:20:00.000Z',
      },
      {
        uid: 'user_maya_456',
        email: 'maya.lofi@sonora.test',
        displayName: 'Maya Chen',
        photoURL: null,
        role: 'user',
        isSuspended: false,
        createdAt: '2025-03-01T15:40:00.000Z',
      },
    ];

    if (userProfile && !currentList.some(u => u.uid === userProfile.uid)) {
      currentList.unshift(userProfile);
    }
    setUsers(currentList);
  }, [userProfile]);

  const toggleSuspension = (uid: string) => {
    const userEmail = users.find(u => u.uid === uid)?.email?.toLowerCase();
    if (userEmail === 'yug.hitendra2007@gmail.com' || userEmail === 'pckrish33@gmail.com') {
      alert('Cannot suspend designated Super Administrator accounts.');
      return;
    }
    setUsers(prev =>
      prev.map(u => (u.uid === uid ? { ...u, isSuspended: !u.isSuspended } : u))
    );
  };

  const toggleRole = (uid: string) => {
    const userEmail = users.find(u => u.uid === uid)?.email?.toLowerCase();
    if (userEmail === 'yug.hitendra2007@gmail.com' || userEmail === 'pckrish33@gmail.com') {
      alert('Cannot demote designated Super Administrator accounts.');
      return;
    }
    setUsers(prev =>
      prev.map(u =>
        u.uid === uid ? { ...u, role: u.role === 'admin' ? 'user' : 'admin' } : u
      )
    );
  };

  const filteredUsers = users.filter(
    u =>
      (u.displayName && u.displayName.toLowerCase().includes(search.toLowerCase())) ||
      (u.email && u.email.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-white tracking-tight">Registered Users</h2>
          <p className="text-xs text-[#a7a7a7]">
            Monitor accounts, role assignments, and platform access
          </p>
        </div>

        <div className="relative max-w-xs w-full">
          <Search className="w-4 h-4 text-[#727272] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={e => setSearch(e.target.value)}
            placeholder="Search users..."
            className="w-full bg-[#181818] border border-white/10 rounded-full px-3 py-1.5 pl-9 text-xs text-white focus:outline-none focus:border-[#1db954]"
          />
        </div>
      </div>

      <div className="bg-[#181818] rounded-2xl border border-white/5 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-[#202020] text-[#a7a7a7] uppercase tracking-wider text-[11px] border-b border-white/5">
              <tr>
                <th className="p-3 pl-4">User</th>
                <th className="p-3">Email</th>
                <th className="p-3 text-center">Role</th>
                <th className="p-3 text-center">Status</th>
                <th className="p-3">Joined</th>
                <th className="p-3 pr-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {filteredUsers.map(u => (
                <tr key={u.uid} className="hover:bg-[#222222] transition-colors">
                  <td className="p-3 pl-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-[#333333] flex items-center justify-center font-bold text-white text-xs">
                        {u.displayName?.charAt(0).toUpperCase() || 'U'}
                      </div>
                      <span className="font-semibold text-white">
                        {u.displayName || 'Anonymous'}
                      </span>
                    </div>
                  </td>
                  <td className="p-3 text-[#a7a7a7] font-mono">{u.email}</td>
                  <td className="p-3 text-center">
                    <span
                      className={`inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        u.role === 'admin'
                          ? 'bg-[#1db954]/20 text-[#1db954]'
                          : 'bg-white/10 text-[#a7a7a7]'
                      }`}
                    >
                      {u.role === 'admin' && <ShieldCheck className="w-3 h-3" />}
                      <span>{u.role.toUpperCase()}</span>
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        u.isSuspended
                          ? 'bg-red-500/20 text-red-400'
                          : 'bg-emerald-500/20 text-emerald-400'
                      }`}
                    >
                      {u.isSuspended ? 'Suspended' : 'Active'}
                    </span>
                  </td>
                  <td className="p-3 text-[#727272]">{formatTimeAgo(u.createdAt)}</td>
                  <td className="p-3 pr-4 text-right">
                    <div className="flex items-center justify-end gap-2">
                      <button
                        onClick={() => toggleRole(u.uid)}
                        className="px-2.5 py-1 rounded bg-[#282828] hover:bg-[#333333] text-white text-[11px] font-medium transition-colors"
                      >
                        {u.role === 'admin' ? 'Set as User' : 'Grant Admin'}
                      </button>
                      <button
                        onClick={() => toggleSuspension(u.uid)}
                        className={`px-2.5 py-1 rounded text-[11px] font-medium transition-colors ${
                          u.isSuspended
                            ? 'bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30'
                            : 'bg-red-500/20 text-red-400 hover:bg-red-500/30'
                        }`}
                      >
                        {u.isSuspended ? 'Reactivate' : 'Suspend'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
