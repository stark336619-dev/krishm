import React, { useState, useEffect } from 'react';
import {
  Music,
  Users,
  ListMusic,
  Mic2,
  Headphones,
  PlusCircle,
  Sparkles,
  TrendingUp,
  Clock,
  Play,
  Check,
  Disc,
} from 'lucide-react';
import { Song, Album, Artist, Playlist, AdminAuditLog } from '../../types/music';
import { musicRepository } from '../../services/musicRepository';
import { useAuth } from '../../context/AuthContext';
import { usePlayer } from '../../context/PlayerContext';
import { formatNumber, formatDuration, formatTimeAgo } from '../../utils/format';

interface AdminDashboardProps {
  onNavigate: (path: string) => void;
}

export const AdminDashboard: React.FC<AdminDashboardProps> = ({ onNavigate }) => {
  const { userProfile } = useAuth();
  const { playSong } = usePlayer();
  const [songs, setSongs] = useState<Song[]>([]);
  const [albums, setAlbums] = useState<Album[]>([]);
  const [artists, setArtists] = useState<Artist[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [auditLogs, setAuditLogs] = useState<AdminAuditLog[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [isSeeding, setIsSeeding] = useState(false);
  const [seedSuccess, setSeedSuccess] = useState<string | null>(null);

  const loadData = async () => {
    setIsLoading(true);
    const [s, al, ar, pl, logs] = await Promise.all([
      musicRepository.getSongs(true),
      musicRepository.getAlbums(),
      musicRepository.getArtists(),
      musicRepository.getPlaylists(),
      musicRepository.getAdminAuditLogs(),
    ]);
    setSongs(s);
    setAlbums(al);
    setArtists(ar);
    setPlaylists(pl);
    setAuditLogs(logs);
    setIsLoading(false);
  };

  useEffect(() => {
    loadData();
  }, []);

  const totalPlays = songs.reduce((acc, s) => acc + (s.playCount || 0), 0);
  const topPlayedSongs = [...songs].sort((a, b) => (b.playCount || 0) - (a.playCount || 0)).slice(0, 5);
  const recentlyAddedSongs = [...songs].slice(0, 5);

  const handleSeedCatalog = async () => {
    setIsSeeding(true);
    setSeedSuccess(null);
    try {
      const result = await musicRepository.seedDemoTracks();
      await musicRepository.recordAuditLog({
        adminId: userProfile?.uid || 'super_admin',
        adminEmail: userProfile?.email || 'admin@sonora.app',
        action: 'SEED_DEMO_CATALOG',
        targetEntity: 'catalog',
        targetId: 'batch_seed',
        details: `Seeded ${result.songsCount} songs, ${result.albumsCount} albums, ${result.artistsCount} artists`,
      });
      setSeedSuccess(`Added ${result.songsCount} streaming songs and albums successfully!`);
      loadData();
    } catch {
      setSeedSuccess('Catalog populated.');
      loadData();
    } finally {
      setIsSeeding(false);
    }
  };

  return (
    <div className="space-y-8">
      {/* Top Banner Notice with 1-Click Seed Tool */}
      {seedSuccess && (
        <div className="p-4 bg-[#1db954]/10 border border-[#1db954]/30 rounded-xl text-[#1db954] text-xs font-semibold flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4" />
            <span>{seedSuccess}</span>
          </div>
          <button
            onClick={() => setSeedSuccess(null)}
            className="text-white hover:underline text-[11px]"
          >
            Dismiss
          </button>
        </div>
      )}

      {/* KPI Cards Strip */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-4">
        <div className="bg-[#181818] p-5 rounded-2xl border border-white/5 space-y-1">
          <div className="flex items-center justify-between text-[#a7a7a7]">
            <span className="text-xs font-medium">Total Songs</span>
            <Music className="w-4 h-4 text-[#1db954]" />
          </div>
          <p className="text-2xl font-bold text-white tabular-nums font-mono">
            {formatNumber(songs.length)}
          </p>
          <p className="text-[11px] text-[#727272]">
            {songs.filter(s => s.isPublished).length} published
          </p>
        </div>

        <div className="bg-[#181818] p-5 rounded-2xl border border-white/5 space-y-1">
          <div className="flex items-center justify-between text-[#a7a7a7]">
            <span className="text-xs font-medium">Total Recorded Plays</span>
            <Headphones className="w-4 h-4 text-blue-400" />
          </div>
          <p className="text-2xl font-bold text-white tabular-nums font-mono">
            {formatNumber(totalPlays)}
          </p>
          <p className="text-[11px] text-[#727272]">Track streaming activity</p>
        </div>

        <div className="bg-[#181818] p-5 rounded-2xl border border-white/5 space-y-1">
          <div className="flex items-center justify-between text-[#a7a7a7]">
            <span className="text-xs font-medium">Albums</span>
            <Disc className="w-4 h-4 text-purple-400" />
          </div>
          <p className="text-2xl font-bold text-white tabular-nums font-mono">
            {formatNumber(albums.length)}
          </p>
          <p className="text-[11px] text-[#727272]">Recorded discs</p>
        </div>

        <div className="bg-[#181818] p-5 rounded-2xl border border-white/5 space-y-1">
          <div className="flex items-center justify-between text-[#a7a7a7]">
            <span className="text-xs font-medium">Artists</span>
            <Mic2 className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-2xl font-bold text-white tabular-nums font-mono">
            {formatNumber(artists.length)}
          </p>
          <p className="text-[11px] text-[#727272]">Active creators</p>
        </div>

        <div className="bg-[#181818] p-5 rounded-2xl border border-white/5 space-y-1">
          <div className="flex items-center justify-between text-[#a7a7a7]">
            <span className="text-xs font-medium">Playlists</span>
            <ListMusic className="w-4 h-4 text-rose-400" />
          </div>
          <p className="text-2xl font-bold text-white tabular-nums font-mono">
            {formatNumber(playlists.length)}
          </p>
          <p className="text-[11px] text-[#727272]">Curated collections</p>
        </div>
      </div>

      {/* Quick Actions & Seeding Utility */}
      <div className="bg-gradient-to-r from-[#181818] to-[#222222] p-6 rounded-2xl border border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
        <div>
          <h3 className="text-sm font-bold text-white flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#1db954]" />
            <span>Catalog Quick Actions</span>
          </h3>
          <p className="text-xs text-[#a7a7a7] mt-1">
            Manually upload your MP3/AAC audio files, configure stream URLs, or pre-load demo tracks.
          </p>
        </div>

        <div className="flex items-center gap-3 shrink-0 flex-wrap">
          <button
            onClick={() => onNavigate('/admin/songs')}
            className="flex items-center gap-2 bg-gradient-to-r from-cyan-500 to-purple-600 hover:opacity-90 text-white font-bold text-xs px-4 py-2 rounded-full hover:scale-105 transition-transform shadow-lg"
          >
            <Music className="w-4 h-4" />
            <span>View All Song & JPG Links</span>
          </button>

          <button
            onClick={() => onNavigate('/admin/songs/new')}
            className="flex items-center gap-2 bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-4 py-2 rounded-full hover:scale-105 transition-transform"
          >
            <PlusCircle className="w-4 h-4" />
            <span>Upload / Add Song</span>
          </button>

          <button
            onClick={handleSeedCatalog}
            disabled={isSeeding}
            className="flex items-center gap-2 bg-[#282828] hover:bg-[#333333] text-white font-medium text-xs px-4 py-2 rounded-full border border-white/10 transition-colors disabled:opacity-50"
            title="Adds royalty-free audio tracks for instant playback testing"
          >
            <Sparkles className="w-4 h-4 text-[#1db954]" />
            <span>{isSeeding ? 'Seeding Tracks...' : 'Load Sample Tracks'}</span>
          </button>
        </div>
      </div>

      {/* Tables Row: Most Played & Recently Added */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Most Played Songs */}
        <div className="bg-[#181818] p-6 rounded-2xl border border-white/5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-4 h-4 text-[#1db954]" />
              <span>Top Streamed Songs</span>
            </h3>
            <button
              onClick={() => onNavigate('/admin/songs')}
              className="text-xs text-[#a7a7a7] hover:text-white"
            >
              Manage all
            </button>
          </div>

          {topPlayedSongs.length === 0 ? (
            <p className="text-xs text-[#727272] py-4 text-center italic">
              No songs recorded yet. Add your first track.
            </p>
          ) : (
            <div className="space-y-2">
              {topPlayedSongs.map((song, i) => (
                <div
                  key={song.id}
                  className="flex items-center justify-between p-2 rounded-lg hover:bg-[#222222] transition-colors"
                >
                  <div className="flex items-center gap-3 min-w-0">
                    <span className="text-xs text-[#a7a7a7] font-mono tabular-nums w-4">
                      {i + 1}
                    </span>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-white truncate">
                        {song.title}
                      </p>
                      <p className="text-[11px] text-[#a7a7a7] truncate">
                        {song.artist}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4 shrink-0">
                    <span className="text-xs text-white font-mono tabular-nums font-semibold">
                      {formatNumber(song.playCount || 0)} plays
                    </span>
                    <button
                      onClick={() => playSong(song)}
                      className="p-1.5 rounded-full hover:bg-white/10 text-[#1db954]"
                    >
                      <Play className="w-3.5 h-3.5 fill-current ml-0.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Recently Added Songs */}
        <div className="bg-[#181818] p-6 rounded-2xl border border-white/5 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-400" />
              <span>Recently Added</span>
            </h3>
            <button
              onClick={() => onNavigate('/admin/songs')}
              className="text-xs text-[#a7a7a7] hover:text-white"
            >
              View catalog
            </button>
          </div>

          {recentlyAddedSongs.length === 0 ? (
            <p className="text-xs text-[#727272] py-4 text-center italic">
              Catalog is currently empty.
            </p>
          ) : (
            <div className="space-y-2">
              {recentlyAddedSongs.map(song => (
                <div
                  key={song.id}
                  className="flex items-center justify-between p-2 rounded-lg hover:bg-[#222222] transition-colors"
                >
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-white truncate">
                      {song.title}
                    </p>
                    <p className="text-[11px] text-[#a7a7a7] truncate">
                      {song.artist} · {formatDuration(song.duration)}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`text-[10px] px-2 py-0.5 rounded-full font-semibold ${
                        song.isPublished
                          ? 'bg-[#1db954]/10 text-[#1db954]'
                          : 'bg-yellow-500/10 text-yellow-400'
                      }`}
                    >
                      {song.isPublished ? 'Published' : 'Draft'}
                    </span>
                    <span className="text-[11px] text-[#727272]">
                      {song.createdAt ? formatTimeAgo(song.createdAt) : 'Recently'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
