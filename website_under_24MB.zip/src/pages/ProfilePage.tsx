import React, { useState, useEffect } from 'react';
import { User, ShieldCheck, Heart, ListMusic, Clock, LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { musicRepository } from '../services/musicRepository';
import { Song, Playlist } from '../types/music';

interface ProfilePageProps {
  onNavigate: (path: string) => void;
}

export const ProfilePage: React.FC<ProfilePageProps> = ({ onNavigate }) => {
  const { userProfile, isAdmin, signOutUser, signInWithGoogle, simulateAdminLogin } = useAuth();
  const [likedCount, setLikedCount] = useState(0);
  const [playlistCount, setPlaylistCount] = useState(0);
  const [historyCount, setHistoryCount] = useState(0);

  useEffect(() => {
    if (!userProfile?.uid) return;
    const fetchCounts = async () => {
      const [likes, playlists, history] = await Promise.all([
        musicRepository.getUserLikes(userProfile.uid),
        musicRepository.getPlaylists(userProfile.uid),
        musicRepository.getUserHistory(userProfile.uid),
      ]);
      setLikedCount(likes.length);
      setPlaylistCount(playlists.filter(p => p.ownerId === userProfile.uid).length);
      setHistoryCount(history.length);
    };
    fetchCounts();
  }, [userProfile?.uid]);

  if (!userProfile) {
    return (
      <div className="p-12 text-center max-w-md mx-auto space-y-4">
        <User className="w-16 h-16 text-[#727272] mx-auto" />
        <h2 className="text-xl font-bold text-white">Sign In to SONORA</h2>
        <p className="text-xs text-[#a7a7a7]">
          Sign in to save liked songs, create custom playlists, and access the admin dashboard.
        </p>
        <div className="flex flex-col gap-2 pt-2">
          <button
            onClick={() => signInWithGoogle()}
            className="bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-6 py-2.5 rounded-full transition-transform hover:scale-105"
          >
            Sign in with Google
          </button>
          <button
            onClick={() => simulateAdminLogin()}
            className="text-xs text-[#a7a7a7] hover:text-white underline pt-1"
          >
            Or log in as Super Admin (yug.hitendra2007@gmail.com)
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="pb-32">
      {/* Profile Header */}
      <div className="bg-gradient-to-b from-[#282828] to-[#121212] p-6 md:p-10 flex flex-col sm:flex-row items-end gap-6 border-b border-white/5">
        <div className="w-40 h-40 rounded-full overflow-hidden shadow-2xl bg-[#333333] shrink-0 border-2 border-white/10 flex items-center justify-center">
          {userProfile.photoURL ? (
            <img
              src={userProfile.photoURL}
              alt={userProfile.displayName || 'User'}
              className="w-full h-full object-cover"
            />
          ) : (
            <span className="text-5xl font-extrabold text-white">
              {userProfile.displayName?.charAt(0).toUpperCase() || 'U'}
            </span>
          )}
        </div>

        <div className="flex flex-col gap-2 min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-white">
              Profile
            </span>
            {isAdmin && (
              <span className="flex items-center gap-1 text-[11px] font-bold text-[#1db954] bg-[#1db954]/10 px-2.5 py-0.5 rounded-full border border-[#1db954]/30">
                <ShieldCheck className="w-3.5 h-3.5" />
                <span>Super Administrator</span>
              </span>
            )}
          </div>
          <h1 className="text-3xl md:text-5xl font-extrabold text-white tracking-tight truncate">
            {userProfile.displayName}
          </h1>
          <p className="text-xs text-[#a7a7a7] font-mono">{userProfile.email}</p>
        </div>
      </div>

      {/* Metrics Row */}
      <div className="px-6 md:px-10 py-8 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl">
        <div
          onClick={() => onNavigate('/liked')}
          className="bg-[#181818] hover:bg-[#222222] p-5 rounded-2xl border border-white/5 cursor-pointer transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#450af5]/20 flex items-center justify-center text-[#450af5]">
              <Heart className="w-5 h-5 fill-current" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white tabular-nums font-mono">
                {likedCount}
              </p>
              <p className="text-xs text-[#a7a7a7]">Liked Songs</p>
            </div>
          </div>
        </div>

        <div
          onClick={() => onNavigate('/library')}
          className="bg-[#181818] hover:bg-[#222222] p-5 rounded-2xl border border-white/5 cursor-pointer transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-[#1db954]/20 flex items-center justify-center text-[#1db954]">
              <ListMusic className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white tabular-nums font-mono">
                {playlistCount}
              </p>
              <p className="text-xs text-[#a7a7a7]">Personal Playlists</p>
            </div>
          </div>
        </div>

        <div
          onClick={() => onNavigate('/library')}
          className="bg-[#181818] hover:bg-[#222222] p-5 rounded-2xl border border-white/5 cursor-pointer transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-blue-500/20 flex items-center justify-center text-blue-400">
              <Clock className="w-5 h-5" />
            </div>
            <div>
              <p className="text-2xl font-bold text-white tabular-nums font-mono">
                {historyCount}
              </p>
              <p className="text-xs text-[#a7a7a7]">Tracks Streamed</p>
            </div>
          </div>
        </div>
      </div>

      {/* Account Settings / Actions */}
      <div className="px-6 md:px-10 max-w-xl space-y-4">
        {isAdmin && (
          <div className="bg-[#181818] p-5 rounded-2xl border border-[#1db954]/20 space-y-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <ShieldCheck className="w-4 h-4 text-[#1db954]" />
              <span>Administrative Privileges</span>
            </h3>
            <p className="text-xs text-[#a7a7a7] leading-relaxed">
              You are authenticated with Super Admin credentials. You have full permissions to manage songs, albums, playlists, users, and homepage sections.
            </p>
            <button
              onClick={() => onNavigate('/admin')}
              className="bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-5 py-2 rounded-full transition-transform hover:scale-105"
            >
              Open Admin Command Center
            </button>
          </div>
        )}

        <button
          onClick={signOutUser}
          className="flex items-center gap-2 text-xs font-semibold text-red-400 hover:text-red-300 p-3 hover:bg-[#1f1f1f] rounded-xl transition-colors"
        >
          <LogOut className="w-4 h-4" />
          <span>Sign Out of Account</span>
        </button>
      </div>
    </div>
  );
};
