import React, { useState } from 'react';
import { Sliders, Keyboard, Check, Volume2, Globe, ExternalLink, AlertCircle, LogOut, Disc } from 'lucide-react';
import { useSpotify } from '../context/SpotifyContext';

export const SettingsPage: React.FC = () => {
  const [quality, setQuality] = useState('High');
  const [autoplay, setAutoplay] = useState(true);
  const [normalizeVolume, setNormalizeVolume] = useState(true);
  const [crossfade, setCrossfade] = useState(0);
  const [savedNotice, setSavedNotice] = useState(false);

  const handleSave = () => {
    setSavedNotice(true);
    setTimeout(() => setSavedNotice(false), 2000);
  };

  const {
    isConnected: isSpotifyConnected,
    isLoading: isSpotifyLoading,
    spotifyUser,
    error: spotifyError,
    connectSpotify,
    disconnectSpotify,
  } = useSpotify();

  return (
    <div className="max-w-2xl p-6 md:p-8 space-y-8 pb-32">
      <div>
        <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
          Settings
        </h1>
        <p className="text-xs text-[#a7a7a7] mt-1">
          Customize your audio streaming, connected services, and playback preferences
        </p>
      </div>

      {savedNotice && (
        <div className="p-3 bg-[#1db954]/10 border border-[#1db954]/30 rounded-xl text-[#1db954] text-xs flex items-center gap-2">
          <Check className="w-4 h-4" />
          <span>Playback settings updated.</span>
        </div>
      )}

      {/* Spotify Connected Account Card */}
      <div className="bg-[#181818] p-6 rounded-2xl border border-white/5 space-y-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-[#1db954]/20 flex items-center justify-center text-[#1db954]">
              <Globe className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <span>Spotify Account & Discovery</span>
                <span className="text-[10px] bg-white/10 text-white px-2 py-0.5 rounded font-mono font-normal">
                  Optional
                </span>
              </h3>
              <p className="text-[11px] text-[#a7a7a7]">
                Connect your Spotify profile to browse your library and discover artists on SONORA
              </p>
            </div>
          </div>

          <span
            className={`text-[10px] font-semibold px-2.5 py-1 rounded-full border ${
              isSpotifyConnected
                ? 'bg-[#1db954]/10 text-[#1db954] border-[#1db954]/30'
                : 'bg-[#282828] text-[#a7a7a7] border-white/10'
            }`}
          >
            {isSpotifyConnected ? 'Linked (PKCE)' : 'Not Connected'}
          </span>
        </div>

        {spotifyError && (
          <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-xl text-red-400 text-xs flex items-start gap-2">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span className="leading-relaxed">{spotifyError}</span>
          </div>
        )}

        {isSpotifyConnected && spotifyUser ? (
          <div className="bg-[#202020] p-4 rounded-xl border border-white/5 flex items-center justify-between">
            <div className="flex items-center gap-3">
              {spotifyUser.imageUrl ? (
                <img
                  src={spotifyUser.imageUrl}
                  alt={spotifyUser.displayName}
                  className="w-10 h-10 rounded-full object-cover border border-[#1db954]/40"
                />
              ) : (
                <div className="w-10 h-10 rounded-full bg-[#1db954] text-black font-bold flex items-center justify-center text-sm">
                  {spotifyUser.displayName.charAt(0).toUpperCase()}
                </div>
              )}
              <div>
                <p className="text-xs font-bold text-white flex items-center gap-1.5">
                  <span>{spotifyUser.displayName}</span>
                  {spotifyUser.profileUrl && (
                    <a
                      href={spotifyUser.profileUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="text-[#a7a7a7] hover:text-[#1db954]"
                    >
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  )}
                </p>
                <p className="text-[10px] text-[#727272]">
                  {spotifyUser.email || `Spotify ID: ${spotifyUser.id}`}
                </p>
              </div>
            </div>

            <button
              onClick={disconnectSpotify}
              className="flex items-center gap-1.5 text-xs text-red-400 hover:text-red-300 bg-red-500/10 hover:bg-red-500/20 px-3 py-1.5 rounded-lg border border-red-500/20 transition-colors"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span>Disconnect</span>
            </button>
          </div>
        ) : (
          <div className="space-y-3 pt-1">
            <p className="text-xs text-[#a7a7a7] leading-relaxed">
              SONORA uses official Spotify PKCE OAuth to authenticate directly without exposing passwords. Your Google Firebase sign-in remains completely separate and safe.
            </p>
            <div className="flex items-center gap-3">
              <button
                onClick={connectSpotify}
                disabled={isSpotifyLoading}
                className="flex items-center gap-2 bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-5 py-2.5 rounded-full transition-transform hover:scale-105 disabled:opacity-50"
              >
                <Disc className="w-4 h-4 fill-black" />
                <span>{isSpotifyLoading ? 'Connecting...' : 'Connect with Spotify'}</span>
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Audio Quality */}
      <div className="bg-[#181818] p-6 rounded-2xl border border-white/5 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Volume2 className="w-4 h-4 text-[#1db954]" />
          <span>Audio Quality</span>
        </h3>

        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs font-semibold text-white">Streaming Quality</p>
              <p className="text-[11px] text-[#a7a7a7]">
                Higher bitrate audio delivers greater acoustic detail
              </p>
            </div>
            <select
              value={quality}
              onChange={e => {
                setQuality(e.target.value);
                handleSave();
              }}
              className="bg-[#242424] text-white border border-white/10 rounded-lg px-3 py-1.5 text-xs focus:outline-none focus:border-[#1db954]"
            >
              <option value="Standard">Standard (128 kbps)</option>
              <option value="High">High (256 kbps)</option>
              <option value="Very High">Very High (320 kbps)</option>
              <option value="Lossless">Lossless FLAC</option>
            </select>
          </div>

          <div className="flex items-center justify-between pt-3 border-t border-white/5">
            <div>
              <p className="text-xs font-semibold text-white">Normalize Volume</p>
              <p className="text-[11px] text-[#a7a7a7]">
                Set the same loudness level for all tracks
              </p>
            </div>
            <input
              type="checkbox"
              checked={normalizeVolume}
              onChange={e => {
                setNormalizeVolume(e.target.checked);
                handleSave();
              }}
              className="w-4 h-4 accent-[#1db954] rounded cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between pt-3 border-t border-white/5">
            <div>
              <p className="text-xs font-semibold text-white">Autoplay</p>
              <p className="text-[11px] text-[#a7a7a7]">
                Keep the music going when your queue finishes
              </p>
            </div>
            <input
              type="checkbox"
              checked={autoplay}
              onChange={e => {
                setAutoplay(e.target.checked);
                handleSave();
              }}
              className="w-4 h-4 accent-[#1db954] rounded cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Playback Crossfade */}
      <div className="bg-[#181818] p-6 rounded-2xl border border-white/5 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Sliders className="w-4 h-4 text-[#1db954]" />
          <span>Playback Transitions</span>
        </h3>

        <div className="space-y-2">
          <div className="flex justify-between text-xs">
            <span className="text-white font-medium">Crossfade Songs</span>
            <span className="text-[#1db954] font-mono tabular-nums">
              {crossfade === 0 ? 'Off' : `${crossfade}s`}
            </span>
          </div>
          <input
            type="range"
            min="0"
            max="12"
            value={crossfade}
            onChange={e => {
              setCrossfade(Number(e.target.value));
              handleSave();
            }}
            className="w-full"
          />
          <p className="text-[11px] text-[#727272]">
            Allows smooth transitions between consecutive songs in your queue.
          </p>
        </div>
      </div>

      {/* Keyboard Shortcuts Reference */}
      <div className="bg-[#181818] p-6 rounded-2xl border border-white/5 space-y-4">
        <h3 className="text-sm font-bold text-white flex items-center gap-2">
          <Keyboard className="w-4 h-4 text-[#1db954]" />
          <span>Keyboard Shortcuts</span>
        </h3>

        <div className="grid grid-cols-2 gap-3 text-xs">
          <div className="flex items-center justify-between p-2 rounded-lg bg-[#202020]">
            <span className="text-[#a7a7a7]">Play / Pause</span>
            <kbd className="bg-[#282828] text-white px-2 py-0.5 rounded font-mono text-[10px] border border-white/10">
              Space
            </kbd>
          </div>

          <div className="flex items-center justify-between p-2 rounded-lg bg-[#202020]">
            <span className="text-[#a7a7a7]">Mute / Unmute</span>
            <kbd className="bg-[#282828] text-white px-2 py-0.5 rounded font-mono text-[10px] border border-white/10">
              M
            </kbd>
          </div>

          <div className="flex items-center justify-between p-2 rounded-lg bg-[#202020]">
            <span className="text-[#a7a7a7]">Seek -5 seconds</span>
            <kbd className="bg-[#282828] text-white px-2 py-0.5 rounded font-mono text-[10px] border border-white/10">
              ← Left
            </kbd>
          </div>

          <div className="flex items-center justify-between p-2 rounded-lg bg-[#202020]">
            <span className="text-[#a7a7a7]">Seek +5 seconds</span>
            <kbd className="bg-[#282828] text-white px-2 py-0.5 rounded font-mono text-[10px] border border-white/10">
              Right →
            </kbd>
          </div>

          <div className="flex items-center justify-between p-2 rounded-lg bg-[#202020]">
            <span className="text-[#a7a7a7]">Next Track</span>
            <kbd className="bg-[#282828] text-white px-2 py-0.5 rounded font-mono text-[10px] border border-white/10">
              Shift + N
            </kbd>
          </div>

          <div className="flex items-center justify-between p-2 rounded-lg bg-[#202020]">
            <span className="text-[#a7a7a7]">Previous Track</span>
            <kbd className="bg-[#282828] text-white px-2 py-0.5 rounded font-mono text-[10px] border border-white/10">
              Shift + P
            </kbd>
          </div>
        </div>
      </div>
    </div>
  );
};
