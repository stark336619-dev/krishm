import React, { useState, useEffect } from 'react';
import {
  Play,
  Shuffle,
  Clock,
  Music2,
  Edit2,
  Trash2,
  Plus,
  X,
  Search,
} from 'lucide-react';
import { Playlist, Song } from '../types/music';
import { musicRepository } from '../services/musicRepository';
import { useAuth } from '../context/AuthContext';
import { usePlayer } from '../context/PlayerContext';
import { SongRow } from '../components/common/SongRow';
import { formatDuration, getFallbackCoverArt } from '../utils/format';

interface PlaylistPageProps {
  playlistId: string;
  onNavigate: (path: string) => void;
}

export const PlaylistPage: React.FC<PlaylistPageProps> = ({
  playlistId,
  onNavigate,
}) => {
  const { userProfile, isAdmin } = useAuth();
  const { playSong, toggleShuffle } = usePlayer();
  const [playlist, setPlaylist] = useState<Playlist | null>(null);
  const [songs, setSongs] = useState<Song[]>([]);
  const [allAvailableSongs, setAllAvailableSongs] = useState<Song[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Edit Modal State
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editTitle, setEditTitle] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editCoverUrl, setEditCoverUrl] = useState('');

  // Add Songs Search
  const [addSongQuery, setAddSongQuery] = useState('');

  const loadPlaylist = async () => {
    setIsLoading(true);
    const [p, allS] = await Promise.all([
      musicRepository.getPlaylistById(playlistId),
      musicRepository.getSongs(false),
    ]);

    setAllAvailableSongs(allS);
    if (p) {
      setPlaylist(p);
      setEditTitle(p.title);
      setEditDescription(p.description || '');
      setEditCoverUrl(p.coverUrl || '');

      // Resolve song objects in playlist order
      const playlistSongs = p.songIds
        .map(id => allS.find(s => s.id === id))
        .filter((s): s is Song => Boolean(s));
      setSongs(playlistSongs);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    loadPlaylist();
  }, [playlistId]);

  if (isLoading) {
    return (
      <div className="p-10 text-center text-xs text-[#a7a7a7]">
        Loading playlist...
      </div>
    );
  }

  if (!playlist) {
    return (
      <div className="p-10 text-center space-y-3">
        <h2 className="text-xl font-bold text-white">Playlist not found</h2>
        <button
          onClick={() => onNavigate('/library')}
          className="text-xs text-[#1db954] hover:underline"
        >
          Return to Library
        </button>
      </div>
    );
  }

  const isOwner = userProfile?.uid === playlist.ownerId || isAdmin;
  const totalDuration = songs.reduce((acc, s) => acc + s.duration, 0);

  const handlePlayAll = () => {
    if (songs.length > 0) {
      playSong(songs[0], songs);
    }
  };

  const handleShufflePlay = () => {
    if (songs.length > 0) {
      toggleShuffle();
      const randomIndex = Math.floor(Math.random() * songs.length);
      playSong(songs[randomIndex], songs);
    }
  };

  const handleRemoveSong = async (songId: string) => {
    const updatedIds = playlist.songIds.filter(id => id !== songId);
    await musicRepository.updatePlaylist(playlist.id, { songIds: updatedIds });
    loadPlaylist();
  };

  const handleAddSong = async (song: Song) => {
    if (!playlist.songIds.includes(song.id)) {
      const updatedIds = [...playlist.songIds, song.id];
      await musicRepository.updatePlaylist(playlist.id, { songIds: updatedIds });
      loadPlaylist();
    }
  };

  const handleSaveEdit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editTitle.trim()) return;
    await musicRepository.updatePlaylist(playlist.id, {
      title: editTitle.trim(),
      description: editDescription.trim(),
      coverUrl: editCoverUrl.trim(),
    });
    setIsEditOpen(false);
    loadPlaylist();
  };

  const handleDeletePlaylist = async () => {
    if (window.confirm(`Are you sure you want to delete "${playlist.title}"?`)) {
      await musicRepository.deletePlaylist(playlist.id);
      onNavigate('/library');
    }
  };

  const filteredAddSongs = addSongQuery.trim()
    ? allAvailableSongs.filter(
        s =>
          !playlist.songIds.includes(s.id) &&
          (s.title.toLowerCase().includes(addSongQuery.toLowerCase()) ||
            s.artist.toLowerCase().includes(addSongQuery.toLowerCase()))
      )
    : [];

  return (
    <div className="pb-32">
      {/* Header Banner */}
      <div className="bg-gradient-to-b from-[#282828] to-[#121212] p-6 md:p-10 flex flex-col sm:flex-row items-end gap-6 border-b border-white/5">
        <div className="relative group w-44 h-44 rounded-xl overflow-hidden shadow-2xl shrink-0 bg-[#242424]">
          <img
            src={playlist.coverUrl || getFallbackCoverArt(playlist.title, 'playlist')}
            alt={playlist.title}
            className="w-full h-full object-cover"
          />
          {isOwner && (
            <button
              onClick={() => setIsEditOpen(true)}
              className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex flex-col items-center justify-center text-white text-xs gap-1 transition-opacity cursor-pointer"
            >
              <Edit2 className="w-5 h-5" />
              <span>Choose photo</span>
            </button>
          )}
        </div>

        <div className="flex flex-col gap-2 min-w-0 flex-1">
          <span className="text-xs font-bold uppercase tracking-wider text-white">
            {playlist.isPublic ? 'Public Playlist' : 'Private Playlist'}
          </span>
          <h1
            onClick={() => isOwner && setIsEditOpen(true)}
            className={`text-3xl md:text-5xl font-extrabold text-white tracking-tight truncate ${
              isOwner ? 'cursor-pointer hover:underline' : ''
            }`}
          >
            {playlist.title}
          </h1>
          {playlist.description && (
            <p className="text-xs text-[#a7a7a7] line-clamp-2 max-w-2xl">
              {playlist.description}
            </p>
          )}
          <div className="flex items-center gap-2 text-xs text-white/80 font-medium mt-1">
            <span>{playlist.ownerName}</span>
            <span aria-hidden="true">·</span>
            <span>{songs.length} songs</span>
            {songs.length > 0 && (
              <>
                <span aria-hidden="true">·</span>
                <span>{formatDuration(totalDuration)}</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Action Controls */}
      <div className="px-6 md:px-10 py-6 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button
            onClick={handlePlayAll}
            disabled={songs.length === 0}
            className="w-14 h-14 rounded-full bg-[#1db954] text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-transform shadow-xl disabled:opacity-40 disabled:cursor-not-allowed"
          >
            <Play className="w-6 h-6 fill-black ml-1" />
          </button>

          <button
            onClick={handleShufflePlay}
            disabled={songs.length === 0}
            className="p-3 text-[#a7a7a7] hover:text-white transition-colors disabled:opacity-40"
          >
            <Shuffle className="w-6 h-6" />
          </button>
        </div>

        {isOwner && (
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsEditOpen(true)}
              className="p-2 text-[#a7a7a7] hover:text-white rounded-full hover:bg-white/5 transition-colors"
              title="Edit Details"
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button
              onClick={handleDeletePlaylist}
              className="p-2 text-[#a7a7a7] hover:text-red-400 rounded-full hover:bg-white/5 transition-colors"
              title="Delete Playlist"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Tracks Section */}
      <div className="px-6 md:px-10">
        {songs.length === 0 ? (
          <div className="bg-[#181818] rounded-xl p-10 text-center max-w-md mx-auto border border-white/5 space-y-3">
            <Music2 className="w-10 h-10 text-[#727272] mx-auto" />
            <h3 className="text-base font-bold text-white">This playlist is empty</h3>
            <p className="text-xs text-[#a7a7a7]">
              Search below to find and add songs to your playlist.
            </p>
          </div>
        ) : (
          <div className="space-y-1 mb-12">
            <div className="grid grid-cols-12 px-4 py-2 border-b border-white/10 text-xs font-medium text-[#a7a7a7] uppercase tracking-wider mb-2">
              <span className="col-span-1">#</span>
              <span className="col-span-6 md:col-span-6">Title</span>
              <span className="hidden md:block col-span-4">Album</span>
              <div className="col-span-5 md:col-span-1 text-right flex justify-end">
                <Clock className="w-4 h-4" />
              </div>
            </div>

            {songs.map((song, idx) => (
              <SongRow
                key={`${song.id}_pl_${idx}`}
                song={song}
                index={idx}
                contextQueue={songs}
                onRemoveFromPlaylist={isOwner ? handleRemoveSong : undefined}
              />
            ))}
          </div>
        )}

        {/* Add Songs Search Box (if owner) */}
        {isOwner && (
          <div className="border-t border-white/10 pt-8 space-y-4">
            <h3 className="text-lg font-bold text-white">
              Let's find something for your playlist
            </h3>
            <div className="relative max-w-md">
              <Search className="w-4 h-4 text-[#727272] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={addSongQuery}
                onChange={e => setAddSongQuery(e.target.value)}
                placeholder="Search for songs or artists..."
                className="w-full bg-[#242424] text-white text-xs pl-10 pr-4 py-2.5 rounded-full border border-transparent focus:border-white/30 focus:outline-none placeholder-[#727272]"
              />
            </div>

            {filteredAddSongs.length > 0 && (
              <div className="space-y-2 max-w-2xl bg-[#181818] p-3 rounded-xl border border-white/5">
                {filteredAddSongs.slice(0, 5).map(s => (
                  <div
                    key={s.id}
                    className="flex items-center justify-between p-2 rounded-lg hover:bg-[#242424]"
                  >
                    <div className="flex items-center gap-3">
                      <img
                        src={s.coverUrl || getFallbackCoverArt(s.title)}
                        alt={s.title}
                        className="w-10 h-10 rounded object-cover"
                      />
                      <div>
                        <p className="text-xs font-semibold text-white">{s.title}</p>
                        <p className="text-[11px] text-[#a7a7a7]">{s.artist}</p>
                      </div>
                    </div>
                    <button
                      onClick={() => handleAddSong(s)}
                      className="flex items-center gap-1.5 px-3 py-1 rounded-full border border-white/20 text-xs font-medium text-white hover:border-white hover:scale-105 transition-all"
                    >
                      <Plus className="w-3.5 h-3.5" />
                      <span>Add</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </div>

      {/* Edit Playlist Details Modal */}
      {isEditOpen && (
        <div className="fixed inset-0 bg-black/70 backdrop-blur-sm z-50 flex items-center justify-center p-4">
          <div className="bg-[#282828] border border-white/10 rounded-2xl p-6 w-full max-w-md shadow-2xl relative">
            <div className="flex items-center justify-between pb-4 border-b border-white/10">
              <h3 className="text-lg font-bold text-white">Edit Details</h3>
              <button
                onClick={() => setIsEditOpen(false)}
                className="text-[#a7a7a7] hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSaveEdit} className="space-y-4 pt-4">
              <div>
                <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
                  Playlist Title
                </label>
                <input
                  type="text"
                  value={editTitle}
                  onChange={e => setEditTitle(e.target.value)}
                  className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
                  required
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
                  Cover Artwork URL (optional)
                </label>
                <input
                  type="url"
                  value={editCoverUrl}
                  onChange={e => setEditCoverUrl(e.target.value)}
                  placeholder="https://..."
                  className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
                />
              </div>

              <div>
                <label className="text-xs font-semibold text-[#a7a7a7] block mb-1">
                  Description
                </label>
                <textarea
                  value={editDescription}
                  onChange={e => setEditDescription(e.target.value)}
                  rows={3}
                  className="w-full bg-[#181818] border border-white/10 rounded-lg px-3 py-2 text-xs text-white focus:outline-none focus:border-[#1db954]"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setIsEditOpen(false)}
                  className="px-4 py-2 rounded-full text-xs font-semibold text-white hover:bg-white/10"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-5 py-2 rounded-full hover:scale-105 transition-transform"
                >
                  Save Changes
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
