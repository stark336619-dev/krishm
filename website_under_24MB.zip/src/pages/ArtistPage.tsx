import React, { useState, useEffect } from 'react';
import { Play, Shuffle, CheckCircle2, UserPlus, UserCheck } from 'lucide-react';
import { Artist, Song, Album } from '../types/music';
import { musicRepository } from '../services/musicRepository';
import { usePlayer } from '../context/PlayerContext';
import { SongRow } from '../components/common/SongRow';
import { AlbumCard } from '../components/common/AlbumCard';
import { formatNumber, getFallbackCoverArt } from '../utils/format';

interface ArtistPageProps {
  artistId: string;
  onNavigate: (path: string) => void;
}

export const ArtistPage: React.FC<ArtistPageProps> = ({ artistId, onNavigate }) => {
  const { playSong, toggleShuffle } = usePlayer();
  const [artist, setArtist] = useState<Artist | null>(null);
  const [songs, setSongs] = useState<Song[]>([]);
  const [albums, setAlbums] = useState<Album[]>([]);
  const [isFollowing, setIsFollowing] = useState(false);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchArtistData = async () => {
      setIsLoading(true);
      const [allArtists, allSongs, allAlbums] = await Promise.all([
        musicRepository.getArtists(),
        musicRepository.getSongs(false),
        musicRepository.getAlbums(),
      ]);

      // Look up either by id or matching artist name
      const current =
        allArtists.find(a => a.id === artistId) ||
        allArtists.find(a => a.name.toLowerCase() === decodeURIComponent(artistId).toLowerCase());

      const artistName = current ? current.name : decodeURIComponent(artistId);

      if (current) {
        setArtist(current);
      } else {
        // Synthesize artist profile from song catalogue
        setArtist({
          id: artistId,
          name: artistName,
          genres: ['Contemporary'],
          monthlyListeners: 120400,
          isVerified: true,
          createdAt: new Date().toISOString(),
          bio: `${artistName} is an active streaming artist on Sonora.`,
        });
      }

      const artistSongs = allSongs.filter(
        s => s.artist.toLowerCase() === artistName.toLowerCase()
      );
      artistSongs.sort((a, b) => (b.playCount || 0) - (a.playCount || 0));
      setSongs(artistSongs);

      const artistAlbums = allAlbums.filter(
        al => al.artist.toLowerCase() === artistName.toLowerCase()
      );
      setAlbums(artistAlbums);

      setIsLoading(false);
    };

    fetchArtistData();
  }, [artistId]);

  if (isLoading) {
    return (
      <div className="p-10 text-center text-xs text-[#a7a7a7]">
        Loading artist...
      </div>
    );
  }

  if (!artist) {
    return (
      <div className="p-10 text-center space-y-3">
        <h2 className="text-xl font-bold text-white">Artist not found</h2>
        <button
          onClick={() => onNavigate('/')}
          className="text-xs text-[#1db954] hover:underline"
        >
          Return Home
        </button>
      </div>
    );
  }

  const handlePlayAll = () => {
    if (songs.length > 0) {
      playSong(songs[0], songs);
    }
  };

  return (
    <div className="pb-32">
      {/* Hero Header */}
      <div className="bg-gradient-to-b from-[#1c2e26] to-[#121212] p-6 md:p-10 flex flex-col sm:flex-row items-end gap-6 border-b border-white/5">
        <div className="w-44 h-44 rounded-full overflow-hidden shadow-2xl shrink-0 bg-[#242424] border-2 border-white/10">
          <img
            src={artist.photoUrl || getFallbackCoverArt(artist.name, 'artist')}
            alt={artist.name}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="flex flex-col gap-2 min-w-0">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-[#1db954]">
            <CheckCircle2 className="w-4 h-4 fill-[#1db954] text-black" />
            <span>Verified Artist</span>
          </div>
          <h1 className="text-4xl md:text-6xl font-extrabold text-white tracking-tight">
            {artist.name}
          </h1>
          <p className="text-xs text-[#a7a7a7] tabular-nums font-mono">
            {formatNumber(artist.monthlyListeners || 54200)} monthly listeners
          </p>
        </div>
      </div>

      {/* Action Controls */}
      <div className="px-6 md:px-10 py-6 flex items-center gap-4">
        <button
          onClick={handlePlayAll}
          disabled={songs.length === 0}
          className="w-14 h-14 rounded-full bg-[#1db954] text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-transform shadow-xl disabled:opacity-40"
        >
          <Play className="w-6 h-6 fill-black ml-1" />
        </button>

        <button
          onClick={() => setIsFollowing(!isFollowing)}
          className={`flex items-center gap-2 px-5 py-2 rounded-full border text-xs font-bold transition-all ${
            isFollowing
              ? 'border-white/30 text-white hover:border-red-400 hover:text-red-400'
              : 'border-white/20 text-white hover:border-white hover:scale-105'
          }`}
        >
          {isFollowing ? (
            <>
              <UserCheck className="w-4 h-4" />
              <span>Following</span>
            </>
          ) : (
            <>
              <UserPlus className="w-4 h-4" />
              <span>Follow</span>
            </>
          )}
        </button>
      </div>

      {/* Popular Tracks Table */}
      <div className="px-6 md:px-10 space-y-8">
        <div>
          <h2 className="text-xl font-bold text-white mb-4">Popular</h2>
          {songs.length === 0 ? (
            <p className="text-xs text-[#727272]">No songs available for this artist.</p>
          ) : (
            <div className="space-y-1">
              {songs.slice(0, 5).map((song, idx) => (
                <SongRow
                  key={`${song.id}_art_${idx}`}
                  song={song}
                  index={idx}
                  contextQueue={songs}
                />
              ))}
            </div>
          )}
        </div>

        {/* Discography */}
        {albums.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-white">Discography</h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {albums.map(al => (
                <AlbumCard
                  key={al.id}
                  album={al}
                  onClick={() => onNavigate(`/albums/${al.id}`)}
                />
              ))}
            </div>
          </div>
        )}

        {/* Bio */}
        {artist.bio && (
          <div className="space-y-3 bg-[#181818] p-6 rounded-2xl border border-white/5 max-w-2xl">
            <h3 className="text-base font-bold text-white">About</h3>
            <p className="text-xs text-[#a7a7a7] leading-relaxed whitespace-pre-line">
              {artist.bio}
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
