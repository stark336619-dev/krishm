import React, { useState, useEffect } from 'react';
import { Plus, Heart, Music2, Disc, User, Clock, Trash2 } from 'lucide-react';
import { Playlist, Song, Album, Artist, ListeningHistoryItem } from '../types/music';
import { musicRepository } from '../services/musicRepository';
import { useAuth } from '../context/AuthContext';
import { usePlayer } from '../context/PlayerContext';
import { PlaylistCard } from '../components/common/PlaylistCard';
import { AlbumCard } from '../components/common/AlbumCard';
import { ArtistCard } from '../components/common/ArtistCard';
import { SongRow } from '../components/common/SongRow';
import { formatTimeAgo } from '../utils/format';

interface LibraryPageProps {
  onNavigate: (path: string) => void;
  onCreatePlaylist: () => void;
}

type LibraryTab = 'playlists' | 'liked' | 'history' | 'albums' | 'artists';

export const LibraryPage: React.FC<LibraryPageProps> = ({
  onNavigate,
  onCreatePlaylist,
}) => {
  const { userProfile } = useAuth();
  const { playSong } = usePlayer();
  const [activeTab, setActiveTab] = useState<LibraryTab>('playlists');
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [likedSongs, setLikedSongs] = useState<Song[]>([]);
  const [history, setHistory] = useState<ListeningHistoryItem[]>([]);
  const [albums, setAlbums] = useState<Album[]>([]);
  const [artists, setArtists] = useState<Artist[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchLibraryData = async () => {
      setIsLoading(true);
      const [allPlaylists, allSongs, allAlbums, allArtists] = await Promise.all([
        musicRepository.getPlaylists(userProfile?.uid),
        musicRepository.getSongs(false),
        musicRepository.getAlbums(),
        musicRepository.getArtists(),
      ]);

      setPlaylists(allPlaylists);
      setAlbums(allAlbums);
      setArtists(allArtists);

      if (userProfile?.uid) {
        const likedIds = await musicRepository.getUserLikes(userProfile.uid);
        const userLikedSongs = allSongs.filter(s => likedIds.includes(s.id));
        setLikedSongs(userLikedSongs);

        const userHistory = await musicRepository.getUserHistory(userProfile.uid);
        setHistory(userHistory);
      }
      setIsLoading(false);
    };

    fetchLibraryData();
  }, [userProfile?.uid]);

  return (
    <div className="p-6 md:p-8 space-y-6 pb-32">
      {/* Header and Filter Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            Your Library
          </h1>
          <p className="text-xs text-[#a7a7a7] mt-1">
            Playlists, favorite tracks, and listening records
          </p>
        </div>

        <button
          onClick={onCreatePlaylist}
          className="flex items-center gap-2 bg-[#282828] hover:bg-[#333333] text-white font-medium text-xs px-4 py-2 rounded-full border border-white/10 transition-colors w-fit"
        >
          <Plus className="w-4 h-4 text-[#1db954]" />
          <span>New Playlist</span>
        </button>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 custom-scroll">
        {[
          { id: 'playlists', label: `Playlists (${playlists.length})` },
          { id: 'liked', label: `Liked Songs (${likedSongs.length})` },
          { id: 'history', label: `History (${history.length})` },
          { id: 'albums', label: `Albums (${albums.length})` },
          { id: 'artists', label: `Artists (${artists.length})` },
        ].map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id as LibraryTab)}
            className={`px-4 py-1.5 rounded-full text-xs font-semibold transition-colors shrink-0 ${
              activeTab === tab.id
                ? 'bg-white text-black'
                : 'bg-[#242424] text-white hover:bg-[#303030]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Playlists Grid */}
      {activeTab === 'playlists' && (
        <div>
          {playlists.length === 0 ? (
            <div className="bg-[#181818] rounded-xl p-10 text-center max-w-md mx-auto border border-white/5 space-y-3">
              <Music2 className="w-10 h-10 text-[#727272] mx-auto" />
              <h3 className="text-sm font-bold text-white">Create your first playlist</h3>
              <p className="text-xs text-[#a7a7a7]">
                It's easy, we'll help you organize your music.
              </p>
              <button
                onClick={onCreatePlaylist}
                className="bg-white text-black text-xs font-bold px-4 py-2 rounded-full hover:scale-105 transition-transform"
              >
                Create Playlist
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {playlists.map(pl => (
                <PlaylistCard
                  key={pl.id}
                  playlist={pl}
                  onClick={() => onNavigate(`/playlists/${pl.id}`)}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Liked Songs */}
      {activeTab === 'liked' && (
        <div>
          {likedSongs.length === 0 ? (
            <div className="bg-[#181818] rounded-xl p-10 text-center max-w-md mx-auto border border-white/5 space-y-3">
              <Heart className="w-10 h-10 text-[#727272] mx-auto" />
              <h3 className="text-sm font-bold text-white">Songs you like will appear here</h3>
              <p className="text-xs text-[#a7a7a7]">
                Save songs by tapping the heart icon on any track row or player dock.
              </p>
              <button
                onClick={() => onNavigate('/')}
                className="bg-white text-black text-xs font-bold px-4 py-2 rounded-full hover:scale-105 transition-transform"
              >
                Find Songs
              </button>
            </div>
          ) : (
            <div className="space-y-1">
              {likedSongs.map((song, idx) => (
                <SongRow
                  key={song.id}
                  song={song}
                  index={idx}
                  contextQueue={likedSongs}
                />
              ))}
            </div>
          )}
        </div>
      )}

      {/* Listening History */}
      {activeTab === 'history' && (
        <div className="space-y-3">
          {history.length === 0 ? (
            <div className="bg-[#181818] rounded-xl p-10 text-center max-w-md mx-auto border border-white/5 space-y-3">
              <Clock className="w-10 h-10 text-[#727272] mx-auto" />
              <h3 className="text-sm font-bold text-white">No listening history yet</h3>
              <p className="text-xs text-[#a7a7a7]">
                Tracks you stream for more than 15 seconds will appear here.
              </p>
            </div>
          ) : (
            <div className="bg-[#181818] rounded-xl border border-white/5 overflow-hidden">
              <div className="divide-y divide-white/5">
                {history.map(item => (
                  <div
                    key={item.id}
                    className="p-3 px-4 flex items-center justify-between hover:bg-[#222222] transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <Music2 className="w-4 h-4 text-[#1db954]" />
                      <div>
                        <p className="text-xs font-semibold text-white">
                          {item.songTitle}
                        </p>
                        <p className="text-[11px] text-[#a7a7a7]">{item.artist}</p>
                      </div>
                    </div>
                    <span className="text-[11px] text-[#727272]">
                      {formatTimeAgo(item.playedAt)}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Saved Albums */}
      {activeTab === 'albums' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {albums.map(al => (
            <AlbumCard
              key={al.id}
              album={al}
              onClick={() => onNavigate(`/albums/${al.id}`)}
            />
          ))}
        </div>
      )}

      {/* Artists */}
      {activeTab === 'artists' && (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
          {artists.map(ar => (
            <ArtistCard
              key={ar.id}
              artist={ar}
              onClick={() => onNavigate(`/artists/${ar.id}`)}
            />
          ))}
        </div>
      )}
    </div>
  );
};
