import React, { useEffect, useState, useMemo } from 'react';
import { Play, Sparkles, Plus, Disc, Radio, Music, Globe, ExternalLink } from 'lucide-react';
import { Song, Album, Artist, Playlist } from '../types/music';
import { musicRepository } from '../services/musicRepository';
import { unifiedMusicService, SUPPORTED_LANGUAGES } from '../services/unifiedMusicService';
import { ProviderTrack } from '../types/providers';
import { usePlayer } from '../context/PlayerContext';
import { useAuth } from '../context/AuthContext';
import { useSpotify } from '../context/SpotifyContext';
import { SongCard } from '../components/common/SongCard';
import { AlbumCard } from '../components/common/AlbumCard';
import { ArtistCard } from '../components/common/ArtistCard';
import { PlaylistCard } from '../components/common/PlaylistCard';
import { getFallbackCoverArt } from '../utils/format';

interface HomePageProps {
  onNavigate: (path: string) => void;
}

function deduplicateSongs(songList: Song[]): Song[] {
  const seenIds = new Set<string>();
  const seenTracks = new Set<string>();
  const result: Song[] = [];
  for (const s of songList) {
    if (!s || !s.id) continue;
    const titleKey = `${(s.title || '').trim().toLowerCase()}___${(s.artist || '').trim().toLowerCase()}`;
    if (!seenIds.has(s.id) && !seenTracks.has(titleKey)) {
      seenIds.add(s.id);
      seenTracks.add(titleKey);
      result.push(s);
    }
  }
  return result;
}

function trackToSong(t: ProviderTrack): Song {
  return {
    id: t.id,
    title: t.title,
    artist: t.artist,
    album: t.album,
    albumId: t.albumId,
    coverUrl: t.coverUrl,
    audioUrl: t.audioUrl || '',
    duration: t.duration,
    genre: t.genre,
    language: t.language,
    releaseDate: t.releaseDate,
    isPublished: true,
    playCount: t.playCount || 0,
    provider: t.provider,
    providerId: t.providerId,
    externalUrl: t.externalUrl,
    hasFullPlayback: t.hasFullPlayback,
    embedUrl: t.embedUrl,
    license: t.license,
  };
}

export const HomePage: React.FC<HomePageProps> = ({ onNavigate }) => {
  const { playSong } = usePlayer();
  const { isAdmin } = useAuth();
  const { isConnected: isSpotifyConnected, spotifyUser } = useSpotify();

  const [songs, setSongs] = useState<Song[]>([]);
  const [albums, setAlbums] = useState<Album[]>([]);
  const [artists, setArtists] = useState<Artist[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Discovery & Language Filter
  const [selectedLanguage, setSelectedLanguage] = useState('All');
  const [discoveredTracks, setDiscoveredTracks] = useState<Song[]>([]);
  const [regionalSpotlight, setRegionalSpotlight] = useState<Song[]>([]);
  const [globalCurated, setGlobalCurated] = useState<Song[]>([]);
  const [isDiscovering, setIsDiscovering] = useState(false);

  // STERNITERS Curated Home Feed (Garba, Punjabi, Romance, Lo-Fi, Classics, Artists)
  const [curatedHome, setCuratedHome] = useState<{
    gujarati: Song[];
    punjabi: Song[];
    romance: Song[];
    lofi: Song[];
    classics: Song[];
    artists: Array<{ id: string; name: string; query: string; image: string }>;
  } | null>(null);

  const loadData = async () => {
    setIsLoading(true);
    const [fetchedSongs, fetchedAlbums, fetchedArtists, fetchedPlaylists] =
      await Promise.all([
        musicRepository.getSongs(false),
        musicRepository.getAlbums(),
        musicRepository.getArtists(),
        musicRepository.getPlaylists(),
      ]);
    setSongs(fetchedSongs);
    setAlbums(fetchedAlbums);
    setArtists(fetchedArtists);
    setPlaylists(fetchedPlaylists);
    setIsLoading(false);
  };

  useEffect(() => {
    loadData();

    // Fetch STERNITERS curated feed
    unifiedMusicService.getHomeFeed().then(feed => {
      if (!feed) return;
      setCuratedHome({
        gujarati: feed.gujarati.map(trackToSong),
        punjabi: feed.punjabi.map(trackToSong),
        romance: feed.romance.map(trackToSong),
        lofi: feed.lofi.map(trackToSong),
        classics: feed.classics.map(trackToSong),
        artists: feed.artists,
      });
    }).catch(() => {});
  }, []);

  // Fetch live discovery feed whenever selected language changes
  useEffect(() => {
    let isMounted = true;
    setIsDiscovering(true);
    unifiedMusicService
      .getDiscoveryFeed(selectedLanguage)
      .then(feed => {
        if (!isMounted) return;
        setDiscoveredTracks(feed.trending.map(trackToSong));
        setRegionalSpotlight(feed.spotlight.map(trackToSong));
        setGlobalCurated(feed.curated.map(trackToSong));
        setIsDiscovering(false);
      })
      .catch(() => {
        if (isMounted) setIsDiscovering(false);
      });

    return () => {
      isMounted = false;
    };
  }, [selectedLanguage]);

  // Time-aware greeting
  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  // Combine local library + automated discovery with strict deduplication
  const allTrending = useMemo(() => {
    return deduplicateSongs([...songs, ...discoveredTracks]).slice(0, 12);
  }, [songs, discoveredTracks]);

  const jumpBackInSongs = useMemo(() => {
    return allTrending.slice(0, 6);
  }, [allTrending]);

  const cleanRegionalSpotlight = useMemo(() => {
    return deduplicateSongs(regionalSpotlight);
  }, [regionalSpotlight]);

  const cleanGlobalCurated = useMemo(() => {
    return deduplicateSongs(globalCurated);
  }, [globalCurated]);

  return (
    <div className="p-6 md:p-8 space-y-8 pb-32">
      {/* Top Greeting Banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-white tracking-tight">
            {getGreeting()}
            {spotifyUser ? `, ${spotifyUser.displayName}` : ''}
          </h1>
          <p className="text-xs text-[#a7a7a7] mt-1">
            Discover music in Gujarati, Hindi, Punjabi, Tamil, English, and beyond.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {isSpotifyConnected ? (
            <div className="flex items-center gap-2 bg-[#1db954]/10 border border-[#1db954]/30 text-[#1db954] text-xs font-semibold px-3 py-1.5 rounded-full">
              <Globe className="w-3.5 h-3.5" />
              <span>Spotify Linked</span>
            </div>
          ) : (
            <button
              onClick={() => onNavigate('/settings')}
              className="text-xs text-[#a7a7a7] hover:text-white flex items-center gap-1.5 bg-[#202020] px-3 py-1.5 rounded-full border border-white/5 transition-colors"
            >
              <Globe className="w-3.5 h-3.5 text-[#1db954]" />
              <span>Connect Spotify</span>
            </button>
          )}

          {isAdmin && (
            <button
              onClick={() => onNavigate('/admin/songs/new')}
              className="flex items-center gap-1.5 bg-[#1db954] hover:bg-[#1ed760] text-black font-bold text-xs px-3.5 py-1.5 rounded-full transition-transform hover:scale-105"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Song</span>
            </button>
          )}
        </div>
      </div>

      {/* Language Filter Pills */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs font-semibold text-[#a7a7a7] uppercase tracking-wider">
            Explore by Language
          </span>
          {isDiscovering && (
            <span className="text-[11px] text-[#1db954] animate-pulse">
              Finding {selectedLanguage} music...
            </span>
          )}
        </div>
        <div className="flex items-center gap-2 overflow-x-auto pb-1 custom-scroll">
          {SUPPORTED_LANGUAGES.map(lang => {
            const isSelected = selectedLanguage === lang.id;
            return (
              <button
                key={lang.id}
                onClick={() => setSelectedLanguage(lang.id)}
                className={`px-3.5 py-1.5 rounded-full text-xs font-semibold transition-all shrink-0 flex items-center gap-1.5 ${
                  isSelected
                    ? 'bg-[#1db954] text-black font-bold shadow-md shadow-[#1db954]/20'
                    : 'bg-[#242424] text-white hover:bg-[#303030] hover:text-white'
                }`}
              >
                <span>{lang.native}</span>
                {lang.id !== 'All' && (
                  <span className={`text-[10px] ${isSelected ? 'text-black/70' : 'text-[#a7a7a7]'}`}>
                    ({lang.label})
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* Quick Jump-in Grid (6 rectangular tiles, Spotify style) */}
      {jumpBackInSongs.length > 0 && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {jumpBackInSongs.map((song, idx) => (
            <div
              key={`${song.id}_jump_${idx}`}
              onClick={() => playSong(song, allTrending)}
              className="group flex items-center bg-[#282828]/60 hover:bg-[#282828] rounded-md overflow-hidden cursor-pointer transition-colors shadow-sm relative pr-4"
            >
              <img
                src={song.coverUrl || getFallbackCoverArt(song.title)}
                alt={song.title}
                className="w-16 h-16 object-cover shrink-0 shadow-md"
              />
              <div className="p-3 min-w-0 flex-1">
                <p className="text-xs font-bold text-white truncate">{song.title}</p>
                <p className="text-[11px] text-[#a7a7a7] truncate">{song.artist}</p>
              </div>
              <div className="w-10 h-10 rounded-full bg-[#1db954] text-black flex items-center justify-center shadow-lg opacity-0 group-hover:opacity-100 transition-all duration-200 hover:scale-105 shrink-0">
                <Play className="w-4 h-4 fill-black ml-0.5" />
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Trending Tracks */}
      {allTrending.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                <span>Trending {selectedLanguage === 'All' ? 'Now' : `in ${selectedLanguage}`}</span>
                <Sparkles className="w-4 h-4 text-[#1ed760]" />
              </h2>
              <p className="text-xs text-[#a7a7a7]">
                Live streamed and discovered across regional and global music charts
              </p>
            </div>
            <button
              onClick={() => onNavigate('/search')}
              className="text-xs font-semibold text-[#a7a7a7] hover:text-white transition-colors"
            >
              Search more
            </button>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {allTrending.map((song, idx) => (
              <SongCard key={`${song.id}_trend_${idx}`} song={song} contextQueue={allTrending} />
            ))}
          </div>
        </section>
      )}

      {/* Gujarati Garba & Folk Hits */}
      {curatedHome?.gujarati && curatedHome.gujarati.length > 0 && (selectedLanguage === 'All' || selectedLanguage === 'Gujarati') && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                <span>ગુજરાતી ગરબા & લોકગીત (Gujarati Folk & Garba)</span>
                <Radio className="w-4 h-4 text-amber-400" />
              </h2>
              <p className="text-xs text-[#a7a7a7]">
                Kinjal Dave, Geeta Rabari, Kirtidan Gadhvi, Aditya Gadhvi & trending Navratri garba
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {curatedHome.gujarati.slice(0, 6).map((song, idx) => (
              <SongCard key={`${song.id}_guj_${idx}`} song={song} contextQueue={curatedHome.gujarati} />
            ))}
          </div>
        </section>
      )}

      {/* Bollywood Romance & Melodies */}
      {curatedHome?.romance && curatedHome.romance.length > 0 && (selectedLanguage === 'All' || selectedLanguage === 'Hindi') && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                <span>Bollywood Romance & Melodies</span>
                <Sparkles className="w-4 h-4 text-rose-400" />
              </h2>
              <p className="text-xs text-[#a7a7a7]">
                Arijit Singh, Shreya Ghoshal, Atif Aslam, Pritam & iconic love ballads
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {curatedHome.romance.slice(0, 6).map((song, idx) => (
              <SongCard key={`${song.id}_rom_${idx}`} song={song} contextQueue={curatedHome.romance} />
            ))}
          </div>
        </section>
      )}

      {/* Punjabi Bangers */}
      {curatedHome?.punjabi && curatedHome.punjabi.length > 0 && (selectedLanguage === 'All' || selectedLanguage === 'Punjabi') && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                <span>ਪੰਜਾਬੀ ਬੀਟਸ (Punjabi Top Hits)</span>
                <Disc className="w-4 h-4 text-orange-400" />
              </h2>
              <p className="text-xs text-[#a7a7a7]">
                Diljit Dosanjh, Karan Aujla, AP Dhillon, Sidhu Moose Wala & high-energy beats
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {curatedHome.punjabi.slice(0, 6).map((song, idx) => (
              <SongCard key={`${song.id}_pun_${idx}`} song={song} contextQueue={curatedHome.punjabi} />
            ))}
          </div>
        </section>
      )}

      {/* Lo-Fi Chill & Slowed Nights */}
      {curatedHome?.lofi && curatedHome.lofi.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                <span>Lo-Fi Chill & Late Night Slowed</span>
                <Radio className="w-4 h-4 text-teal-400" />
              </h2>
              <p className="text-xs text-[#a7a7a7]">
                Husn, Sajni, Heeriye, O Maahi, acoustic reverbs & mellow study vibes
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {curatedHome.lofi.slice(0, 6).map((song, idx) => (
              <SongCard key={`${song.id}_lofi_${idx}`} song={song} contextQueue={curatedHome.lofi} />
            ))}
          </div>
        </section>
      )}

      {/* Evergreen Classics */}
      {curatedHome?.classics && curatedHome.classics.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                <span>90s & Evergreen Golden Classics</span>
                <Music className="w-4 h-4 text-emerald-400" />
              </h2>
              <p className="text-xs text-[#a7a7a7]">
                Kishore Kumar, Lata Mangeshkar, RD Burman, Kumar Sanu & timeless nostalgia
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {curatedHome.classics.slice(0, 6).map((song, idx) => (
              <SongCard key={`${song.id}_classic_${idx}`} song={song} contextQueue={curatedHome.classics} />
            ))}
          </div>
        </section>
      )}

      {/* Popular Artists Grid from STERNITERS */}
      {curatedHome?.artists && curatedHome.artists.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Top Featured Artists</h2>
              <p className="text-xs text-[#a7a7a7]">Tap any artist to discover their catalog</p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            {curatedHome.artists.map(art => (
              <div
                key={art.id}
                onClick={() => onNavigate(`/search?q=${encodeURIComponent(art.name)}`)}
                className="group flex flex-col items-center bg-[#181818]/60 hover:bg-[#202020] p-3 rounded-xl border border-white/5 hover:border-white/10 cursor-pointer transition-all hover:scale-105"
              >
                <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-full overflow-hidden mb-2 shadow-lg relative">
                  <img src={art.image} alt={art.name} className="w-full h-full object-cover" />
                </div>
                <span className="text-xs font-bold text-white text-center line-clamp-1 group-hover:text-[#1ed760] transition-colors">
                  {art.name}
                </span>
                <span className="text-[10px] text-[#808080]">Artist</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Regional Spotlight */}
      {cleanRegionalSpotlight.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                <span>{selectedLanguage === 'All' ? 'Indian Regional' : selectedLanguage} Spotlight</span>
                <Radio className="w-4 h-4 text-purple-400" />
              </h2>
              <p className="text-xs text-[#a7a7a7]">
                Authentic vocalists, film soundtracks, and folk hits
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {cleanRegionalSpotlight.map((song, idx) => (
              <SongCard key={`${song.id}_spot_${idx}`} song={song} contextQueue={cleanRegionalSpotlight} />
            ))}
          </div>
        </section>
      )}

      {/* Global Creative Commons Discovery */}
      {cleanGlobalCurated.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                <span>Global Independent Music</span>
                <Disc className="w-4 h-4 text-rose-400" />
              </h2>
              <p className="text-xs text-[#a7a7a7]">
                Full length licensed tracks via Jamendo Music
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {cleanGlobalCurated.map((song, idx) => (
              <SongCard key={`${song.id}_cur_${idx}`} song={song} contextQueue={cleanGlobalCurated} />
            ))}
          </div>
        </section>
      )}

      {/* Popular Albums */}
      {albums.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Popular Albums</h2>
              <p className="text-xs text-[#a7a7a7]">Full-length records and EPs</p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {albums.map(album => (
              <AlbumCard
                key={album.id}
                album={album}
                onClick={() => onNavigate(`/albums/${album.id}`)}
              />
            ))}
          </div>
        </section>
      )}

      {/* Curated Playlists */}
      {playlists.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Featured Playlists</h2>
              <p className="text-xs text-[#a7a7a7]">Handpicked moods and genres</p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {playlists.map(playlist => (
              <PlaylistCard
                key={playlist.id}
                playlist={playlist}
                onClick={() => onNavigate(`/playlists/${playlist.id}`)}
              />
            ))}
          </div>
        </section>
      )}

      {/* Popular Artists */}
      {artists.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold text-white tracking-tight">Popular Artists</h2>
              <p className="text-xs text-[#a7a7a7]">Discover independent creators</p>
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {artists.map(artist => (
              <ArtistCard
                key={artist.id}
                artist={artist}
                onClick={() => onNavigate(`/artists/${artist.id}`)}
              />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
