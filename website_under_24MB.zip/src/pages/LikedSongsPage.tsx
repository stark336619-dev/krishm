import React, { useState, useEffect } from 'react';
import { Heart, Play, Shuffle, Clock, Music } from 'lucide-react';
import { Song } from '../types/music';
import { musicRepository } from '../services/musicRepository';
import { useAuth } from '../context/AuthContext';
import { usePlayer } from '../context/PlayerContext';
import { SongRow } from '../components/common/SongRow';
import { formatDuration } from '../utils/format';

interface LikedSongsPageProps {
  onNavigate: (path: string) => void;
}

export const LikedSongsPage: React.FC<LikedSongsPageProps> = ({ onNavigate }) => {
  const { userProfile } = useAuth();
  const { playSong, toggleShuffle } = usePlayer();
  const [likedSongs, setLikedSongs] = useState<Song[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchLiked = async () => {
      setIsLoading(true);
      if (!userProfile?.uid) {
        setIsLoading(false);
        return;
      }
      const [allSongs, likedIds] = await Promise.all([
        musicRepository.getSongs(false),
        musicRepository.getUserLikes(userProfile.uid),
      ]);
      const matched = allSongs.filter(s => likedIds.includes(s.id));
      setLikedSongs(matched);
      setIsLoading(false);
    };
    fetchLiked();
  }, [userProfile?.uid]);

  const totalDuration = likedSongs.reduce((acc, song) => acc + song.duration, 0);

  const handlePlayAll = () => {
    if (likedSongs.length > 0) {
      playSong(likedSongs[0], likedSongs);
    }
  };

  const handleShufflePlay = () => {
    if (likedSongs.length > 0) {
      toggleShuffle();
      const randomIndex = Math.floor(Math.random() * likedSongs.length);
      playSong(likedSongs[randomIndex], likedSongs);
    }
  };

  return (
    <div className="pb-32">
      {/* Header Banner */}
      <div className="bg-gradient-to-b from-[#450af5] to-[#121212] p-6 md:p-10 flex flex-col sm:flex-row items-end gap-6">
        <div className="w-44 h-44 rounded-xl bg-gradient-to-br from-[#450af5] to-[#c4efd9] shadow-2xl flex items-center justify-center shrink-0">
          <Heart className="w-20 h-20 text-white fill-white" />
        </div>
        <div className="flex flex-col gap-2 min-w-0">
          <span className="text-xs font-bold uppercase tracking-wider text-white">
            Playlist
          </span>
          <h1 className="text-4xl md:text-6xl font-extrabold text-white tracking-tight">
            Liked Songs
          </h1>
          <div className="flex items-center gap-2 text-xs text-white/80 font-medium">
            <span>{userProfile?.displayName || 'Sonora Listener'}</span>
            <span aria-hidden="true">·</span>
            <span>{likedSongs.length} songs</span>
            {likedSongs.length > 0 && (
              <>
                <span aria-hidden="true">·</span>
                <span>{formatDuration(totalDuration)}</span>
              </>
            )}
          </div>
        </div>
      </div>

      {/* Action Controls */}
      <div className="px-6 md:px-10 py-6 flex items-center gap-4">
        <button
          onClick={handlePlayAll}
          disabled={likedSongs.length === 0}
          className="w-14 h-14 rounded-full bg-[#1db954] text-black flex items-center justify-center hover:scale-105 active:scale-95 transition-transform shadow-xl disabled:opacity-40 disabled:cursor-not-allowed"
          title="Play Liked Songs"
        >
          <Play className="w-6 h-6 fill-black ml-1" />
        </button>

        <button
          onClick={handleShufflePlay}
          disabled={likedSongs.length === 0}
          className="p-3 text-[#a7a7a7] hover:text-white transition-colors disabled:opacity-40"
          title="Shuffle Liked Songs"
        >
          <Shuffle className="w-6 h-6" />
        </button>
      </div>

      {/* Track List */}
      <div className="px-6 md:px-10">
        {likedSongs.length === 0 ? (
          <div className="bg-[#181818] rounded-xl p-12 text-center max-w-md mx-auto border border-white/5 space-y-3">
            <Music className="w-12 h-12 text-[#727272] mx-auto" />
            <h3 className="text-base font-bold text-white">No liked songs yet</h3>
            <p className="text-xs text-[#a7a7a7]">
              Explore the music catalog and click the heart icon on any track to save it here.
            </p>
            <button
              onClick={() => onNavigate('/')}
              className="bg-white text-black font-bold text-xs px-5 py-2.5 rounded-full hover:scale-105 transition-transform"
            >
              Explore Music
            </button>
          </div>
        ) : (
          <div className="space-y-1">
            <div className="grid grid-cols-12 px-4 py-2 border-b border-white/10 text-xs font-medium text-[#a7a7a7] uppercase tracking-wider mb-2">
              <span className="col-span-1">#</span>
              <span className="col-span-6 md:col-span-6">Title</span>
              <span className="hidden md:block col-span-4">Album</span>
              <div className="col-span-5 md:col-span-1 text-right flex justify-end">
                <Clock className="w-4 h-4" />
              </div>
            </div>

            {likedSongs.map((song, idx) => (
              <SongRow
                key={`${song.id}_liked_${idx}`}
                song={song}
                index={idx}
                contextQueue={likedSongs}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
