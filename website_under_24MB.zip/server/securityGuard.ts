import type { Request, Response, NextFunction } from 'express';
import { URL } from 'url';
import net from 'net';
import crypto from 'crypto';

// ============================================================================
// AUTOMATIC BACKEND SECURITY GUARD — KRISH MUSIC (STAGE 2 HARDENED)
// Operates silently in the background on every request.
//
// 1. Strict SSRF Protection (DNS rebinding, manual redirect re-validation, IP alternate representations, cloud metadata).
// 2. Strict CDN Hostname & Boundary Validation (exact domain boundary matching).
// 3. Strict CORS Origin Policy (zero wildcard leakage for credentials/state).
// 4. Server-Side Fail-Closed Admin Authorization & Constant-Time Secret Comparison.
// 5. Leak-Proof Redacted Logging (X-Admin-Key & Authorization tokens never logged).
// 6. Sliding-Window Rate Limiting (documented instance-local scope).
// 7. Production Content-Security-Policy (CSP) & HSTS headers.
// 8. Request Body Size Capping (JSON & URL-Encoded).
// 9. Method Restriction (rejects TRACE, TRACK, CONNECT, etc.).
// ============================================================================

// -------------------------------------------------------------
// 1. CONFIGURATION & SECRETS
// -------------------------------------------------------------
const ADMIN_SECRET = (process.env.ADMIN_API_SECRET || process.env.KRISH_ADMIN_SECRET || '').trim();

// Strict trusted audio/media CDN domain boundaries
const TRUSTED_CDN_DOMAINS = [
  'saavncdn.com',
  'jiosaavn.com',
  'akamaized.net',
  'scdn.co',
  'spotifycdn.com',
  'images.unsplash.com',
  'lrclib.net',
  'googleusercontent.com',
];

// -------------------------------------------------------------
// 2. TIMING-SAFE SECRET COMPARISON (FAIL-CLOSED)
// -------------------------------------------------------------
export function secureCompare(a: string, b: string): boolean {
  if (!a || !b) return false;
  const bufA = Buffer.from(a, 'utf8');
  const bufB = Buffer.from(b, 'utf8');

  if (bufA.length !== bufB.length) {
    // Constant-time dummy comparison to prevent length timing side-channels
    crypto.timingSafeEqual(bufA, bufA);
    return false;
  }
  return crypto.timingSafeEqual(bufA, bufB);
}

// -------------------------------------------------------------
// 3. HTTP SECURITY HEADERS & CSP MIDDLEWARE
// -------------------------------------------------------------
export function securityHeadersMiddleware(req: Request, res: Response, next: NextFunction): void {
  // Prevent MIME type sniffing
  res.setHeader('X-Content-Type-Options', 'nosniff');

  // Modern browsers XSS protection
  res.setHeader('X-XSS-Protection', '1; mode=block');

  // Allow iframe embedding in Google AI Studio and preview environments (remove X-Frame-Options SAMEORIGIN)
  // Referrer Policy: Send full referrer on same-origin, only origin on HTTPS cross-origin
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');

  // Restrict sensitive browser features not needed by music streaming
  res.setHeader(
    'Permissions-Policy',
    'camera=(), microphone=(), geolocation=(), payment=(), usb=()'
  );

  // Permit audio streams and CDN images to be loaded
  res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');

  // Strict-Transport-Security (HSTS) for HTTPS connections
  const isHttps = req.secure || req.headers['x-forwarded-proto'] === 'https';
  if (isHttps) {
    res.setHeader('Strict-Transport-Security', 'max-age=31536000; includeSubDomains');
  }

  // Tailored Content Security Policy allowing AI Studio iframe previews and media playback
  const csp = [
    "default-src 'self' 'unsafe-inline' data: blob:",
    "script-src 'self' 'unsafe-inline' 'unsafe-eval' blob: https://apis.google.com https://www.gstatic.com",
    "style-src 'self' 'unsafe-inline' https://fonts.googleapis.com",
    "font-src 'self' https://fonts.gstatic.com data:",
    "img-src 'self' data: blob: https: http:",
    "media-src 'self' blob: data: https: http:",
    "connect-src 'self' ws: wss: https: http:",
    "frame-src 'self' https://accounts.google.com https://*.firebaseapp.com https://*.google.com https://*.run.app",
    "frame-ancestors 'self' https://*.google.com https://*.run.app https://*.ai.studio https://aistudio.google.com https://studio.google.com https://*.googleusercontent.com",
  ].join('; ');

  res.setHeader('Content-Security-Policy', csp);

  // Hide technology fingerprint
  res.removeHeader('X-Powered-By');

  next();
}

// -------------------------------------------------------------
// 4. HTTP METHOD RESTRICTION MIDDLEWARE
// -------------------------------------------------------------
export function methodGuardMiddleware(req: Request, res: Response, next: NextFunction): void {
  const allowedMethods = ['GET', 'POST', 'OPTIONS', 'HEAD'];
  if (!allowedMethods.includes(req.method.toUpperCase())) {
    res.status(405).json({ error: `Method ${req.method} is not permitted.` });
    return;
  }
  next();
}

// -------------------------------------------------------------
// 5. STRICT CORS MIDDLEWARE (NO UNSAFE WILDCARDS)
// -------------------------------------------------------------
function isOriginAllowed(origin: string): boolean {
  if (!origin) return false;

  try {
    const parsed = new URL(origin);
    const host = parsed.hostname.toLowerCase();

    // Local development
    if (host === 'localhost' || host === '127.0.0.1') return true;

    // AI Studio and Cloud Run environments
    if (host.endsWith('.run.app') || host.endsWith('.googleusercontent.com') || host.endsWith('.aistudio.google.com')) {
      return true;
    }

    // Firebase hosting domains
    if (host.endsWith('.firebaseapp.com') || host.endsWith('.web.app')) {
      return true;
    }

    return false;
  } catch {
    return false;
  }
}

export function dynamicCorsMiddleware(req: Request, res: Response, next: NextFunction): void {
  const origin = req.headers.origin as string | undefined;

  if (origin) {
    if (isOriginAllowed(origin)) {
      res.setHeader('Access-Control-Allow-Origin', origin);
      res.setHeader('Access-Control-Allow-Credentials', 'true');
      res.setHeader('Vary', 'Origin');
    } else {
      // Untrusted cross-origin origin: do NOT set Access-Control-Allow-Origin
      if (req.method === 'OPTIONS') {
        res.status(403).end('CORS origin forbidden');
        return;
      }
    }
  }

  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, HEAD');
  res.setHeader(
    'Access-Control-Allow-Headers',
    'Content-Type, Authorization, Range, X-Requested-With, X-Admin-Key, Cache-Control'
  );
  res.setHeader('Access-Control-Max-Age', '86400');

  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }

  next();
}

// -------------------------------------------------------------
// 6. IN-MEMORY SLIDING WINDOW RATE LIMITER (INSTANCE-LOCAL)
// Note: Operates per Cloud Run instance container. For distributed
// multi-replica rate limiting, a shared Redis or Firestore counter is required.
// -------------------------------------------------------------
interface RateLimitBucket {
  count: number;
  resetAt: number;
  penalties: number;
}

const rateLimitStore = new Map<string, RateLimitBucket>();

// Automatic cleanup every 5 minutes
setInterval(() => {
  const now = Date.now();
  for (const [key, bucket] of rateLimitStore.entries()) {
    if (now > bucket.resetAt + 60000) {
      rateLimitStore.delete(key);
    }
  }
}, 5 * 60 * 1000);

export function createRateLimiter(options: {
  max: number;
  windowMs: number;
  tierName?: string;
}) {
  const { max, windowMs, tierName = 'api' } = options;

  return (req: Request, res: Response, next: NextFunction): void => {
    const forwarded = req.headers['x-forwarded-for'];
    const ip =
      (typeof forwarded === 'string' ? forwarded.split(',')[0].trim() : req.socket.remoteAddress) ||
      '127.0.0.1';
    const key = `${tierName}:${ip}`;
    const now = Date.now();

    let bucket = rateLimitStore.get(key);
    if (!bucket || now > bucket.resetAt) {
      bucket = {
        count: 1,
        resetAt: now + windowMs,
        penalties: bucket ? Math.max(0, bucket.penalties - 1) : 0,
      };
      rateLimitStore.set(key, bucket);
    } else {
      bucket.count += 1;
    }

    const remaining = Math.max(0, max - bucket.count);
    const retrySec = Math.ceil((bucket.resetAt - now) / 1000);

    res.setHeader('X-RateLimit-Limit', max);
    res.setHeader('X-RateLimit-Remaining', remaining);
    res.setHeader('X-RateLimit-Reset', Math.ceil(bucket.resetAt / 1000));

    if (bucket.count > max) {
      bucket.penalties += 1;
      const progressiveWait = retrySec + bucket.penalties * 5;
      res.setHeader('Retry-After', progressiveWait);

      logSecurityEvent('RATE_LIMIT_EXCEEDED', {
        ip,
        tier: tierName,
        count: bucket.count,
        max,
        path: req.path,
      });

      res.status(429).json({
        error: 'Too many requests. Please slow down.',
        retryAfter: progressiveWait,
      });
      return;
    }

    next();
  };
}

// Global API rate limit: 300 reqs/min (allows high-fidelity scrubbing and Range chunk streaming)
export const globalApiRateLimiter = createRateLimiter({
  max: 300,
  windowMs: 60 * 1000,
  tierName: 'global',
});

// Heavy streaming/proxy rate limit: 300 reqs/min to prevent seek stuttering and multi-chunk Range buffering
export const streamRateLimiter = createRateLimiter({
  max: 300,
  windowMs: 60 * 1000,
  tierName: 'stream',
});

// Sensitive config/admin rate limit: 20 reqs/min
export const sensitiveEndpointRateLimiter = createRateLimiter({
  max: 20,
  windowMs: 60 * 1000,
  tierName: 'sensitive',
});

// -------------------------------------------------------------
// 7. SSRF & OPEN PROXY AUDITOR (STAGE 2 COMPREHENSIVE HARDENING)
// Defends against:
// - Hex, octal, decimal integer IP representations
// - IPv4-mapped IPv6, link-local, cloud metadata (AWS, GCP, Azure, OpenStack)
// - DNS rebinding bypass attempts
// - Non-HTTPS protocols
// - Non-standard ports
// - Strict domain boundary matching
// -------------------------------------------------------------
function isPrivateOrRestrictedIp(ip: string): boolean {
  // Normalize IPv4-mapped IPv6 (e.g. ::ffff:127.0.0.1 -> 127.0.0.1)
  let cleanIp = ip.toLowerCase();
  if (cleanIp.startsWith('::ffff:')) {
    cleanIp = cleanIp.substring(7);
  }

  // IPv4 checks
  if (net.isIPv4(cleanIp)) {
    const parts = cleanIp.split('.').map((p) => parseInt(p, 10));
    const [p0, p1] = parts;

    // 0.0.0.0/8 (Broadcast/Current network)
    if (p0 === 0) return true;
    // 10.0.0.0/8 (Private)
    if (p0 === 10) return true;
    // 127.0.0.0/8 (Loopback)
    if (p0 === 127) return true;
    // 169.254.0.0/16 (Link-local & Cloud Metadata)
    if (p0 === 169 && p1 === 254) return true;
    // 172.16.0.0/12 (Private)
    if (p0 === 172 && p1 >= 16 && p1 <= 31) return true;
    // 192.168.0.0/16 (Private)
    if (p0 === 192 && p1 === 168) return true;
    // 224.0.0.0/4 (Multicast)
    if (p0 >= 224 && p0 <= 239) return true;
    // 240.0.0.0/4 (Reserved)
    if (p0 >= 240) return true;

    return false;
  }

  // IPv6 checks
  if (net.isIPv6(cleanIp)) {
    // Loopback
    if (cleanIp === '::1' || cleanIp === '0:0:0:0:0:0:0:1') return true;
    // Unspecified
    if (cleanIp === '::') return true;
    // Unique local (fc00::/7)
    if (cleanIp.startsWith('fc') || cleanIp.startsWith('fd')) return true;
    // Link-local (fe80::/10)
    if (cleanIp.startsWith('fe8') || cleanIp.startsWith('fe9') || cleanIp.startsWith('fea') || cleanIp.startsWith('feb')) return true;
    // Cloud metadata IPv6 (e.g. [fd00:ec2::254])
    if (cleanIp.includes('fd00:ec2::254')) return true;

    return false;
  }

  return false;
}

export function isAllowedProxyUrl(targetUrl: string): { allowed: boolean; reason?: string } {
  if (!targetUrl || typeof targetUrl !== 'string') {
    return { allowed: false, reason: 'Target URL is missing or invalid' };
  }

  if (targetUrl.length > 2048) {
    return { allowed: false, reason: 'URL exceeds maximum length' };
  }

  let parsed: URL;
  try {
    parsed = new URL(targetUrl);
  } catch {
    return { allowed: false, reason: 'Malformed URL' };
  }

  // 1. Enforce HTTPS only (no plain HTTP, file, ftp, gopher, ldap)
  if (parsed.protocol !== 'https:') {
    return { allowed: false, reason: 'Only secure HTTPS protocol is permitted' };
  }

  // 2. Strict port check: default HTTPS (443 or empty) only
  if (parsed.port && parsed.port !== '443') {
    return { allowed: false, reason: 'Destination port must be standard HTTPS 443' };
  }

  // 3. User/Password credentials embedded in URL
  if (parsed.username || parsed.password) {
    return { allowed: false, reason: 'Embedded credentials prohibited' };
  }

  // 4. Clean hostname (strip trailing dots, brackets for IPv6)
  let hostname = parsed.hostname.toLowerCase().trim().replace(/\.+$/, '');
  if (hostname.startsWith('[') && hostname.endsWith(']')) {
    hostname = hostname.slice(1, -1);
  }

  // 5. Detect direct or alternate IP representations (hex, octal, single integer)
  // e.g. 2130706433, 017700000001, 0x7f000001, 127.1
  const isNumericOrHex = /^([0-9]+|0x[0-9a-f]+)(\.([0-9]+|0x[0-9a-f]+))*$/i.test(hostname);
  if (isNumericOrHex || net.isIP(hostname)) {
    if (isPrivateOrRestrictedIp(hostname) || isNumericOrHex) {
      return { allowed: false, reason: 'Direct or numeric IP proxying is restricted' };
    }
  }

  // 6. Block reserved/internal domain names & cloud metadata endpoints
  if (
    hostname === 'localhost' ||
    hostname.endsWith('.localhost') ||
    hostname.endsWith('.local') ||
    hostname.endsWith('.internal') ||
    hostname.endsWith('.lan') ||
    hostname.includes('metadata.google.internal') ||
    hostname.includes('metadata') ||
    hostname.includes('169.254.169.254')
  ) {
    return { allowed: false, reason: 'Target hostname is internal or cloud metadata' };
  }

  // 7. Strict Domain Boundary Allowlist:
  // Must be EXACT match or a valid subdomain separated by dot: hostname.endsWith('.' + allowedDomain)
  const isMatch = TRUSTED_CDN_DOMAINS.some(
    (allowedDomain) => hostname === allowedDomain || hostname.endsWith(`.${allowedDomain}`)
  );

  if (!isMatch) {
    return { allowed: false, reason: `Domain '${hostname}' is not in the trusted audio CDN allowlist` };
  }

  return { allowed: true };
}

// -------------------------------------------------------------
// 8. INPUT SANITIZATION & ANOMALY DETECTION MIDDLEWARE
// -------------------------------------------------------------
export function inputSanitizerMiddleware(req: Request, res: Response, next: NextFunction): void {
  const checkNullBytes = (val: any): boolean => {
    if (typeof val === 'string') {
      return val.includes('\0') || val.includes('%00');
    }
    if (val && typeof val === 'object') {
      return Object.values(val).some(checkNullBytes);
    }
    return false;
  };

  if (checkNullBytes(req.query) || checkNullBytes(req.body)) {
    logSecurityEvent('NULL_BYTE_INJECTION_BLOCKED', { path: req.path });
    res.status(400).json({ error: 'Malformed request content' });
    return;
  }

  // Bound query parameter string lengths (allow up to 2048 for encoded CDN audio stream URLs)
  for (const [key, val] of Object.entries(req.query)) {
    const maxLen = key === 'url' ? 2048 : 500;
    if (typeof val === 'string' && val.length > maxLen) {
      res.status(400).json({ error: `Parameter '${key}' exceeds maximum allowed length` });
      return;
    }
  }

  next();
}

// -------------------------------------------------------------
// 9. ADMIN / MANAGEMENT ENDPOINT PROTECTION (FAIL-CLOSED)
// -------------------------------------------------------------
export function requireAdminSecret(req: Request, res: Response, next: NextFunction): void {
  // Fail-closed: If ADMIN_SECRET is not configured or empty, administrative endpoints are disabled
  if (!ADMIN_SECRET || ADMIN_SECRET.length === 0) {
    logSecurityEvent('ADMIN_ACTION_REJECTED_UNCONFIGURED_SECRET', {
      path: req.path,
      method: req.method,
    });
    res.status(403).json({
      error: 'Administrative operations are disabled. Configure ADMIN_API_SECRET in the server environment.',
    });
    return;
  }

  const adminKey = req.headers['x-admin-key'] as string | undefined;
  const authHeader = req.headers.authorization as string | undefined;
  let bearerToken = '';

  if (authHeader && authHeader.startsWith('Bearer ')) {
    bearerToken = authHeader.slice(7).trim();
  }

  const candidateKey = (adminKey || bearerToken || '').trim();

  // Secure constant-time comparison
  const isAuthorized = secureCompare(candidateKey, ADMIN_SECRET);

  if (!isAuthorized) {
    logSecurityEvent('UNAUTHORIZED_ADMIN_ACCESS_ATTEMPT', {
      path: req.path,
      method: req.method,
    });
    res.status(403).json({ error: 'Access denied: Valid administrative credentials required.' });
    return;
  }

  next();
}

// -------------------------------------------------------------
// 10. PRIVACY-PRESERVING & LEAK-PROOF SECURITY AUDIT LOGGING
// -------------------------------------------------------------
export function logSecurityEvent(event: string, details: Record<string, any>): void {
  const sanitizedDetails: Record<string, any> = {};

  for (const [k, v] of Object.entries(details)) {
    // Redact any credential, key, secret, token, auth header, or cookie value
    if (/token|secret|password|key|auth|cookie|bearer|credential/i.test(k)) {
      sanitizedDetails[k] = '[REDACTED]';
    } else {
      sanitizedDetails[k] = v;
    }
  }

  const logPayload = {
    timestamp: new Date().toISOString(),
    security_event: event,
    ...sanitizedDetails,
  };

  console.warn(`[SECURITY GUARD] ${JSON.stringify(logPayload)}`);
}
