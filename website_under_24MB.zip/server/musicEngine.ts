import express from 'express';
import type { Request, Response } from 'express';
import crypto from 'crypto';
import { isAllowedProxyUrl, logSecurityEvent } from './securityGuard.ts';

export const musicRouter = express.Router();

// -------------------------------------------------------------
// CONSTANTS & SEEDS
// -------------------------------------------------------------
const JIO_API = 'https://www.jiosaavn.com/api.php';
const REFERER = 'https://www.jiosaavn.com/';
const ORIGIN = 'https://www.jiosaavn.com';
const COOKIE = 'gdpr_acceptance=true; DL=IN; geo_country_code=IN';
const UA =
  'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36';
const DES_KEY = '38346591';

// Seed artists from original STERNITERS catalogue
const SEED_ARTISTS: Array<{ name: string; image: string }> = [
  { name: 'Arijit Singh', image: 'https://c.saavncdn.com/artists/Arijit_Singh_002_20230323062147_500x500.jpg' },
  { name: 'Shreya Ghoshal', image: 'https://c.saavncdn.com/artists/Shreya_Ghoshal_004_20230323061427_500x500.jpg' },
  { name: 'A.R. Rahman', image: 'https://c.saavncdn.com/artists/A_R_Rahman_002_20230323061413_500x500.jpg' },
  { name: 'Pritam', image: 'https://c.saavncdn.com/artists/Pritam_003_20230323061502_500x500.jpg' },
  { name: 'Atif Aslam', image: 'https://c.saavncdn.com/artists/Atif_Aslam_002_20230323062035_500x500.jpg' },
  { name: 'Diljit Dosanjh', image: 'https://c.saavncdn.com/artists/Diljit_Dosanjh_004_20221007183314_500x500.jpg' },
  { name: 'Sonu Nigam', image: 'https://c.saavncdn.com/artists/Sonu_Nigam_003_20230323061555_500x500.jpg' },
  { name: 'Jubin Nautiyal', image: 'https://c.saavncdn.com/artists/Jubin_Nautiyal_002_20230323061938_500x500.jpg' },
  { name: 'Anirudh Ravichander', image: 'https://c.saavncdn.com/artists/Anirudh_Ravichander_003_20230323061735_500x500.jpg' },
  { name: 'KK', image: 'https://c.saavncdn.com/artists/KK_002_20230323061706_500x500.jpg' },
  { name: 'Sachin-Jigar', image: 'https://c.saavncdn.com/artists/Sachin_Jigar_002_20230323061803_500x500.jpg' },
  { name: 'Amit Trivedi', image: 'https://c.saavncdn.com/artists/Amit_Trivedi_002_20230323061749_500x500.jpg' },
  { name: 'Sunidhi Chauhan', image: 'https://c.saavncdn.com/artists/Sunidhi_Chauhan_003_20230323061611_500x500.jpg' },
  { name: 'Neha Kakkar', image: 'https://c.saavncdn.com/artists/Neha_Kakkar_006_20230323061817_500x500.jpg' },
  { name: 'Armaan Malik', image: 'https://c.saavncdn.com/artists/Armaan_Malik_002_20230323061952_500x500.jpg' },
  { name: 'Mohit Chauhan', image: 'https://c.saavncdn.com/artists/Mohit_Chauhan_002_20230323061625_500x500.jpg' },
  { name: 'Shaan', image: 'https://c.saavncdn.com/artists/Shaan_003_20230323061639_500x500.jpg' },
  { name: 'Alka Yagnik', image: 'https://c.saavncdn.com/artists/Alka_Yagnik_003_20230323061516_500x500.jpg' },
  { name: 'Udit Narayan', image: 'https://c.saavncdn.com/artists/Udit_Narayan_003_20230323061530_500x500.jpg' },
  { name: 'Kumar Sanu', image: 'https://c.saavncdn.com/artists/Kumar_Sanu_003_20230323061543_500x500.jpg' },
  { name: 'Kishore Kumar', image: 'https://c.saavncdn.com/artists/Kishore_Kumar_003_20230323061440_500x500.jpg' },
  { name: 'Mohammed Rafi', image: 'https://c.saavncdn.com/artists/Mohammed_Rafi_003_20230323061453_500x500.jpg' },
  { name: 'Lata Mangeshkar', image: 'https://c.saavncdn.com/artists/Lata_Mangeshkar_003_20230323061420_500x500.jpg' },
  { name: 'Jagjit Singh', image: 'https://c.saavncdn.com/artists/Jagjit_Singh_003_20230323061652_500x500.jpg' },
  { name: 'AP Dhillon', image: 'https://c.saavncdn.com/artists/AP_Dhillon_002_20220623063546_500x500.jpg' },
  { name: 'Karan Aujla', image: 'https://c.saavncdn.com/artists/Karan_Aujla_004_20230915104618_500x500.jpg' },
  { name: 'Shubh', image: 'https://c.saavncdn.com/artists/Shubh_002_20230519073105_500x500.jpg' },
  { name: 'Darshan Raval', image: 'https://c.saavncdn.com/artists/Darshan_Raval_002_20230323062102_500x500.jpg' },
  { name: 'Anuv Jain', image: 'https://c.saavncdn.com/artists/Anuv_Jain_002_20230323062201_500x500.jpg' },
  { name: 'Prateek Kuhad', image: 'https://c.saavncdn.com/artists/Prateek_Kuhad_002_20230323062215_500x500.jpg' },
  { name: 'Sid Sriram', image: 'https://c.saavncdn.com/artists/Sid_Sriram_003_20230323061831_500x500.jpg' },
];

// In-memory caches
const streamCache = new Map<string, { url: string; expiresAt: number }>();
const metaCache = new Map<string, { data: any; expiresAt: number }>();
const lyricsServerCache = new Map<string, any>();
let homePayloadCache: { data: any; expiresAt: number } | null = null;
let romancePayloadCache: { data: any; expiresAt: number } | null = null;

// -------------------------------------------------------------
// TEXT & CRYPTO HELPERS
// -------------------------------------------------------------
function cleanText(str: string): string {
  if (!str) return '';
  return str
    .replace(/&quot;/g, '"')
    .replace(/&#039;/g, "'")
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&nbsp;/g, ' ')
    .trim();
}

function desDecrypt(b64: string, key = DES_KEY): string | null {
  try {
    let s = b64.replace(/-/g, '+').replace(/_/g, '/');
    while (s.length % 4 !== 0) s += '=';
    const buf = Buffer.from(s, 'base64');
    const decipher = crypto.createDecipheriv('des-ecb', Buffer.from(key), null);
    decipher.setAutoPadding(true);
    let dec = decipher.update(buf, undefined, 'utf8');
    dec += decipher.final('utf8');
    const url = dec.trim();
    if (url.startsWith('http://') || url.startsWith('https://')) {
      return url;
    }
    return null;
  } catch (err) {
    return null;
  }
}

async function getAuthTokenStreamUrl(encryptedMediaUrl: string, bitrate = '320'): Promise<string | null> {
  try {
    const body = new URLSearchParams({
      __call: 'song.generateAuthToken',
      _format: 'json',
      _marker: '0',
      cc: 'in',
      api_version: '4',
      ctx: 'wap6dot0',
      url: encryptedMediaUrl,
      bitrate,
    });

    const res = await fetch(JIO_API, {
      method: 'POST',
      headers: {
        'User-Agent': UA,
        Referer: REFERER,
        Origin: ORIGIN,
        Cookie: COOKIE,
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: body.toString(),
    });

    if (!res.ok) return null;
    const data: any = await res.json();
    if (data?.auth_url && typeof data.auth_url === 'string') return data.auth_url;
    if (data?.data?.auth_url && typeof data.data.auth_url === 'string') return data.data.auth_url;
    return null;
  } catch (e) {
    return null;
  }
}

// -------------------------------------------------------------
// SONG NORMALIZATION & RESOLUTION
// -------------------------------------------------------------
export async function resolveStreamFromRaw(song: any, bypassCache = false): Promise<string | null> {
  const songId = song.id || song.song_id;
  if (!songId) return null;

  if (!bypassCache) {
    const cached = streamCache.get(songId);
    if (cached && cached.expiresAt > Date.now()) {
      return cached.url;
    }
  }

  const moreInfo = song.more_info || {};
  const encryptedUrl =
    moreInfo.encrypted_media_url ||
    song.encrypted_media_url ||
    moreInfo.encrypted_media_path ||
    song.encrypted_media_path;

  let streamUrl: string | null = null;

  // 1. 320kbps Auth Token
  if (encryptedUrl) {
    streamUrl = await getAuthTokenStreamUrl(encryptedUrl, '320');
  }

  // 2. 160kbps Auth Token
  if (!streamUrl && encryptedUrl) {
    streamUrl = await getAuthTokenStreamUrl(encryptedUrl, '160');
  }

  // 3. Direct DES Decrypt
  if (!streamUrl && encryptedUrl) {
    streamUrl = desDecrypt(encryptedUrl);
  }

  // 4. Fallback media_url / vlink preview
  if (!streamUrl) {
    const rawUrl =
      moreInfo.media_url ||
      song.media_url ||
      moreInfo.media_preview_url ||
      song.media_preview_url ||
      moreInfo.vlink ||
      song.vlink;
    if (rawUrl && typeof rawUrl === 'string' && (rawUrl.startsWith('http://') || rawUrl.startsWith('https://'))) {
      streamUrl = rawUrl;
    }
  }

  if (streamUrl) {
    if (streamUrl.startsWith('http://')) {
      streamUrl = streamUrl.replace(/^http:\/\//i, 'https://');
    }

    // Dynamic TTL: Parse Expires parameter if signed CDN URL, else 20 min default
    let ttl = 20 * 60 * 1000;
    try {
      const parsed = new URL(streamUrl);
      const expParam = parsed.searchParams.get('Expires') || parsed.searchParams.get('expires');
      if (expParam) {
        const expSec = parseInt(expParam, 10);
        if (!isNaN(expSec) && expSec > 1000000000) {
          const msRemaining = (expSec * 1000) - Date.now() - 60000;
          if (msRemaining > 30000) {
            ttl = Math.min(ttl, msRemaining);
          }
        }
      }
    } catch {}

    streamCache.set(songId, {
      url: streamUrl,
      expiresAt: Date.now() + ttl,
    });
  }

  return streamUrl;
}

export async function getSongDetails(songId: string): Promise<any | null> {
  const cleanId = String(songId).replace(/^saavn_/, '').trim();
  if (!cleanId) return null;

  const cached = metaCache.get(cleanId);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.data;
  }

  // Helper fetcher
  const fetchJio = async (params: Record<string, string>): Promise<any | null> => {
    try {
      const qs = new URLSearchParams({
        _format: 'json',
        _marker: '0',
        api_version: '4',
        ctx: 'web6dot0',
        ...params,
      });
      const res = await fetch(`${JIO_API}?${qs.toString()}`, {
        headers: {
          'User-Agent': UA,
          Referer: REFERER,
          Origin: ORIGIN,
          Cookie: COOKIE,
        },
      });
      if (!res.ok) return null;
      return await res.json();
    } catch {
      return null;
    }
  };

  try {
    // 1. Primary: song.getDetails by pids
    const data1 = await fetchJio({ __call: 'song.getDetails', pids: cleanId });
    let songData = data1?.[cleanId] || (Array.isArray(data1?.songs) ? data1.songs[0] : null) || (data1?.id ? data1 : null);

    // 2. Secondary fallback: webapi.get by token (used for perma_url/token links)
    if (!songData) {
      const data2 = await fetchJio({ __call: 'webapi.get', token: cleanId, type: 'song' });
      songData = data2?.songs?.[0] || (Array.isArray(data2) ? data2[0] : null);
    }

    // 3. Tertiary fallback: song.gotDetails
    if (!songData) {
      const data3 = await fetchJio({ __call: 'song.gotDetails', pids: cleanId });
      songData = data3?.[cleanId] || (Array.isArray(data3) ? data3[0] : null);
    }

    // 4. Quaternary fallback: search by cleanId
    if (!songData) {
      const sData = await fetchJio({ __call: 'search.getResults', q: cleanId, n: '5' });
      const sArr = Array.isArray(sData?.results) ? sData.results : [];
      songData = sArr.find((s: any) => String(s?.id || '').replace(/^saavn_/, '').trim() === cleanId) || sArr[0] || null;
    }

    if (songData) {
      metaCache.set(cleanId, {
        data: songData,
        expiresAt: Date.now() + 2 * 60 * 60 * 1000,
      });
      return songData;
    }
    return null;
  } catch (err) {
    return null;
  }
}

export function normSong(raw: any): any {
  const moreInfo = raw.more_info || {};
  const songId = String(raw.id || raw.song_id || moreInfo.id || '').replace(/^saavn_/, '');

  let artistNames: string[] = [];
  if (Array.isArray(moreInfo.artistMap?.primary_artists)) {
    artistNames = moreInfo.artistMap.primary_artists.map((a: any) => cleanText(a.name));
  } else if (typeof moreInfo.primary_artists === 'string') {
    artistNames = moreInfo.primary_artists.split(',').map((s: string) => cleanText(s));
  } else if (typeof raw.singers === 'string') {
    artistNames = raw.singers.split(',').map((s: string) => cleanText(s));
  } else if (typeof raw.primary_artists === 'string') {
    artistNames = raw.primary_artists.split(',').map((s: string) => cleanText(s));
  } else if (typeof raw.artist === 'string') {
    artistNames = raw.artist.split(',').map((s: string) => cleanText(s));
  }

  const primaryArtist = artistNames.filter(Boolean).join(', ') || 'Various Artists';

  let coverUrl = raw.image || moreInfo.image || '';
  if (typeof coverUrl === 'string') {
    coverUrl = coverUrl.replace(/150x150/g, '500x500').replace(/50x50/g, '500x500');
  }

  const durationSec = parseInt(raw.duration || moreInfo.duration || '0', 10);
  const streamProxyUrl = `/backend.php?action=stream_proxy&id=${encodeURIComponent(songId)}`;

  return {
    id: songId,
    rawId: songId,
    title: cleanText(raw.title || raw.song || 'Unknown Title'),
    artist: primaryArtist,
    artists: artistNames.filter(Boolean).length ? artistNames.filter(Boolean) : [primaryArtist],
    album: cleanText(raw.album || moreInfo.album || 'Single'),
    image: coverUrl || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&auto=format&fit=crop&q=80',
    coverUrl: coverUrl || 'https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&auto=format&fit=crop&q=80',
    audioUrl: streamProxyUrl,
    stream_url: streamProxyUrl,
    duration: durationSec || 180,
    genre: raw.genre || moreInfo.genre || 'Soundtrack',
    language: raw.language || moreInfo.language || 'Hindi',
    releaseDate: raw.year || moreInfo.release_date || raw.release_date || '',
    year: raw.year || moreInfo.release_date || raw.release_date || '',
    isPlayable: true,
    hasFullPlayback: true,
    provider: 'sterniters',
    providerId: songId,
    play_count: parseInt(raw.play_count || moreInfo.play_count || '0', 10) || 1200,
    playCount: parseInt(raw.play_count || moreInfo.play_count || '0', 10) || 1200,
    quality: '320kbps Lossless',
    more_info: moreInfo,
  };
}

// -------------------------------------------------------------
// CORE DISCOVERY DATA
// -------------------------------------------------------------
function normBaseTitle(t: string): string {
  return (t || '')
    .toLowerCase()
    .replace(/\([^)]*\)|\[[^\]]*\]/g, '')
    .replace(/\b(remix|lofi|slowed|reverb|version|flip|mix|feat|acoustic|reprise|teaser|audio|preview)\b/gi, '')
    .replace(/[^a-z0-9]/g, '')
    .trim();
}

export async function getTrendingSongs(limit = 40): Promise<any[]> {
  try {
    const [k1, k2, k3, k4, k5, k6, k7, hits] = await Promise.all([
      searchSongs('Kesariya Brahmastra Arijit Singh', 1, 2),
      searchSongs('Sajni Laapataa Ladies Arijit Singh', 1, 2),
      searchSongs('Apna Bana Le Bhediya Arijit Singh', 1, 2),
      searchSongs('Heeriye Jasleen Royal Arijit Singh', 1, 2),
      searchSongs('O Maahi Dunki Arijit Singh', 1, 2),
      searchSongs('Husn Anuv Jain', 1, 2),
      searchSongs('Tum Hi Ho Aashiqui 2 Arijit Singh', 1, 2),
      searchSongs('Top Bollywood Trending 2025', 1, 35),
    ]);

    const pool = [...k1, ...k2, ...k3, ...k4, ...k5, ...k6, ...k7, ...hits];
    const seenTitles = new Set<string>();
    const seenIds = new Set<string>();
    const deduplicated: any[] = [];

    for (const song of pool) {
      if (!song?.id) continue;
      const base = normBaseTitle(song.title);
      if (!base || base.length < 3 || seenTitles.has(base) || seenIds.has(song.id)) continue;
      // Skip unwanted teasers or repetitive tracks
      if (song.title.toLowerCase().includes('teaser') || song.title.toLowerCase().includes('audio teaser')) continue;
      seenTitles.add(base);
      seenIds.add(song.id);
      deduplicated.push(song);
      if (deduplicated.length >= limit) break;
    }

    if (deduplicated.length >= 8) {
      return deduplicated;
    }
  } catch (err) {
    // Fallback
  }

  return searchSongs('Arijit Singh Top Hindi Hits', 1, limit);
}

export async function searchSongs(query: string, page = 1, limit = 25): Promise<any[]> {
  if (!query) return [];

  try {
    const url = `${JIO_API}?__call=search.getResults&q=${encodeURIComponent(
      query
    )}&n=${limit}&p=${page}&_format=json&_marker=0&api_version=4&ctx=web6dot0`;

    const res = await fetch(url, {
      headers: { 'User-Agent': UA, Referer: REFERER, Origin: ORIGIN, Cookie: COOKIE },
    });

    if (!res.ok) return [];
    const data: any = await res.json();
    const results = Array.isArray(data?.results) ? data.results : [];
    if (results.length) {
      for (const s of results) {
        const sid = String(s?.id || s?.song_id || '').replace(/^saavn_/, '').trim();
        if (sid) {
          metaCache.set(sid, { data: s, expiresAt: Date.now() + 2 * 60 * 60 * 1000 });
        }
      }
      return results.map((s: any) => normSong(s));
    }

    // Autocomplete fallback
    try {
      const fallbackUrl = `${JIO_API}?__call=autocomplete.get&query=${encodeURIComponent(
        query
      )}&_format=json&_marker=0&ctx=web6dot0`;
      const aRes = await fetch(fallbackUrl, {
        headers: { 'User-Agent': UA, Referer: REFERER, Origin: ORIGIN, Cookie: COOKIE },
      });
      if (aRes.ok) {
        const aData: any = await aRes.json();
        const autoSongs = Array.isArray(aData?.songs?.data) ? aData.songs.data : [];
        if (autoSongs.length) {
          return autoSongs.map((s: any) => normSong(s));
        }
      }
    } catch {}

    // Query Decomposition fallback for compound phrases (e.g. "Kesariya Brahmastra", "Raataan Lambiyan Shershaah")
    const cleaned = query
      .replace(/\b(full|official|video|audio|lyrics?|song|hd|mp3|download|teaser)\b/gi, '')
      .replace(/\s+/g, ' ')
      .trim();
    const words = cleaned.split(' ').filter(Boolean);

    if (words.length > 1) {
      const candidates = [words.slice(0, 2).join(' '), words[0]];
      for (const candidate of candidates) {
        if (!candidate || candidate.length < 2) continue;
        try {
          const subUrl = `${JIO_API}?__call=search.getResults&q=${encodeURIComponent(
            candidate
          )}&n=${limit}&p=${page}&_format=json&_marker=0&api_version=4&ctx=web6dot0`;
          const subRes = await fetch(subUrl, {
            headers: { 'User-Agent': UA, Referer: REFERER, Origin: ORIGIN, Cookie: COOKIE },
          });
          if (subRes.ok) {
            const subData: any = await subRes.json();
            const subResults = Array.isArray(subData?.results) ? subData.results : [];
            if (subResults.length) {
              return subResults.map((s: any) => normSong(s));
            }
          }
        } catch {}
      }
    }

    return [];
  } catch (err) {
    return [];
  }
}

export async function getRomanceStation(limit = 80): Promise<{ results: any[]; arijit: any[] }> {
  if (romancePayloadCache && romancePayloadCache.expiresAt > Date.now()) {
    return romancePayloadCache.data;
  }

  const [romanceHits1, romanceHits2, arijitHits] = await Promise.all([
    searchSongs('Romantic Hits', 1, Math.min(30, limit)),
    searchSongs('Love Songs', 1, Math.min(30, limit)),
    searchSongs('Arijit Singh Love Songs', 1, Math.min(40, limit)),
  ]);

  const seen = new Set<string>();
  const combinedRomance: any[] = [];
  for (const s of [...romanceHits1, ...romanceHits2]) {
    if (s && s.id && !seen.has(s.id)) {
      seen.add(s.id);
      combinedRomance.push(s);
    }
  }

  const payload = {
    results: combinedRomance,
    arijit: arijitHits,
  };

  romancePayloadCache = {
    data: payload,
    expiresAt: Date.now() + 30 * 60 * 1000,
  };

  return payload;
}

export async function getHomePayload(limit = 72): Promise<any> {
  if (homePayloadCache && homePayloadCache.expiresAt > Date.now()) {
    return homePayloadCache.data;
  }

  const trending = await getTrendingSongs(limit);
  const homeArtists = SEED_ARTISTS.slice(0, 24);

  const payload = {
    results: trending,
    artists: homeArtists,
    generated_at: Math.floor(Date.now() / 1000),
    discovery_sources: ['JioSaavn', 'Sterniters Music', 'Shoeb Music'],
  };

  homePayloadCache = {
    data: payload,
    expiresAt: Date.now() + 15 * 60 * 1000,
  };

  return payload;
}

// -------------------------------------------------------------
// STREAM PROXY WITH PARTIAL CONTENT (HTTP 206)
// -------------------------------------------------------------
export async function proxyAudioStream(
  req: Request,
  res: Response,
  targetUrl: string,
  downloadFilename: string | null = null,
  songIdToInvalidate: string | null = null
): Promise<void> {
  // 1. SSRF & Domain Allowlist Protection
  const urlCheck = isAllowedProxyUrl(targetUrl);
  if (!urlCheck.allowed) {
    logSecurityEvent('SSRF_PROXY_ATTEMPT_BLOCKED', {
      targetUrl: targetUrl.slice(0, 100),
      reason: urlCheck.reason,
      ip: req.socket.remoteAddress,
    });
    res.status(403).send('Proxy access denied by security guard');
    return;
  }

  const controller = new AbortController();
  // Connection / response header timeout only (15s).
  // Once the upstream response headers are received, this timeout MUST be cleared so the stream does not abort mid-song!
  let headerTimeout: NodeJS.Timeout | null = setTimeout(() => {
    controller.abort(new Error('Audio origin connect timeout'));
  }, 15000);

  try {
    const rangeHeader = downloadFilename ? undefined : req.headers.range;
    const fetchHeaders: Record<string, string> = {
      'User-Agent': UA,
      Referer: REFERER,
      Origin: ORIGIN,
      Cookie: COOKIE,
      Accept: 'audio/ogg,audio/*;q=0.9,application/octet-stream;q=0.8,*/*;q=0.5',
    };

    if (rangeHeader) {
      fetchHeaders['Range'] = rangeHeader;
    }

    let currentUrl = targetUrl;
    let audioRes: any = null;
    let redirectCount = 0;
    const maxRedirects = 2;

    try {
      while (redirectCount <= maxRedirects) {
        audioRes = await fetch(currentUrl, {
          headers: fetchHeaders,
          signal: controller.signal,
          redirect: 'manual',
        });

        // If redirect, re-validate the target URL through isAllowedProxyUrl (prevents redirect SSRF bypasses)
        if ([301, 302, 303, 307, 308].includes(audioRes.status)) {
          const location = audioRes.headers.get('location');
          if (!location) {
            res.status(502).send('Invalid redirect from origin');
            return;
          }

          let resolvedLocation: string;
          try {
            resolvedLocation = new URL(location, currentUrl).toString();
          } catch {
            res.status(400).send('Malformed redirect location');
            return;
          }

          const check = isAllowedProxyUrl(resolvedLocation);
          if (!check.allowed) {
            logSecurityEvent('SSRF_REDIRECT_ATTEMPT_BLOCKED', {
              from: currentUrl.slice(0, 80),
              to: resolvedLocation.slice(0, 80),
              reason: check.reason,
              ip: req.socket.remoteAddress,
            });
            res.status(403).send('Redirect to unauthorized destination blocked by security guard');
            return;
          }

          currentUrl = resolvedLocation;
          redirectCount++;
          continue;
        }

        break;
      }
    } finally {
      // CLEAR the initial connection timeout once headers have been received
      if (headerTimeout) {
        clearTimeout(headerTimeout);
        headerTimeout = null;
      }
    }

    if (!audioRes || (!audioRes.ok && audioRes.status !== 206)) {
      if (songIdToInvalidate && [401, 403, 404, 410].includes(audioRes?.status)) {
        streamCache.delete(songIdToInvalidate);
        // Automatic server-side recovery: generate a fresh 320kbps stream token
        try {
          const raw = await getSongDetails(songIdToInvalidate);
          if (raw) {
            const freshUrl = await resolveStreamFromRaw(raw, true);
            if (freshUrl && freshUrl !== targetUrl) {
              return await proxyAudioStream(req, res, freshUrl, downloadFilename, null);
            }
          }
        } catch (_recoveryErr) {}
      }
      res.status(audioRes?.status || 502).send('Streaming error from audio origin');
      return;
    }

    const status = audioRes.status;
    res.status(status);

    let contentType = audioRes.headers.get('content-type') || 'audio/mp4';
    if (!contentType.startsWith('audio/') && !contentType.startsWith('video/')) {
      if (currentUrl.includes('.mp3')) contentType = 'audio/mpeg';
      else contentType = 'audio/mp4';
    }
    const contentLength = audioRes.headers.get('content-length');
    const contentRange = audioRes.headers.get('content-range');
    const acceptRanges = audioRes.headers.get('accept-ranges') || 'bytes';

    res.setHeader('Content-Type', contentType);
    res.setHeader('Accept-Ranges', acceptRanges);
    res.setHeader('Cache-Control', 'public, max-age=86400');

    if (contentLength) res.setHeader('Content-Length', contentLength);
    if (contentRange) res.setHeader('Content-Range', contentRange);

    if (downloadFilename) {
      const safeFilename = downloadFilename.replace(/[\r\n"\\\/]/g, '_').slice(0, 150);
      res.setHeader('Content-Disposition', `attachment; filename="${encodeURIComponent(safeFilename)}"`);
    }

    if (audioRes.body) {
      const { Readable } = await import('stream');
      // @ts-ignore
      const nodeStream = Readable.fromWeb(audioRes.body);

      nodeStream.on('error', (_streamErr: any) => {
        controller.abort();
        if (!res.headersSent) {
          res.status(500).send('Stream transfer error');
        } else {
          res.end();
        }
      });

      nodeStream.pipe(res);

      req.on('close', () => {
        controller.abort();
        nodeStream.destroy();
      });
    } else {
      const arrayBuf = await audioRes.arrayBuffer();
      res.send(Buffer.from(arrayBuf));
    }
  } catch (err: any) {
    if (headerTimeout) {
      clearTimeout(headerTimeout);
      headerTimeout = null;
    }
    controller.abort();
    if (!res.headersSent) {
      res.status(500).send('Streaming proxy error');
    }
  }
}

// -------------------------------------------------------------
// LISTEN TOGETHER ROOMS (IN-MEMORY MANAGER WITH AUTOMATIC GC)
// -------------------------------------------------------------
interface RoomParticipant {
  name: string;
  role: 'host' | 'listener';
  last_seen: number;
}

interface RoomData {
  code: string;
  created_at: number;
  last_activity: number;
  updated_at_ms: number;
  seq: number;
  ended: boolean;
  host_token_hash: string;
  host_participant_id: string;
  track: any | null;
  upcoming: any[];
  position: number;
  playing: boolean;
  playback_rate: number;
  participants: Record<string, RoomParticipant>;
}

const activeRooms = new Map<string, RoomData>();
const MAX_CONCURRENT_ROOMS = 500;

// Automatic room garbage collection every 10 minutes (purges inactive rooms older than 2 hours)
setInterval(() => {
  const now = Math.floor(Date.now() / 1000);
  for (const [code, room] of activeRooms.entries()) {
    if (room.ended || now - room.last_activity > 2 * 60 * 60) {
      activeRooms.delete(code);
    }
  }
}, 10 * 60 * 1000);

function cleanRoomCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let out = '';
  for (let i = 0; i < 6; i++) {
    out += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return out;
}

// -------------------------------------------------------------
// UNIFIED /backend.php DISPATCHER
// -------------------------------------------------------------
export async function handleBackendPhp(req: Request, res: Response): Promise<void> {
  const action = String(req.query.action || req.body?.action || '').trim();

  res.setHeader('X-Sterniters-Backend', 'v61-compatible');

  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }

  switch (action) {
    // 1. Home
    case 'home': {
      const limit = Math.min(90, Math.max(36, parseInt(String(req.query.limit || '72'), 10) || 72));
      const payload = await getHomePayload(limit);
      res.json(payload);
      return;
    }

    // 2. Trending
    case 'trending': {
      const limit = Math.min(50, Math.max(10, parseInt(String(req.query.limit || '20'), 10) || 20));
      const results = await getTrendingSongs(limit);
      res.json({ results });
      return;
    }

    // 3. Search & Fallbacks
    case 'search':
    case 'video_search': {
      const q = String(req.query.q || '').trim();
      const limit = Math.min(50, Math.max(5, parseInt(String(req.query.limit || '25'), 10) || 25));
      const page = Math.max(1, parseInt(String(req.query.page || '1'), 10) || 1);
      const results = await searchSongs(q, page, limit);
      res.json({ results });
      return;
    }

    case 'pagal_search': {
      const q = String(req.query.q || '').trim();
      const limit = Math.min(50, Math.max(5, parseInt(String(req.query.limit || '16'), 10) || 16));
      const page = Math.max(1, parseInt(String(req.query.page || '1'), 10) || 1);
      let results = await searchSongs(q, page, limit);
      if (!results.length && q) {
        results = await searchSongs(`${q} song`, 1, limit);
      }
      res.json({ results, provider: 'Sterniters Music', count: results.length });
      return;
    }

    case 'shoeb_search': {
      const q = String(req.query.q || '').trim();
      const limit = Math.min(50, Math.max(5, parseInt(String(req.query.limit || '18'), 10) || 18));
      const page = Math.max(1, parseInt(String(req.query.page || '1'), 10) || 1);
      const results = await searchSongs(q, page, limit);
      res.json({ results, provider: 'Shoeb Music', count: results.length });
      return;
    }

    case 'shoeb_browse': {
      const limit = Math.min(30, Math.max(4, parseInt(String(req.query.limit || '8'), 10) || 8));
      const songs = await getTrendingSongs(limit);
      res.json({
        ok: true,
        results: songs.map((s) => ({ ...s, provider: 'Shoeb Music' })),
        provider: 'Shoeb Music',
        count: songs.length,
      });
      return;
    }

    case 'warm_secondary': {
      const rawIds = String(req.query.ids || req.body?.ids || '').trim();
      const ids = rawIds ? rawIds.split(',').map((s) => s.trim()).filter(Boolean).slice(0, 8) : [];
      const results: Record<string, any> = {};

      await Promise.all(
        ids.map(async (id) => {
          try {
            const raw = await getSongDetails(id);
            if (raw) {
              const stream = await resolveStreamFromRaw(raw);
              if (stream) {
                results[id] = {
                  meta: normSong(raw),
                  stream,
                };
              }
            }
          } catch {}
        })
      );

      res.json({ ok: true, results });
      return;
    }

    // 4. Romance Station
    case 'romance_station': {
      const limit = Math.min(220, Math.max(40, parseInt(String(req.query.limit || '180'), 10) || 180));
      const payload = await getRomanceStation(limit);
      res.json(payload);
      return;
    }

    // 5. Song Details & Stream Resolution
    case 'song': {
      const id = String(req.query.id || '').replace(/^saavn_/, '').trim();
      const fresh = req.query.fresh === '1';
      if (!id) {
        res.status(400).json({ error: 'Missing song ID' });
        return;
      }

      if (fresh) {
        streamCache.delete(id);
      }

      const raw = await getSongDetails(id);
      if (!raw) {
        res.status(404).json({ error: 'Song not found' });
        return;
      }

      const song = normSong(raw);
      const streamUrl = await resolveStreamFromRaw(raw, fresh);

      if (!streamUrl) {
        res.status(404).json({ error: 'This track is not playable right now' });
        return;
      }

      const encUrl = Buffer.from(streamUrl).toString('base64');
      const resolvedStreamUrl = `/backend.php?action=stream_proxy&id=${encodeURIComponent(
        id
      )}&url=${encodeURIComponent(encUrl)}`;
      const fallbackStreamUrl = `/backend.php?action=stream&id=${encodeURIComponent(
        id
      )}&url=${encodeURIComponent(encUrl)}`;
      const downloadUrl = `/backend.php?action=download&id=${encodeURIComponent(id)}`;

      res.json({
        ...song,
        stream_url: resolvedStreamUrl,
        stream_fallback_url: fallbackStreamUrl,
        download_url: downloadUrl,
      });
      return;
    }

    // 6. Stream Proxy & Streaming
    case 'stream_proxy':
    case 'stream': {
      let rawUrl = '';
      const encUrl = String(req.query.url || '').trim();
      const songId = String(req.query.id || '').replace(/^saavn_/, '').trim();

      if (encUrl) {
        try {
          const safeB64 = encUrl.replace(/ /g, '+');
          const dec = Buffer.from(safeB64, 'base64').toString('utf8');
          if (dec.startsWith('http://') || dec.startsWith('https://')) {
            rawUrl = dec;
          }
        } catch {
          // ignore
        }
      }

      if (!rawUrl && songId) {
        const raw = await getSongDetails(songId);
        if (raw) {
          const resolved = await resolveStreamFromRaw(raw);
          if (resolved) rawUrl = resolved;
        }
      }

      if (!rawUrl) {
        res.status(400).send('Invalid or missing stream URL');
        return;
      }

      await proxyAudioStream(req, res, rawUrl, null, songId || null);
      return;
    }

    // 7. Lyrics
    case 'lyrics': {
      const id = String(req.query.id || '').replace(/^saavn_/, '').trim();
      let title = String(req.query.title || '').trim();
      let artist = String(req.query.artist || '').trim();
      let duration = Math.round(Number(req.query.duration || 0));

      if (!id && !title) {
        res.status(400).json({ error: 'Missing song ID or title' });
        return;
      }

      if ((!title || !duration) && id) {
        const raw = await getSongDetails(id);
        if (raw) {
          if (!title) title = cleanText(raw.song || raw.title || '');
          if (!artist) artist = cleanText(raw.primary_artists || raw.singers || raw.artist || '').split(',')[0].trim();
          if (!duration && raw.duration) duration = Math.round(Number(raw.duration));
        }
      }

      const cacheKey = `${id || title}_${artist}_${duration}`.toLowerCase();
      if (lyricsServerCache.has(cacheKey)) {
        res.json(lyricsServerCache.get(cacheKey));
        return;
      }

      // 1. Check LRCLIB for real-time Synced Lyrics with duration & recording verification
      if (title) {
        try {
          const cleanTitle = title
            .replace(/\(from\s+[^)]+\)/gi, '')
            .replace(/\(feat[^)]+\)/gi, '')
            .replace(/\(video\s+song\)/gi, '')
            .replace(/\(official\s+audio\)/gi, '')
            .replace(/\(audio\)/gi, '')
            .replace(/\[[^\]]+\]/g, '')
            .replace(/\([^)]*\)/g, '')
            .replace(/\s+/g, ' ')
            .trim();

          const cleanTitleSimple = cleanTitle.toLowerCase().replace(/[^a-z0-9\u0900-\u097F\u0A80-\u0AFF]/gi, '');

          const isSameSongTitle = (candidateTitle: string): boolean => {
            if (!candidateTitle || !cleanTitleSimple) return false;
            const c = String(candidateTitle)
              .toLowerCase()
              .replace(/\(from\s+[^)]+\)/gi, '')
              .replace(/\(feat[^)]+\)/gi, '')
              .replace(/\(video\s+song\)/gi, '')
              .replace(/\(official\s+audio\)/gi, '')
              .replace(/\(audio\)/gi, '')
              .replace(/\[[^\]]+\]/g, '')
              .replace(/\([^)]*\)/g, '')
              .replace(/[^a-z0-9\u0900-\u097F\u0A80-\u0AFF]/gi, '')
              .trim();
            if (!c) return false;
            if (c === cleanTitleSimple) return true;
            if (c.includes(cleanTitleSimple) || cleanTitleSimple.includes(c)) return true;
            if (cleanTitleSimple.length >= 5 && c.startsWith(cleanTitleSimple.slice(0, 5))) return true;
            return false;
          };

          const artistScore = (candidateArtist: string): number => {
            if (!candidateArtist || !artist) return 0;
            const c = candidateArtist.toLowerCase().replace(/[^a-z0-9\u0900-\u097F\u0A80-\u0AFF]/gi, '');
            const t = artist.toLowerCase().replace(/[^a-z0-9\u0900-\u097F\u0A80-\u0AFF]/gi, '');
            if (!c || !t) return 0;
            if (c === t) return 12;
            const targetParts = artist.toLowerCase().split(/[,&/|]/).map(x => x.trim()).filter(Boolean);
            const candParts = candidateArtist.toLowerCase().split(/[,&/|]/).map(x => x.trim()).filter(Boolean);
            for (const tp of targetParts) {
              const cleanTp = tp.replace(/[^a-z0-9\u0900-\u097F\u0A80-\u0AFF]/gi, '');
              if (!cleanTp || cleanTp.length < 3) continue;
              for (const cp of candParts) {
                const cleanCp = cp.replace(/[^a-z0-9\u0900-\u097F\u0A80-\u0AFF]/gi, '');
                if (!cleanCp) continue;
                if (cleanCp === cleanTp || cleanCp.includes(cleanTp) || cleanTp.includes(cleanCp)) return 10;
              }
            }
            return 0;
          };

          // Single, efficient LRCLIB query (avoids 429 rate-limiting)
          const controller = new AbortController();
          const timeout = setTimeout(() => controller.abort(), 4500);
          let lrcResults: any = null;
          try {
            const lrcUrl = `https://lrclib.net/api/search?q=${encodeURIComponent(cleanTitle)}`;
            const r = await fetch(lrcUrl, {
              headers: { 'User-Agent': 'KRISH-MUSIC/2.0 (Web Music Player)' },
              signal: controller.signal,
            });
            if (r.ok) {
              lrcResults = await r.json();
            }
          } catch {
            // timeout or network
          } finally {
            clearTimeout(timeout);
          }

          if (Array.isArray(lrcResults) && lrcResults.length > 0) {
            // Filter candidates to strictly match title (prevents wrong-song lyric swap)
            const matching = lrcResults.filter((item: any) =>
              item && (typeof item.syncedLyrics === 'string' || typeof item.plainLyrics === 'string') && isSameSongTitle(item.trackName)
            );

            if (matching.length > 0) {
              const scored = matching.map((item: any) => {
                let score = 0;
                score += artistScore(item.artistName);
                if (duration > 0 && item.duration) {
                  const diff = Math.abs(item.duration - duration);
                  if (diff <= 3) score += 16;
                  else if (diff <= 6) score += 10;
                  else if (diff <= 12) score += 5;
                  else if (diff > 25) score -= 12;
                }
                if (item.syncedLyrics && item.syncedLyrics.trim().length > 0) score += 6;
                if (item.plainLyrics && item.plainLyrics.trim().length > 0) score += 3;
                return { item, score };
              });

              scored.sort((a: any, b: any) => b.score - a.score);
              const bestCandidate = scored[0].item;

              if (bestCandidate) {
                const durMatches = duration <= 0 || !bestCandidate.duration || Math.abs(bestCandidate.duration - duration) <= 5;
                const hasSynced = Boolean(bestCandidate.syncedLyrics && bestCandidate.syncedLyrics.trim().length > 0 && durMatches);
                const plain = (bestCandidate.plainLyrics || (bestCandidate.syncedLyrics ? bestCandidate.syncedLyrics.replace(/\[\d+:\d+(?:\.\d+)?\]/g, '') : '')).trim();

                if (plain || hasSynced) {
                  const payload = {
                    id,
                    lyrics: plain,
                    synced_lyrics: hasSynced ? bestCandidate.syncedLyrics : '',
                    has_synced: hasSynced,
                    duration: bestCandidate.duration || duration,
                    available: true,
                    source: 'lrclib',
                  };
                  lyricsServerCache.set(cacheKey, payload);
                  if (lyricsServerCache.size > 200) {
                    lyricsServerCache.delete(lyricsServerCache.keys().next().value!);
                  }
                  res.json(payload);
                  return;
                }
              }
            }
          }
        } catch {
          // fallback to jiosaavn
        }
      }

      // 2. Fallback to JioSaavn
      try {
        // Step A: Direct lyrics_id lookup with clean ID
        const directUrl = `${JIO_API}?__call=lyrics.getLyrics&lyrics_id=${encodeURIComponent(
          id
        )}&_format=json&ctx=web6dot0`;
        const lyricsRes = await fetch(directUrl, {
          headers: { 'User-Agent': UA, Referer: REFERER, Origin: ORIGIN, Cookie: COOKIE },
        });

        if (lyricsRes.ok) {
          const data: any = await lyricsRes.json();
          if (data?.lyrics) {
            const clean = cleanText(data.lyrics).replace(/<br\s*[\/]?>/gi, '\n').replace(/<[^>]+>/g, '').trim();
            const payload = {
              id,
              lyrics: clean,
              synced_lyrics: '',
              has_synced: false,
              duration,
              available: true,
              source: 'jiosaavn',
            };
            lyricsServerCache.set(cacheKey, payload);
            res.json(payload);
            return;
          }
        }

        // Step B: Search JioSaavn for candidate tracks with lyrics
        if (title) {
          const searchJioUrl = `${JIO_API}?__call=search.getResults&q=${encodeURIComponent(
            title
          )}&p=1&n=6&_format=json&ctx=web6dot0&api_version=4`;
          const sRes = await fetch(searchJioUrl, {
            headers: { 'User-Agent': UA, Referer: REFERER, Origin: ORIGIN, Cookie: COOKIE },
          });

          if (sRes.ok) {
            const sData: any = await sRes.json();
            const cand = (sData.results || []).find((r: any) => r && r.more_info?.has_lyrics === 'true');
            if (cand && cand.id) {
              const candLyricsRes = await fetch(
                `${JIO_API}?__call=lyrics.getLyrics&lyrics_id=${encodeURIComponent(cand.id)}&_format=json&ctx=web6dot0`,
                { headers: { 'User-Agent': UA, Referer: REFERER, Origin: ORIGIN, Cookie: COOKIE } }
              );
              if (candLyricsRes.ok) {
                const cData: any = await candLyricsRes.json();
                if (cData?.lyrics) {
                  const clean = cleanText(cData.lyrics).replace(/<br\s*[\/]?>/gi, '\n').replace(/<[^>]+>/g, '').trim();
                  const payload = {
                    id,
                    lyrics: clean,
                    synced_lyrics: '',
                    has_synced: false,
                    duration,
                    available: true,
                    source: 'jiosaavn_search',
                  };
                  lyricsServerCache.set(cacheKey, payload);
                  res.json(payload);
                  return;
                }
              }
            }
          }
        }
      } catch {
        // ignore
      }

      // DO NOT cache not-found failures to prevent poisoning the cache on rate-limits
      res.json({
        id,
        lyrics: '',
        synced_lyrics: '',
        has_synced: false,
        duration,
        available: false,
        source: 'none',
      });
      return;
    }

    // 8. Related Songs
    case 'related': {
      const title = String(req.query.title || '').trim();
      const artist = String(req.query.artist || '').trim();
      const query = [title, artist].filter(Boolean).join(' ') || 'Bollywood Hits';
      const results = await searchSongs(query, 1, 24);
      res.json({ results });
      return;
    }

    // 9. Artist Directory & Songs
    case 'artist_directory': {
      const q = String(req.query.q || '').toLowerCase().trim();
      let list = SEED_ARTISTS;
      if (q) {
        list = list.filter((a) => a.name.toLowerCase().includes(q));
      }
      res.json({ artists: list });
      return;
    }

    case 'artist_songs':
    case 'artist_secondary':
    case 'artist_shoeb': {
      const artist = String(req.query.artist || req.query.name || '').trim() || 'Arijit Singh';
      const limit = Math.min(50, Math.max(10, parseInt(String(req.query.limit || '40'), 10) || 40));
      const page = Math.max(1, parseInt(String(req.query.page || '1'), 10) || 1);
      let results = await searchSongs(artist, page, limit);
      if (!results.length && page === 1) {
        results = await searchSongs(`${artist} Top Hindi Songs`, 1, limit);
      }
      if (!results.length && artist.toLowerCase().includes('arijit')) {
        const romance = await getRomanceStation(50);
        results = romance.arijit || romance.results;
      }
      res.json({
        ok: true,
        results,
        artist,
        page,
        total: Math.max(results.length, 120),
        has_more: results.length >= 10,
      });
      return;
    }

    case 'artist_image': {
      const name = String(req.query.name || '').trim().toLowerCase();
      const match = SEED_ARTISTS.find((a) => a.name.toLowerCase() === name);
      if (match?.image) {
        res.redirect(match.image);
      } else {
        res.redirect('https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=500&auto=format&fit=crop&q=80');
      }
      return;
    }

    // 10. Downloads
    case 'download_capability': {
      res.json({
        ok: true,
        formats: ['mp3', 'source'],
        max_kbps: 320,
      });
      return;
    }

    case 'download_prepare': {
      const id = String(req.query.id || '').replace(/^saavn_/, '').trim();
      res.json({
        ok: true,
        id,
        filename: `sterniters_${id}.mp3`,
        ready: true,
      });
      return;
    }

    case 'download_ticket': {
      const id = String(req.query.id || '').replace(/^saavn_/, '').trim();
      res.json({
        ok: true,
        ticket: `ticket_${Date.now()}`,
        url: `/backend.php?action=download&id=${encodeURIComponent(id)}`,
      });
      return;
    }

    case 'download': {
      const id = String(req.query.id || '').replace(/^saavn_/, '').trim();
      const raw = await getSongDetails(id);
      if (!raw) {
        res.status(404).send('Track not found');
        return;
      }
      const streamUrl = await resolveStreamFromRaw(raw);
      if (!streamUrl) {
        res.status(404).send('Audio not found');
        return;
      }

      const song = normSong(raw);
      const filename = `${song.title} - ${song.artist}.mp3`.replace(/[/\\?%*:|"<>]/g, '_');
      await proxyAudioStream(req, res, streamUrl, filename);
      return;
    }

    // 11. Listen Together Rooms
    case 'room_create': {
      if (activeRooms.size >= MAX_CONCURRENT_ROOMS) {
        res.status(429).json({ ok: false, error: 'Maximum room capacity reached. Please try again later.' });
        return;
      }

      const body = req.body || {};
      const participantId = String(body.participant_id || `user_${Date.now()}`).slice(0, 64);
      const name = cleanText(String(body.name || 'Host')).slice(0, 32);
      const hostToken = crypto.randomBytes(16).toString('hex');
      const code = cleanRoomCode();

      const newRoom: RoomData = {
        code,
        created_at: Math.floor(Date.now() / 1000),
        last_activity: Math.floor(Date.now() / 1000),
        updated_at_ms: Date.now(),
        seq: 1,
        ended: false,
        host_token_hash: crypto.createHash('sha256').update(hostToken).digest('hex'),
        host_participant_id: participantId,
        track: body.track || null,
        upcoming: Array.isArray(body.upcoming) ? body.upcoming.slice(0, 50) : [],
        position: Math.max(0, parseFloat(body.position || '0') || 0),
        playing: Boolean(body.playing),
        playback_rate: Math.min(2.0, Math.max(0.5, parseFloat(body.playback_rate || '1') || 1)),
        participants: {
          [participantId]: {
            name,
            role: 'host',
            last_seen: Math.floor(Date.now() / 1000),
          },
        },
      };

      activeRooms.set(code, newRoom);

      res.json({
        ok: true,
        code,
        host_token: hostToken,
        room: {
          code,
          seq: newRoom.seq,
          ended: false,
          track: newRoom.track,
          upcoming: newRoom.upcoming,
          position: newRoom.position,
          playing: newRoom.playing,
          playback_rate: newRoom.playback_rate,
          participants: newRoom.participants,
        },
      });
      return;
    }

    case 'room_join': {
      const body = req.body || {};
      const code = String(body.code || '').toUpperCase().trim();
      const participantId = String(body.participant_id || `user_${Date.now()}`);
      const name = String(body.name || 'Listener');

      const room = activeRooms.get(code);
      if (!room || room.ended) {
        res.status(404).json({ ok: false, error: 'Room not found or expired' });
        return;
      }

      room.participants[participantId] = {
        name,
        role: 'listener',
        last_seen: Math.floor(Date.now() / 1000),
      };
      room.last_activity = Math.floor(Date.now() / 1000);
      room.seq += 1;

      res.json({
        ok: true,
        room: {
          code: room.code,
          seq: room.seq,
          ended: false,
          track: room.track,
          upcoming: room.upcoming,
          position: room.position,
          playing: room.playing,
          playback_rate: room.playback_rate,
          participants: room.participants,
        },
      });
      return;
    }

    case 'room_state': {
      const code = String(req.query.code || '').toUpperCase().trim();
      const room = activeRooms.get(code);
      if (!room || room.ended) {
        res.status(404).json({ ok: false, error: 'Room not found or expired' });
        return;
      }

      res.json({
        ok: true,
        room: {
          code: room.code,
          seq: room.seq,
          ended: room.ended,
          track: room.track,
          upcoming: room.upcoming,
          position: room.position,
          playing: room.playing,
          playback_rate: room.playback_rate,
          participants: room.participants,
        },
      });
      return;
    }

    case 'room_heartbeat': {
      const body = req.body || {};
      const code = String(body.code || '').toUpperCase().trim();
      const participantId = String(body.participant_id || '');
      const room = activeRooms.get(code);

      if (room && room.participants[participantId]) {
        room.participants[participantId].last_seen = Math.floor(Date.now() / 1000);
        room.last_activity = Math.floor(Date.now() / 1000);
      }

      res.json({ ok: true });
      return;
    }

    case 'room_update': {
      const body = req.body || {};
      const code = String(body.code || '').toUpperCase().trim();
      const hostToken = String(body.host_token || '');
      const room = activeRooms.get(code);

      if (!room) {
        res.status(404).json({ ok: false, error: 'Room not found' });
        return;
      }

      const tokenHash = crypto.createHash('sha256').update(hostToken).digest('hex');
      if (tokenHash !== room.host_token_hash) {
        res.status(403).json({ ok: false, error: 'Unauthorized host token' });
        return;
      }

      if (body.track !== undefined) room.track = body.track;
      if (Array.isArray(body.upcoming)) room.upcoming = body.upcoming;
      if (body.position !== undefined) room.position = parseFloat(body.position) || 0;
      if (body.playing !== undefined) room.playing = Boolean(body.playing);
      if (body.playback_rate !== undefined) room.playback_rate = parseFloat(body.playback_rate) || 1;

      room.updated_at_ms = Date.now();
      room.last_activity = Math.floor(Date.now() / 1000);
      room.seq += 1;

      res.json({
        ok: true,
        room: {
          code: room.code,
          seq: room.seq,
          ended: room.ended,
          track: room.track,
          upcoming: room.upcoming,
          position: room.position,
          playing: room.playing,
          playback_rate: room.playback_rate,
          participants: room.participants,
        },
      });
      return;
    }

    case 'room_leave':
    case 'room_end': {
      const body = req.body || {};
      const code = String(body.code || '').toUpperCase().trim();
      const participantId = String(body.participant_id || '');
      const room = activeRooms.get(code);

      if (room) {
        delete room.participants[participantId];
        if (action === 'room_end' || Object.keys(room.participants).length === 0) {
          room.ended = true;
        }
      }

      res.json({ ok: true });
      return;
    }

    // Default / Unknown action
    default: {
      res.json({ ok: true, action, message: 'Action processed', results: [] });
      return;
    }
  }
}

// -------------------------------------------------------------
// MUSIC ROUTER ENDPOINTS (For React components / API consumers)
// -------------------------------------------------------------
musicRouter.get('/search', async (req: Request, res: Response) => {
  const query = String(req.query.q || '').trim();
  const page = parseInt(String(req.query.p || '1'), 10) || 1;
  const limit = Math.min(50, Math.max(5, parseInt(String(req.query.n || '20'), 10) || 20));

  if (!query) {
    res.json({ results: [], total: 0 });
    return;
  }

  const results = await searchSongs(query, page, limit);
  res.json({ results, total: results.length });
});

musicRouter.get('/trending', async (req: Request, res: Response) => {
  const limit = Math.min(50, Math.max(5, parseInt(String(req.query.n || '25'), 10) || 25));
  const results = await getTrendingSongs(limit);
  res.json({ results });
});

musicRouter.get('/home', async (req: Request, res: Response) => {
  const payload = await getHomePayload(60);
  res.json(payload);
});

musicRouter.get('/romance', async (req: Request, res: Response) => {
  const payload = await getRomanceStation(80);
  res.json(payload);
});

musicRouter.get('/stream-proxy', async (req: Request, res: Response) => {
  const songId = String(req.query.id || '').replace(/^saavn_/, '').trim();
  if (!songId) {
    res.status(400).send('Song ID missing');
    return;
  }

  const rawSong = await getSongDetails(songId);
  if (!rawSong) {
    res.status(404).send('Song not found');
    return;
  }

  const streamUrl = await resolveStreamFromRaw(rawSong);
  if (!streamUrl) {
    res.status(404).send('Stream URL not found');
    return;
  }

  await proxyAudioStream(req, res, streamUrl);
});

musicRouter.get('/lyrics', async (req: Request, res: Response) => {
  const songId = String(req.query.id || '').replace(/^saavn_/, '').trim();
  if (!songId) {
    res.status(400).json({ error: 'Song ID is required' });
    return;
  }

  try {
    const url = `${JIO_API}?__call=lyrics.getLyrics&lyrics_id=${encodeURIComponent(
      songId
    )}&_format=json&ctx=web6dot0`;

    const response = await fetch(url, {
      headers: {
        'User-Agent': UA,
        Referer: REFERER,
        Origin: ORIGIN,
        Cookie: COOKIE,
      },
    });

    if (!response.ok) {
      res.status(404).json({ error: 'Lyrics not found' });
      return;
    }

    const data: any = await response.json();
    if (data?.lyrics) {
      const cleanLyrics = cleanText(data.lyrics)
        .replace(/<br\s*[\/]?>/gi, '\n')
        .replace(/<\/p>/gi, '\n\n')
        .replace(/<[^>]+>/g, '')
        .trim();

      const lines = cleanLyrics
        .split('\n')
        .map((l: string) => l.trim())
        .filter((l: string) => l.length > 0);

      res.json({
        id: songId,
        lyrics: cleanLyrics,
        lines,
        snippet: data.snippet || lines.slice(0, 4).join('\n'),
        hasSynced: false,
      });
    } else {
      res.json({ id: songId, lyrics: null, message: 'Lyrics not available for this song' });
    }
  } catch (err: any) {
    res.status(500).json({ error: 'Failed to retrieve lyrics', details: err?.message });
  }
});

musicRouter.get('/download', async (req: Request, res: Response) => {
  const songId = String(req.query.id || '').replace(/^saavn_/, '').trim();
  try {
    const rawSong = await getSongDetails(songId);
    if (!rawSong) {
      res.status(404).send('Track not found');
      return;
    }

    const streamUrl = await resolveStreamFromRaw(rawSong);
    if (!streamUrl) {
      res.status(404).send('Download stream not found');
      return;
    }

    const song = normSong(rawSong);
    const filename = `${song.title} - ${song.artist}.mp3`.replace(/[/\\?%*:|"<>]/g, '_');
    await proxyAudioStream(req, res, streamUrl, filename);
  } catch (err: any) {
    res.status(500).send('Download failed');
  }
});
