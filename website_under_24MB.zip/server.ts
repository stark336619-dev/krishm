import express from 'express';
import type { Request, Response, NextFunction } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import crypto from 'crypto';
import { musicRouter, handleBackendPhp } from './server/musicEngine.ts';
import {
  securityHeadersMiddleware,
  dynamicCorsMiddleware,
  methodGuardMiddleware,
  globalApiRateLimiter,
  sensitiveEndpointRateLimiter,
  inputSanitizerMiddleware,
  requireAdminSecret,
  logSecurityEvent,
} from './server/securityGuard.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Automatic Background Security: Method restriction, HTTP Headers, Dynamic CORS & Input Sanitizer
app.use(methodGuardMiddleware);
app.use(securityHeadersMiddleware);
app.use(dynamicCorsMiddleware);
app.use(inputSanitizerMiddleware);

// Limit JSON and URL-encoded payload sizes to 100kb (prevents memory exhaustion attacks)
app.use(express.json({ limit: '100kb' }));
app.use(express.urlencoded({ extended: false, limit: '100kb' }));
app.use(express.static(path.resolve(__dirname, 'public')));

// Rate-limited Music Engine Endpoints
app.use((req, res, next) => {
  if (req.path === '/backend.php' || req.path.endsWith('/backend.php')) {
    return globalApiRateLimiter(req, res, () => handleBackendPhp(req, res));
  }
  next();
});
app.all(['/backend.php', '/backend.php/'], globalApiRateLimiter, handleBackendPhp);
app.use('/api/music', globalApiRateLimiter, musicRouter);

// In-memory server credentials override (configured dynamically via Admin Settings or env)
let runtimeSpotifyClientId = process.env.SPOTIFY_CLIENT_ID || '';
let runtimeSpotifyClientSecret = process.env.SPOTIFY_CLIENT_SECRET || '';

// Base URLs
let customWebsiteUrl = process.env.CUSTOM_WEBSITE_URL || 'https://krish-gaana.ai.studio';
const APP_URL =
  process.env.APP_URL ||
  'https://ais-dev-bqqfhpfmdr4fx2imh7y6qs-225291614794.asia-southeast1.run.app';
const SHARED_APP_URL = APP_URL.includes('ais-dev-')
  ? APP_URL.replace('ais-dev-', 'ais-pre-')
  : APP_URL;
const FIREBASE_APP_URL = 'https://methodical-hall-7bcxw.firebaseapp.com';
const FIREBASE_WEB_APP_URL = 'https://methodical-hall-7bcxw.web.app';

// In-memory server cache & pending OAuth sessions
const serverCache = new Map<string, { data: any; expiresAt: number }>();
interface OAuthSession {
  verifier: string;
  redirectUri: string;
  createdAt: number;
}
const pendingOAuthSessions = new Map<string, OAuthSession>();

// Cleanup expired OAuth sessions periodically (older than 15 mins)
setInterval(() => {
  const now = Date.now();
  for (const [state, session] of pendingOAuthSessions.entries()) {
    if (now - session.createdAt > 15 * 60 * 1000) {
      pendingOAuthSessions.delete(state);
    }
  }
}, 5 * 60 * 1000);

// Helper: Determine canonical redirect URI based on request
function resolveRedirectUri(req: Request): string {
  // 1. Explicit redirect_uri param requested by client
  const requestedUri = req.query.redirect_uri as string | undefined;
  if (requestedUri) {
    try {
      const parsed = new URL(requestedUri);
      if (
        (customWebsiteUrl && parsed.origin === customWebsiteUrl.replace(/\/$/, '')) ||
        parsed.origin === FIREBASE_APP_URL ||
        parsed.origin === FIREBASE_WEB_APP_URL ||
        parsed.origin === APP_URL ||
        parsed.origin === SHARED_APP_URL ||
        parsed.hostname.endsWith('ai.studio') ||
        parsed.hostname.endsWith('firebaseapp.com') ||
        parsed.hostname.endsWith('web.app') ||
        parsed.hostname.endsWith('run.app') ||
        parsed.hostname === 'localhost'
      ) {
        return requestedUri;
      }
    } catch {
      // ignore invalid URL
    }
  }

  // 2. Custom website URL takes highest precedence if set
  if (customWebsiteUrl) {
    const cleanCustom = customWebsiteUrl.replace(/\/$/, '');
    return `${cleanCustom}/api/spotify/callback`;
  }

  // 3. Query param origin or request headers
  const reqOrigin =
    (req.query.origin as string) ||
    req.headers.origin ||
    (req.headers.referer ? new URL(req.headers.referer as string).origin : undefined);

  if (reqOrigin && typeof reqOrigin === 'string') {
    if (
      reqOrigin.includes('methodical-hall-7bcxw') ||
      reqOrigin.includes('firebaseapp.com') ||
      reqOrigin.includes('web.app')
    ) {
      return `${reqOrigin.replace(/\/$/, '')}/api/spotify/callback`;
    }
    if (reqOrigin.includes('run.app') || reqOrigin.includes('localhost')) {
      return `${reqOrigin.replace(/\/$/, '')}/api/spotify/callback`;
    }
  }

  // 4. User configured Firebase callback URL as primary target
  return `${FIREBASE_APP_URL}/api/spotify/callback`;
}

// API: Website URL Management (Get current URL configuration)
app.get('/api/website/url', (req: Request, res: Response) => {
  res.json({
    customWebsiteUrl: customWebsiteUrl || null,
    appUrl: APP_URL,
    sharedAppUrl: SHARED_APP_URL,
    firebaseAppUrl: FIREBASE_APP_URL,
    firebaseWebUrl: FIREBASE_WEB_APP_URL,
    activeUrl: customWebsiteUrl || FIREBASE_APP_URL || APP_URL,
    callbackUrl: customWebsiteUrl
      ? `${customWebsiteUrl.replace(/\/$/, '')}/api/spotify/callback`
      : `${FIREBASE_APP_URL}/api/spotify/callback`,
  });
});

// API: Website URL Management (Update website URL / custom domain)
app.post(
  '/api/website/url',
  sensitiveEndpointRateLimiter,
  requireAdminSecret,
  (req: Request, res: Response) => {
    const { url } = req.body;
    if (url === null || url === '') {
      customWebsiteUrl = '';
      res.json({
        success: true,
        message: 'Website URL reset to default.',
        activeUrl: FIREBASE_APP_URL,
        customWebsiteUrl: null,
      });
      return;
    }

    if (typeof url !== 'string' || !url.trim() || url.length > 256) {
      res.status(400).json({ error: 'Please provide a valid website URL or custom domain.' });
      return;
    }

    let formatted = url.trim();
    if (!formatted.startsWith('http://') && !formatted.startsWith('https://')) {
      formatted = `https://${formatted}`;
    }
    formatted = formatted.replace(/\/$/, '');

    try {
      const parsed = new URL(formatted);
      // Require valid public hostname, disallow IP addresses, localhost, and metadata
      const host = parsed.hostname.toLowerCase();
      if (
        !host.includes('.') ||
        host === 'localhost' ||
        host.endsWith('.local') ||
        host.endsWith('.internal') ||
        host.includes('metadata') ||
        /^\d+\.\d+\.\d+\.\d+$/.test(host)
      ) {
        res.status(400).json({ error: 'Invalid custom domain. Must be a valid public hostname.' });
        return;
      }

      customWebsiteUrl = formatted;
      res.json({
        success: true,
        message: 'Website URL updated successfully.',
        activeUrl: customWebsiteUrl,
        customWebsiteUrl,
        callbackUrl: `${customWebsiteUrl}/api/spotify/callback`,
      });
    } catch (e: any) {
      res.status(400).json({ error: 'Invalid URL format.' });
    }
  }
);

// API: Health check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// API: Provider Status
app.get('/api/providers/status', (req: Request, res: Response) => {
  const spotifyConfigured = Boolean(runtimeSpotifyClientId);

  res.json({
    providers: [
      {
        id: 'itunes',
        name: 'Regional & Multi-Language Music (Apple Catalog)',
        isConfigured: true,
        health: 'healthy',
        requiresCredentials: false,
        attributionText: 'Audio previews & metadata provided via Apple iTunes Search API.',
      },
      {
        id: 'jamendo',
        name: 'Jamendo Music (Creative Commons)',
        isConfigured: true,
        health: 'healthy',
        requiresCredentials: false,
        attributionText: 'Licensed music via Jamendo API.',
      },
      {
        id: 'spotify',
        name: 'Spotify Web API',
        isConfigured: spotifyConfigured,
        health: spotifyConfigured ? 'healthy' : 'unconfigured',
        requiresCredentials: true,
        attributionText: 'Content provided via Spotify Web API.',
        setupNotice: spotifyConfigured
          ? 'Configured and operational.'
          : 'Requires SPOTIFY_CLIENT_ID and optional SPOTIFY_CLIENT_SECRET.',
      },
    ],
  });
});

// API: Spotify OAuth Configuration & Exact Redirect URIs
app.get('/api/spotify/config', (req: Request, res: Response) => {
  const customCallback = customWebsiteUrl ? `${customWebsiteUrl.replace(/\/$/, '')}/api/spotify/callback` : null;
  const firebaseCallback = `${FIREBASE_APP_URL}/api/spotify/callback`;
  const firebaseWebCallback = `${FIREBASE_WEB_APP_URL}/api/spotify/callback`;
  const devCallback = `${APP_URL}/api/spotify/callback`;
  const sharedCallback = `${SHARED_APP_URL}/api/spotify/callback`;
  const devCallbackAlias = `${APP_URL}/callback`;
  const sharedCallbackAlias = `${SHARED_APP_URL}/callback`;

  const instructions = [
    'Go to Spotify Developer Dashboard: https://developer.spotify.com/dashboard',
    'Select your app -> Settings -> Basic Information',
  ];
  if (customCallback) {
    instructions.push(`In "Redirect URIs", register your custom domain: ${customCallback}`);
  }
  instructions.push(`In "Redirect URIs", register: ${firebaseCallback}`);
  instructions.push(`Also register: ${devCallback} if previewing within AI Studio.`);
  instructions.push('Save changes in Spotify Developer Dashboard.');

  res.json({
    configured: Boolean(runtimeSpotifyClientId),
    hasClientSecret: Boolean(runtimeSpotifyClientSecret),
    clientId: runtimeSpotifyClientId ? `${runtimeSpotifyClientId.slice(0, 6)}...` : null,
    rawClientId: runtimeSpotifyClientId || null,
    customWebsiteUrl: customWebsiteUrl || null,
    appUrl: APP_URL,
    sharedAppUrl: SHARED_APP_URL,
    firebaseAppUrl: FIREBASE_APP_URL,
    exactCallbackUrls: {
      custom: customCallback,
      firebase: firebaseCallback,
      firebaseWeb: firebaseWebCallback,
      primaryDev: devCallback,
      primaryShared: sharedCallback,
      aliasDev: devCallbackAlias,
      aliasShared: sharedCallbackAlias,
    },
    instructions,
  });
});

// API: Configure Spotify credentials at runtime (Restricted Admin only)
app.post(
  '/api/spotify/configure',
  sensitiveEndpointRateLimiter,
  requireAdminSecret,
  (req: Request, res: Response) => {
    const { clientId, clientSecret } = req.body;
    if (typeof clientId === 'string' && clientId.length <= 64 && /^[a-zA-Z0-9_-]+$/.test(clientId.trim())) {
      runtimeSpotifyClientId = clientId.trim();
    }
    if (typeof clientSecret === 'string' && clientSecret.length <= 64 && /^[a-zA-Z0-9_-]+$/.test(clientSecret.trim())) {
      runtimeSpotifyClientSecret = clientSecret.trim();
    }
    serverCache.delete('spotify_token');

    res.json({
      success: true,
      configured: Boolean(runtimeSpotifyClientId),
      hasClientSecret: Boolean(runtimeSpotifyClientSecret),
      message: 'Spotify credentials updated on server.',
    });
  }
);

// API: Initiate Spotify Authorization Code with PKCE Flow
app.get('/api/spotify/auth-url', (req: Request, res: Response) => {
  const clientId = runtimeSpotifyClientId || process.env.SPOTIFY_CLIENT_ID;

  if (!clientId) {
    res.status(400).json({
      error: 'Spotify Client ID is not configured.',
      help: 'Please set SPOTIFY_CLIENT_ID in your environment or enter it in Sonora Admin Settings -> Spotify Settings.',
    });
    return;
  }

  // 1. Generate cryptographic state for CSRF protection
  const state = crypto.randomBytes(16).toString('hex');

  // 2. Generate PKCE code_verifier (43-128 random chars) & code_challenge (SHA-256 base64url)
  const codeVerifier = crypto.randomBytes(32).toString('base64url');
  const codeChallenge = crypto
    .createHash('sha256')
    .update(codeVerifier)
    .digest('base64url');

  // 3. Determine redirect URI
  const redirectUri = resolveRedirectUri(req);

  // 4. Save session state with 10-minute validity
  pendingOAuthSessions.set(state, {
    verifier: codeVerifier,
    redirectUri,
    createdAt: Date.now(),
  });

  // 5. Scopes needed for Spotify discovery and user library read
  const scopes = [
    'user-read-private',
    'user-read-email',
    'user-library-read',
    'user-top-read',
    'playlist-read-private',
    'playlist-read-collaborative',
  ].join(' ');

  const params = new URLSearchParams({
    response_type: 'code',
    client_id: clientId,
    scope: scopes,
    redirect_uri: redirectUri,
    state,
    code_challenge: codeChallenge,
    code_challenge_method: 'S256',
  });

  const authUrl = `https://accounts.spotify.com/authorize?${params.toString()}`;

  res.json({
    url: authUrl,
    state,
    redirectUri,
  });
});

// Spotify OAuth Callback Handler
const spotifyCallbackHandler = async (req: Request, res: Response) => {
  const { code, state, error, error_description } = req.query;

  // Handle user cancellation or provider error
  if (error) {
    const errorMsg = String(error_description || error || 'Access denied');
    res.status(200).send(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>Spotify Connection Cancelled — SONORA</title>
          <style>
            body {
              background: #121212;
              color: #ffffff;
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              display: flex;
              align-items: center;
              justify-content: center;
              height: 100vh;
              margin: 0;
              text-align: center;
              padding: 20px;
              box-sizing: border-box;
            }
            .card {
              background: #181818;
              border: 1px solid #282828;
              border-radius: 16px;
              padding: 32px;
              max-width: 440px;
              box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            }
            h2 { font-size: 18px; color: #ef4444; margin: 0 0 12px; }
            p { font-size: 13px; color: #a7a7a7; margin: 0 0 20px; line-height: 1.5; }
            button {
              background: #282828;
              color: #fff;
              border: 1px solid rgba(255,255,255,0.1);
              padding: 8px 18px;
              border-radius: 9999px;
              font-size: 12px;
              cursor: pointer;
            }
          </style>
        </head>
        <body>
          <div class="card">
            <h2>Connection Cancelled</h2>
            <p>${errorMsg.replace(/</g, '&lt;')}</p>
            <button onclick="window.close()">Close Window</button>
          </div>
          <script>
            if (window.opener) {
              window.opener.postMessage({ type: 'SPOTIFY_AUTH_ERROR', error: '${String(error)}' }, '*');
              setTimeout(() => window.close(), 1200);
            }
          </script>
        </body>
      </html>
    `);
    return;
  }

  // Validate state & code existence
  if (!code || !state) {
    res.status(400).send(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>Invalid Request — SONORA</title>
          <style>
            body { background: #121212; color: #fff; font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
            .card { background: #181818; border: 1px solid #282828; border-radius: 16px; padding: 32px; text-align: center; max-width: 400px; }
            h2 { color: #f59e0b; font-size: 18px; }
            p { font-size: 13px; color: #a7a7a7; }
          </style>
        </head>
        <body>
          <div class="card">
            <h2>Missing Parameters</h2>
            <p>The authorization response was missing required code or state parameters.</p>
            <script>
              if (window.opener) {
                window.opener.postMessage({ type: 'SPOTIFY_AUTH_ERROR', error: 'missing_parameters' }, '*');
              }
            </script>
          </div>
        </body>
      </html>
    `);
    return;
  }

  // Validate state in session store
  const session = pendingOAuthSessions.get(String(state));
  if (!session) {
    res.status(400).send(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>Session Expired — SONORA</title>
          <style>
            body { background: #121212; color: #fff; font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
            .card { background: #181818; border: 1px solid #282828; border-radius: 16px; padding: 32px; text-align: center; max-width: 440px; }
            h2 { color: #ef4444; font-size: 18px; }
            p { font-size: 13px; color: #a7a7a7; line-height: 1.5; }
          </style>
        </head>
        <body>
          <div class="card">
            <h2>OAuth Session Expired</h2>
            <p>Your authentication request expired or the state parameter was invalid. Please return to SONORA and try connecting again.</p>
            <script>
              if (window.opener) {
                window.opener.postMessage({ type: 'SPOTIFY_AUTH_ERROR', error: 'session_expired' }, '*');
                setTimeout(() => window.close(), 2000);
              }
            </script>
          </div>
        </body>
      </html>
    `);
    return;
  }

  // Delete session to prevent replay
  pendingOAuthSessions.delete(String(state));

  const clientId = runtimeSpotifyClientId || process.env.SPOTIFY_CLIENT_ID || '';
  const clientSecret = runtimeSpotifyClientSecret || process.env.SPOTIFY_CLIENT_SECRET || '';

  try {
    // Exchange authorization code + code_verifier for tokens
    const bodyParams = new URLSearchParams({
      grant_type: 'authorization_code',
      code: String(code),
      redirect_uri: session.redirectUri,
      client_id: clientId,
      code_verifier: session.verifier,
    });

    const headers: Record<string, string> = {
      'Content-Type': 'application/x-www-form-urlencoded',
    };

    if (clientSecret) {
      headers['Authorization'] = `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString('base64')}`;
    }

    const tokenRes = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers,
      body: bodyParams,
    });

    const tokenData = await tokenRes.json();

    if (!tokenRes.ok) {
      const errorMsg = tokenData.error_description || tokenData.error || 'Token exchange failed';
      res.status(400).send(`
        <!DOCTYPE html>
        <html>
          <head>
            <meta charset="utf-8" />
            <title>Authentication Failed — SONORA</title>
            <style>
              body { background: #121212; color: #fff; font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
              .card { background: #181818; border: 1px solid #282828; border-radius: 16px; padding: 32px; text-align: center; max-width: 440px; }
              h2 { color: #ef4444; font-size: 18px; }
              p { font-size: 13px; color: #a7a7a7; line-height: 1.5; }
            </style>
          </head>
          <body>
            <div class="card">
              <h2>Token Exchange Failed</h2>
              <p>${String(errorMsg).replace(/</g, '&lt;')}</p>
              <script>
                if (window.opener) {
                  window.opener.postMessage({ type: 'SPOTIFY_AUTH_ERROR', error: '${String(errorMsg)}' }, '*');
                  setTimeout(() => window.close(), 2500);
                }
              </script>
            </div>
          </body>
        </html>
      `);
      return;
    }

    // Fetch Spotify user profile info (name, image, Spotify link)
    let spotifyProfile: any = null;
    try {
      const userRes = await fetch('https://api.spotify.com/v1/me', {
        headers: { Authorization: `Bearer ${tokenData.access_token}` },
      });
      if (userRes.ok) {
        spotifyProfile = await userRes.json();
      }
    } catch {
      // Non-critical, continue
    }

    // Return friendly popup closer with postMessage payload
    const payload = JSON.stringify({
      type: 'SPOTIFY_AUTH_SUCCESS',
      accessToken: tokenData.access_token,
      refreshToken: tokenData.refresh_token || '',
      expiresIn: tokenData.expires_in,
      spotifyUser: spotifyProfile
        ? {
            id: spotifyProfile.id,
            displayName: spotifyProfile.display_name,
            email: spotifyProfile.email,
            imageUrl: spotifyProfile.images?.[0]?.url || '',
            profileUrl: spotifyProfile.external_urls?.spotify || '',
          }
        : null,
    });

    res.status(200).send(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>Spotify Connected — SONORA</title>
          <style>
            body {
              background: #121212;
              color: #ffffff;
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              display: flex;
              align-items: center;
              justify-content: center;
              height: 100vh;
              margin: 0;
              text-align: center;
              padding: 20px;
              box-sizing: border-box;
            }
            .card {
              background: #181818;
              border: 1px solid #282828;
              border-radius: 16px;
              padding: 32px;
              max-width: 420px;
              box-shadow: 0 10px 30px rgba(0,0,0,0.5);
            }
            .spinner {
              width: 36px;
              height: 36px;
              border: 3px solid rgba(29, 185, 84, 0.2);
              border-top-color: #1db954;
              border-radius: 50%;
              animation: spin 0.8s linear infinite;
              margin: 0 auto 16px;
            }
            @keyframes spin { to { transform: rotate(360deg); } }
            h2 { font-size: 18px; margin: 0 0 8px; font-weight: 700; color: #1db954; }
            p { font-size: 13px; color: #a7a7a7; margin: 0; }
          </style>
        </head>
        <body>
          <div class="card">
            <div class="spinner"></div>
            <h2>Spotify Connected!</h2>
            <p>Linking with SONORA. This window will close automatically...</p>
          </div>
          <script>
            try {
              const data = ${payload};
              if (window.opener) {
                window.opener.postMessage(data, '*');
                setTimeout(() => window.close(), 500);
              } else {
                setTimeout(() => { window.location.href = '/'; }, 1000);
              }
            } catch (e) {
              window.close();
            }
          </script>
        </body>
      </html>
    `);
  } catch (err: any) {
    logSecurityEvent('SPOTIFY_OAUTH_EXCHANGE_ERROR', { error: err?.message || 'Unknown' });
    res.status(500).send(`
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>Server Error — KRISH MUSIC</title>
          <style>
            body { background: #121212; color: #fff; font-family: sans-serif; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
            .card { background: #181818; border: 1px solid #282828; border-radius: 16px; padding: 32px; text-align: center; max-width: 440px; }
            h2 { color: #ef4444; font-size: 18px; }
            p { font-size: 13px; color: #a7a7a7; }
          </style>
        </head>
        <body>
          <div class="card">
            <h2>Authentication Server Error</h2>
            <p>An unexpected error occurred during token exchange. Please close this window and try again.</p>
            <script>
              if (window.opener) {
                window.opener.postMessage({ type: 'SPOTIFY_AUTH_ERROR', error: 'Authentication exchange error' }, '*');
                setTimeout(() => window.close(), 2500);
              }
            </script>
          </div>
        </body>
      </html>
    `);
  }
};

// Register callback routes with both trailing slash variations and aliases
app.get(
  [
    '/api/spotify/callback',
    '/api/spotify/callback/',
    '/callback',
    '/callback/',
    '/auth/spotify/callback',
    '/auth/spotify/callback/',
  ],
  spotifyCallbackHandler
);

// API: Refresh Spotify Access Token
app.post('/api/spotify/refresh', async (req: Request, res: Response) => {
  const { refresh_token } = req.body;
  const clientId = runtimeSpotifyClientId || process.env.SPOTIFY_CLIENT_ID;
  const clientSecret = runtimeSpotifyClientSecret || process.env.SPOTIFY_CLIENT_SECRET;

  if (!refresh_token) {
    res.status(400).json({ error: 'Missing refresh_token in request body.' });
    return;
  }

  if (!clientId) {
    res.status(400).json({ error: 'Spotify Client ID not configured.' });
    return;
  }

  try {
    const bodyParams = new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token,
      client_id: clientId,
    });

    const headers: Record<string, string> = {
      'Content-Type': 'application/x-www-form-urlencoded',
    };

    if (clientSecret) {
      headers['Authorization'] = `Basic ${Buffer.from(`${clientId}:${clientSecret}`).toString('base64')}`;
    }

    const tokenRes = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers,
      body: bodyParams,
    });

    const data = await tokenRes.json();
    if (!tokenRes.ok) {
      res.status(tokenRes.status).json({ error: data.error_description || data.error });
      return;
    }

    res.json(data);
  } catch (err: any) {
    logSecurityEvent('SPOTIFY_TOKEN_REFRESH_ERROR', { error: err?.message || 'Unknown' });
    res.status(500).json({ error: 'Failed to refresh Spotify token' });
  }
});

// API: Server-side Spotify Client Credentials token exchange (For catalog browsing without user login)
app.post('/api/spotify/token', sensitiveEndpointRateLimiter, async (req: Request, res: Response) => {
  const clientId = runtimeSpotifyClientId || process.env.SPOTIFY_CLIENT_ID;
  const clientSecret = runtimeSpotifyClientSecret || process.env.SPOTIFY_CLIENT_SECRET;

  if (!clientId || !clientSecret) {
    res.status(400).json({ error: 'Spotify server credentials not configured.' });
    return;
  }

  // Check cached token
  const cached = serverCache.get('spotify_token');
  if (cached && Date.now() < cached.expiresAt) {
    res.json(cached.data);
    return;
  }

  try {
    const creds = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
    const response = await fetch('https://accounts.spotify.com/api/token', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        Authorization: `Basic ${creds}`,
      },
      body: new URLSearchParams({ grant_type: 'client_credentials' }),
    });

    if (!response.ok) {
      res.status(response.status).json({ error: 'Failed to authenticate with Spotify.' });
      return;
    }

    const data = await response.json();
    serverCache.set('spotify_token', {
      data,
      expiresAt: Date.now() + (data.expires_in - 60) * 1000,
    });

    res.json(data);
  } catch (err: any) {
    logSecurityEvent('SPOTIFY_CLIENT_CREDS_ERROR', { error: err?.message || 'Unknown' });
    res.status(500).json({ error: 'Spotify token exchange error' });
  }
});

// API: Clear server cache (Restricted Admin only)
app.post(
  '/api/cache/clear',
  sensitiveEndpointRateLimiter,
  requireAdminSecret,
  (req: Request, res: Response) => {
    serverCache.clear();
    pendingOAuthSessions.clear();
    res.json({ success: true, message: 'Server cache and OAuth sessions cleared.' });
  }
);

// Global Error Handler Middleware: Catches unexpected exceptions and prevents info disclosure
app.use((err: any, req: Request, res: Response, _next: NextFunction) => {
  logSecurityEvent('UNHANDLED_SERVER_EXCEPTION', {
    path: req.path,
    method: req.method,
    message: err?.message || 'Unknown error',
  });
  if (!res.headersSent) {
    res.status(500).json({ error: 'An unexpected internal server error occurred.' });
  }
});

// Vite Middleware mounting
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: {
        middlewareMode: true,
        hmr: process.env.DISABLE_HMR !== 'true',
        watch: process.env.DISABLE_HMR === 'true' ? null : {},
      },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`KRISH MUSIC server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
