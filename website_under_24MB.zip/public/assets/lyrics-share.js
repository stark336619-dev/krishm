/**
 * ══════════════════════════════════════════════════════════════════════════
 * KRISH MUSIC — SPOTIFY MOBILE LYRICS SHARING SYSTEM
 * Dynamic Song-Wise Color Palette, Lyrics Selection & Card Generation
 * ══════════════════════════════════════════════════════════════════════════
 */

(function () {
  'use strict';

  // ─── Curated Dynamic Song Palettes (Spotify Style) ───
  const SPOTIFY_PALETTES = [
    { primary: '#1e7e48', dark: '#091c10', glow: 'rgba(30, 215, 96, 0.38)', accent: '#1ed760', border: 'rgba(30, 215, 96, 0.45)' }, // Emerald Green
    { primary: '#8b263e', dark: '#1c070c', glow: 'rgba(235, 75, 110, 0.40)', accent: '#ff5c82', border: 'rgba(235, 75, 110, 0.45)' }, // Ruby Crimson
    { primary: '#215086', dark: '#081220', glow: 'rgba(64, 140, 230, 0.40)', accent: '#509bf5', border: 'rgba(64, 140, 230, 0.45)' }, // Ocean Sapphire
    { primary: '#6e2b86', dark: '#18071e', glow: 'rgba(180, 80, 220, 0.40)', accent: '#c850f2', border: 'rgba(180, 80, 220, 0.45)' }, // Royal Violet
    { primary: '#a34818', dark: '#220d04', glow: 'rgba(240, 120, 50, 0.40)', accent: '#ff8a45', border: 'rgba(240, 120, 50, 0.45)' }, // Saffron Amber
    { primary: '#1b6b68', dark: '#061716', glow: 'rgba(40, 180, 175, 0.40)', accent: '#38d5ce', border: 'rgba(40, 180, 175, 0.45)' }, // Deep Teal
    { primary: '#8a2b6e', dark: '#1d0717', glow: 'rgba(220, 75, 180, 0.40)', accent: '#f052c5', border: 'rgba(220, 75, 180, 0.45)' }, // Magenta Bloom
    { primary: '#2a3b86', dark: '#090d20', glow: 'rgba(80, 110, 240, 0.40)', accent: '#6285ff', border: 'rgba(80, 110, 240, 0.45)' }, // Electric Indigo
    { primary: '#8a5c18', dark: '#1e1404', glow: 'rgba(230, 160, 45, 0.40)', accent: '#ffbf45', border: 'rgba(230, 160, 45, 0.45)' }, // Warm Gold
    { primary: '#1e6686', dark: '#06161e', glow: 'rgba(45, 165, 220, 0.40)', accent: '#42c0f5', border: 'rgba(45, 165, 220, 0.45)' }  // Cyan Glacier
  ];

  const state = {
    song: null,
    lyricsLines: [], // Array of { id: string, text: string, sec?: number }
    selectedLineIds: new Set(),
    maxSelection: 8, // Up to 8 lines for a full verse while preserving Spotify card beauty
    activeTab: 'lyrics', // 'lyrics' | 'song'
    aspectRatio: '9:16', // '9:16' | '1:1' | '4:5'
    cardPalette: null,
    isGenerating: false,
    loadedImage: null,
    loadedImageUrl: ''
  };

  // ─── Helpers ───
  function $(sel, root = document) {
    return root.querySelector(sel);
  }

  function $$(sel, root = document) {
    return Array.from(root.querySelectorAll(sel));
  }

  function getToastFn() {
    return typeof window.toast === 'function' ? window.toast : (msg) => console.log('[Toast]', msg);
  }

  function getHapticFn() {
    return typeof window.haptic === 'function' ? window.haptic : (lvl) => {
      if (window.navigator?.vibrate) {
        try { window.navigator.vibrate(lvl || 10); } catch (_) {}
      }
    };
  }

  function escapeHtml(str) {
    return String(str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function parseSongArtists(song) {
    if (!song) return 'KRISH MUSIC';
    if (typeof window.artists === 'function') {
      try {
        const res = window.artists(song);
        if (res) return res;
      } catch (_) {}
    }
    if (Array.isArray(song.artists) && song.artists.length > 0) {
      return song.artists.map((a) => (typeof a === 'object' ? a.name || a.title || '' : String(a))).filter(Boolean).join(', ');
    }
    return song.artist || song.singers || song.primary_artists || 'KRISH MUSIC';
  }

  function resolveActiveSong(songOverride) {
    if (songOverride && (songOverride.title || songOverride.id)) return songOverride;

    if (typeof window.getCurrentSong === 'function') {
      try {
        const s = window.getCurrentSong();
        if (s && (s.title || s.id)) return s;
      } catch (_) {}
    }

    if (window.__krishCurrentSong && (window.__krishCurrentSong.title || window.__krishCurrentSong.id)) {
      return window.__krishCurrentSong;
    }

    if (window.current && (window.current.title || window.current.id)) {
      return window.current;
    }

    // Inspect live DOM from player
    const pTitle = document.getElementById('playerTitle')?.textContent?.trim();
    const pArtist = document.getElementById('playerArtist')?.textContent?.trim();
    const mnpTitle = document.getElementById('mnpTitle')?.textContent?.trim();
    const mnpArtist = document.getElementById('mnpArtist')?.textContent?.trim();

    const title = (pTitle && pTitle !== 'Choose a song') ? pTitle : (mnpTitle && mnpTitle !== 'Choose a song') ? mnpTitle : '';
    const artist = (pArtist && pArtist !== 'KRISH MUSIC') ? pArtist : (mnpArtist && mnpArtist !== 'KRISH MUSIC Web') ? mnpArtist : 'KRISH MUSIC';

    const pArtImg = document.querySelector('#playerArt img')?.src ||
                    document.querySelector('.mnp-cover img')?.src ||
                    document.querySelector('.p-track .art img')?.src ||
                    document.getElementById('mnpCover')?.src ||
                    document.querySelector('#playerArt .art img')?.src || '';

    const audioEl = document.getElementById('audio') || window.audio;
    const songId = audioEl?.dataset?.songId || '';

    if (title) {
      return {
        id: songId,
        title: title,
        artist: artist,
        image: pArtImg,
        coverUrl: pArtImg,
        duration: audioEl?.duration || 0
      };
    }

    // Check audio src or catalog
    if (audioEl && (audioEl.src || songId) && window.catalog && Array.isArray(window.catalog)) {
      if (songId) {
        const found = window.catalog.find((s) => String(s.id) === String(songId));
        if (found) return found;
      }
    }

    return null;
  }

  function getSongArtworkUrl(song) {
    if (!song) return '';
    return song.coverUrl || song.image || song.artwork || '';
  }

  function getSongDeepLink(song) {
    const origin = 'https://krish-gaana.ai.studio';
    if (!song) return origin;
    const key = song.id || song.title || '';
    return `${origin}/?song=${encodeURIComponent(key)}`;
  }

  // ─── Dynamic Color Palette Extractor ───
  function getFallbackSongPalette(song) {
    const key = String(song?.id || song?.title || 'krish');
    let hash = 0;
    for (let i = 0; i < key.length; i++) {
      hash = (hash << 5) - hash + key.charCodeAt(i);
      hash |= 0;
    }
    const idx = Math.abs(hash) % SPOTIFY_PALETTES.length;
    return SPOTIFY_PALETTES[idx];
  }

  function extractSongPalette(img, song) {
    const fallback = getFallbackSongPalette(song);
    if (!img) return fallback;

    try {
      const c = document.createElement('canvas');
      c.width = 32;
      c.height = 32;
      const ctx = c.getContext('2d', { willReadFrequently: true });
      if (!ctx) return fallback;

      ctx.drawImage(img, 0, 0, 32, 32);
      const imgData = ctx.getImageData(0, 0, 32, 32).data;

      let maxScore = -1;
      let bestR = 30, bestG = 215, bestB = 96;
      let count = 0;

      for (let i = 0; i < imgData.length; i += 16) {
        const r = imgData[i];
        const g = imgData[i + 1];
        const b = imgData[i + 2];
        const a = imgData[i + 3];

        if (a < 128) continue;

        // Skip pure blacks or extreme brights
        const brightness = (r * 299 + g * 587 + b * 114) / 1000;
        if (brightness < 30 || brightness > 230) continue;

        const maxC = Math.max(r, g, b);
        const minC = Math.min(r, g, b);
        const saturation = maxC - minC;

        if (saturation > maxScore) {
          maxScore = saturation;
          bestR = r;
          bestG = g;
          bestB = b;
        }
        count++;
      }

      if (count === 0 || maxScore < 20) {
        return fallback;
      }

      // Base vibrant color
      const pR = Math.min(255, Math.max(25, bestR));
      const pG = Math.min(255, Math.max(25, bestG));
      const pB = Math.min(255, Math.max(25, bestB));

      // Deep dark complement for bottom of gradient
      const dR = Math.round(pR * 0.14);
      const dG = Math.round(pG * 0.14);
      const dB = Math.round(pB * 0.14);

      // Light accent for play badge and quote
      const aR = Math.min(255, Math.round(pR * 1.35 + 35));
      const aG = Math.min(255, Math.round(pG * 1.35 + 35));
      const aB = Math.min(255, Math.round(pB * 1.35 + 35));

      return {
        primary: `rgb(${pR}, ${pG}, ${pB})`,
        dark: `rgb(${dR}, ${dG}, ${dB})`,
        glow: `rgba(${pR}, ${pG}, ${pB}, 0.45)`,
        accent: `rgb(${aR}, ${aG}, ${aB})`,
        border: `rgba(${aR}, ${aG}, ${aB}, 0.35)`
      };
    } catch (_) {
      return fallback;
    }
  }

  // Parse raw LRC or text into clean array of lines
  function extractCleanLyricsLines(syncedText, plainText) {
    const raw = syncedText || plainText || '';
    if (!raw.trim()) return [];

    const lines = raw.split(/\r?\n/);
    const result = [];
    const timeRegex = /\[(\d{1,2}):(\d{2})(?:\.(\d+))?\]/g;

    for (let i = 0; i < lines.length; i++) {
      let l = lines[i].trim();
      if (!l) continue;

      let sec = null;
      const match = /\[(\d{1,2}):(\d{2})(?:\.(\d+))?\]/.exec(l);
      if (match) {
        const m = parseInt(match[1], 10) || 0;
        const s = parseInt(match[2], 10) || 0;
        const ms = match[3] ? parseInt(match[3].slice(0, 3), 10) : 0;
        sec = m * 60 + s + ms / 1000;
      }

      // Strip timestamps
      l = l.replace(timeRegex, '').trim();

      // Skip empty or purely metadata tags like [ti: ...], [ar: ...]
      if (!l || /^\[(ti|ar|al|by|offset|length):/i.test(l)) continue;

      // Filter out system, loading placeholder, or non-lyric instrumental markers (e.g. Interlude, Music, Intro)
      const cleanCheck = l.replace(/[\[\]\(\)\{\}\*\-\_\~]/g, '').trim().toLowerCase();
      if (!cleanCheck || /^(loading|no\s+synced|no\s+lyrics|lyrics\s+not\s+found|choose\s+a\s+song|interlude|music|instrumental|intro|outro|bridge|verse|chorus|hook|solo|beat|whistle|applause|cheering)$/i.test(cleanCheck)) continue;

      result.push({
        id: `lss_line_${result.length}`,
        text: l,
        sec: sec
      });
    }

    return result;
  }

  // ─── Modal DOM Injection ───
  function ensureModalsExist() {
    if ($('#lyricsShareSelectModal')) return;

    const html = `
    <!-- SELECT LYRICS MODAL -->
    <div class="lss-modal-overlay" id="lyricsShareSelectModal" aria-hidden="true" role="dialog" aria-label="Select Lyrics">
      <div class="lss-window">
        <!-- Header -->
        <div class="lss-header">
          <div class="lss-song-summary">
            <img class="lss-song-thumb" id="lssSelectSongThumb" src="" alt="Album Artwork" />
            <div class="lss-song-info">
              <h4 id="lssSelectSongTitle">Song Title</h4>
              <p id="lssSelectSongArtist">Artist Name</p>
            </div>
          </div>
          <div class="lss-header-actions">
            <button class="lss-close-btn" id="lssSelectCloseBtn" type="button" aria-label="Close">✕</button>
          </div>
        </div>

        <!-- Toolbar & Counter -->
        <div class="lss-toolbar">
          <div class="lss-counter-badge" id="lssCounterBadge">
            <span class="lss-counter-dot"></span>
            <span id="lssCounterText">0 of 8 lines selected</span>
          </div>
          <div class="lss-quick-actions">
            <button class="lss-text-btn" id="lssSelectAllBtn" type="button">Select 4</button>
            <button class="lss-text-btn" id="lssClearAllBtn" type="button">Clear</button>
          </div>
        </div>

        <!-- Limit Alert Banner -->
        <div class="lss-alert-banner" id="lssAlertBanner">
          <svg viewBox="0 0 24 24" width="16" height="16" fill="currentColor">
            <path d="M12 2L1 21h22L12 2zm0 3.99L19.53 19H4.47L12 5.99zM11 10h2v4h-2zm0 6h2v2h-2z"/>
          </svg>
          <span id="lssAlertMsg">Maximum 8 lines can be shared on a card to keep it clear and readable.</span>
        </div>

        <!-- Scrollable Lyric Line Cards -->
        <div class="lss-body" id="lssLyricsListContainer">
          <!-- Populated dynamically -->
        </div>

        <!-- Footer Action -->
        <div class="lss-footer">
          <span class="lss-footer-hint" id="lssFooterHint">Tap lines to select your favourite snippet</span>
          <button class="lss-primary-btn" id="lssContinueBtn" type="button" disabled>
            <span>Continue</span>
            <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
              <polyline points="9 18 15 12 9 6"></polyline>
            </svg>
          </button>
        </div>
      </div>
    </div>

    <!-- PREVIEW & SHARING MODAL -->
    <div class="lss-modal-overlay" id="lyricsSharePreviewModal" aria-hidden="true" role="dialog" aria-label="Share Lyrics Card">
      <div class="lss-window" style="max-width: 620px;">
        <!-- Header -->
        <div class="lss-header">
          <div style="display:flex;align-items:center;gap:10px;">
            <button class="lss-close-btn" id="lssPreviewBackBtn" type="button" aria-label="Back to selection" title="Back to selection">←</button>
            <div class="lss-song-info">
              <h4 id="lssPreviewHeaderTitle">Share Lyrics Card</h4>
              <p id="lssPreviewHeaderSub">KRISH MUSIC Studio</p>
            </div>
          </div>
          <div class="lss-header-actions">
            <button class="lss-close-btn" id="lssPreviewCloseBtn" type="button" aria-label="Close">✕</button>
          </div>
        </div>

        <!-- Preview Stage -->
        <div class="lss-preview-stage">
          <!-- Top Toolbar: Aspect Ratio -->
          <div style="display:flex;align-items:center;justify-content:center;width:100%;max-width:360px;margin-bottom:4px;">
            <div class="lss-aspect-switcher">
              <button class="lss-aspect-btn active" data-ratio="9:16" type="button" title="Story 9:16">Story 9:16</button>
              <button class="lss-aspect-btn" data-ratio="1:1" type="button" title="Square 1:1">Square 1:1</button>
              <button class="lss-aspect-btn" data-ratio="4:5" type="button" title="Post 4:5">Post 4:5</button>
            </div>
          </div>

          <!-- Card Wrapper -->
          <div class="lss-card-wrapper">
            <!-- Share Visual Card with Dynamic Song Palette -->
            <div class="lss-share-card ratio-9-16" id="lssVisualCard">
              <!-- Card Top -->
              <div class="lss-card-top">
                <div class="lss-brand-badge" id="lssCardBrandBadge">
                  <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/></svg>
                  <span>KRISH MUSIC</span>
                </div>
                <div class="lss-card-quote-icon" id="lssCardQuote">“</div>
              </div>

              <!-- Card Center: Lyrics Mode -->
              <div class="lss-card-center" id="lssCardLyricsCenter">
                <div class="lss-card-lyrics-lines" id="lssCardLyricsLines">
                  <!-- Injected lines -->
                </div>
              </div>

              <!-- Card Center: Song Mode -->
              <div class="lss-card-song-center" id="lssCardSongCenter" style="display:none;">
                <img class="lss-big-artwork" id="lssBigArtwork" src="" alt="Album Artwork" />
                <div class="lss-big-song-meta">
                  <h3 id="lssBigSongTitle">Song Title</h3>
                  <p id="lssBigSongArtist">Artist Name</p>
                </div>
              </div>

              <!-- Card Bottom -->
              <div class="lss-card-bottom" id="lssCardBottom">
                <div class="lss-card-meta">
                  <img class="lss-card-art-thumb" id="lssCardArtThumb" src="" alt="Artwork" />
                  <div class="lss-card-meta-text">
                    <p class="lss-card-meta-title" id="lssCardMetaTitle">Song Title</p>
                    <p class="lss-card-meta-artist" id="lssCardMetaArtist">Artist Name</p>
                  </div>
                </div>
                <div class="lss-card-wave" aria-hidden="true">
                  <i></i><i></i><i></i><i></i><i></i>
                </div>
              </div>
            </div>

            <!-- Render Spinner Overlay -->
            <div class="lss-render-spinner" id="lssRenderSpinner">
              <div class="lss-spinner-ring"></div>
              <span>Crafting high-res card…</span>
            </div>
          </div>
        </div>

        <!-- Footer with Download & Share Button -->
        <div class="lss-footer" style="justify-content:center;">
          <div style="display:flex;gap:12px;width:100%;max-width:360px;">
            <button class="lss-secondary-btn" id="lssQuickDownloadBtn" type="button" style="flex:1;justify-content:center;gap:8px;" title="Download Image">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"></path>
                <polyline points="7 10 12 15 17 10"></polyline>
                <line x1="12" y1="15" x2="12" y2="3"></line>
              </svg>
              <span>Download</span>
            </button>
            <button class="lss-primary-btn" id="lssOpenShareSheetBtn" type="button" style="flex:1.4;justify-content:center;">
              <svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="18" cy="5" r="3"></circle>
                <circle cx="6" cy="12" r="3"></circle>
                <circle cx="18" cy="19" r="3"></circle>
                <line x1="8.59" y1="13.51" x2="15.42" y2="17.49"></line>
                <line x1="15.41" y1="6.51" x2="8.59" y2="10.49"></line>
              </svg>
              <span>Share Card</span>
            </button>
          </div>
        </div>

        <!-- SOCIAL SHARING SHEET -->
        <div class="lss-share-sheet" id="lssShareSheet">
          <div class="lss-sheet-header">
            <h4>Share With Friends</h4>
            <button class="lss-close-btn" id="lssCloseShareSheetBtn" type="button" style="width:28px;height:28px;font-size:12px;">✕</button>
          </div>

          <div class="lss-social-grid">
            <button class="lss-social-btn" data-share="instagram-stories" type="button">
              <div class="lss-social-icon instagram">📸</div>
              <span>Instagram</span>
            </button>
            <button class="lss-social-btn" data-share="whatsapp" type="button">
              <div class="lss-social-icon whatsapp">💬</div>
              <span>WhatsApp</span>
            </button>
            <button class="lss-social-btn" data-share="snapchat" type="button">
              <div class="lss-social-icon snapchat">👻</div>
              <span>Snapchat</span>
            </button>
            <button class="lss-social-btn" data-share="telegram" type="button">
              <div class="lss-social-icon telegram">✈️</div>
              <span>Telegram</span>
            </button>
            <button class="lss-social-btn" data-share="facebook" type="button">
              <div class="lss-social-icon facebook">📘</div>
              <span>Facebook</span>
            </button>
            <button class="lss-social-btn" data-share="sms" type="button">
              <div class="lss-social-icon sms">✉️</div>
              <span>Messages</span>
            </button>
            <button class="lss-social-btn" data-share="download" type="button">
              <div class="lss-social-icon download">📥</div>
              <span>Download</span>
            </button>
            <button class="lss-social-btn" data-share="copy-link" type="button">
              <div class="lss-social-icon copy">🔗</div>
              <span>Copy Link</span>
            </button>
          </div>

          <button class="lss-primary-btn" id="lssNativeShareAllBtn" type="button" style="width:100%;justify-content:center;margin-top:4px;">
            <span>More Apps (Share Sheet)</span>
          </button>
        </div>
      </div>
    </div>
    `;

    const div = document.createElement('div');
    div.id = 'krishLyricsShareRoot';
    div.innerHTML = html;
    document.body.appendChild(div);

    attachEventListeners();
  }

  // ─── Attach Event Listeners ───
  function attachEventListeners() {
    const selectModal = $('#lyricsShareSelectModal');
    const previewModal = $('#lyricsSharePreviewModal');
    const shareSheet = $('#lssShareSheet');

    // Close select modal
    $('#lssSelectCloseBtn')?.addEventListener('click', closeSelectModal);
    selectModal?.addEventListener('click', (e) => {
      if (e.target === selectModal) closeSelectModal();
    });

    // Close preview modal
    $('#lssPreviewCloseBtn')?.addEventListener('click', closePreviewModal);
    previewModal?.addEventListener('click', (e) => {
      if (e.target === previewModal) closePreviewModal();
    });

    // Back to Select Lyrics
    $('#lssPreviewBackBtn')?.addEventListener('click', () => {
      closePreviewModal();
      openSelectModal();
    });

    // Quick Actions: Select 4 lines & Clear
    $('#lssSelectAllBtn')?.addEventListener('click', () => {
      state.selectedLineIds.clear();
      const count = Math.min(state.lyricsLines.length, 4);
      for (let i = 0; i < count; i++) {
        state.selectedLineIds.add(state.lyricsLines[i].id);
      }
      hideAlertBanner();
      renderLyricsList();
      updateSelectModalUI();
      getHapticFn()(10);
    });

    $('#lssClearAllBtn')?.addEventListener('click', () => {
      state.selectedLineIds.clear();
      hideAlertBanner();
      renderLyricsList();
      updateSelectModalUI();
      getHapticFn()(10);
    });

    // Continue to preview
    $('#lssContinueBtn')?.addEventListener('click', () => {
      if (!state.selectedLineIds.size) return;
      closeSelectModal();
      openPreviewModal();
      getHapticFn()(15);
    });


    // Aspect ratio buttons
    $$('.lss-aspect-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const ratio = btn.dataset.ratio;
        setAspectRatio(ratio);
      });
    });

    // Share sheet toggles
    $('#lssOpenShareSheetBtn')?.addEventListener('click', () => {
      shareSheet?.classList.toggle('open');
    });
    $('#lssCloseShareSheetBtn')?.addEventListener('click', () => {
      shareSheet?.classList.remove('open');
    });

    // Quick download
    $('#lssQuickDownloadBtn')?.addEventListener('click', () => {
      handleShareAction('download');
    });

    // Native Share All
    $('#lssNativeShareAllBtn')?.addEventListener('click', () => {
      handleShareAction('native');
    });

    // Social buttons
    $$('.lss-social-btn').forEach((btn) => {
      btn.addEventListener('click', () => {
        const target = btn.dataset.share;
        handleShareAction(target);
      });
    });

    // Keyboard ESC
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        if (shareSheet?.classList.contains('open')) {
          shareSheet.classList.remove('open');
          return;
        }
        if (previewModal?.classList.contains('active')) {
          closePreviewModal();
          return;
        }
        if (selectModal?.classList.contains('active')) {
          closeSelectModal();
        }
      }
    });
  }

  // ─── Main Public Open Function ───
  async function openLyricsShareModal(songOverride) {
    ensureModalsExist();

    const activeSong = resolveActiveSong(songOverride);
    if (!activeSong) {
      getToastFn()('Please play a song first to share lyrics.');
      return;
    }

    state.song = activeSong;
    state.lyricsLines = [];
    state.selectedLineIds.clear();
    state.cardPalette = null;

    // Show Select Lyrics modal immediately with loading indicator
    openSelectModal(true);
    preloadArtwork(getSongArtworkUrl(activeSong));

    // 1. Check if real lyrics exist in memory
    let synced = '';
    let plain = '';

    if (typeof window.getLyricsData === 'function') {
      try {
        const d = window.getLyricsData();
        synced = typeof d?.synced === 'string' ? d.synced.trim() : '';
        plain = typeof d?.original === 'string' ? d.original.trim() : '';
      } catch (_) {}
    }
    if (!synced && typeof window.lyricsSyncedText === 'string') synced = window.lyricsSyncedText.trim();
    if (!plain && typeof window.lyricsOriginalText === 'string') plain = window.lyricsOriginalText.trim();

    // Invalidate placeholder strings
    if (/^(loading|choose\s+a\s+song|no\s+lyrics)/i.test(plain)) {
      plain = '';
    }

    // 2. Fetch directly from /backend.php
    if (!synced && !plain) {
      try {
        const songId = encodeURIComponent(activeSong.id || activeSong.rawId || '');
        const songTitle = encodeURIComponent(activeSong.title || '');
        const songArtist = encodeURIComponent(parseSongArtists(activeSong));
        const songDur = Math.round(Number(activeSong.duration || window.audio?.duration || 0));

        const apiUrl = `/backend.php?action=lyrics&id=${songId}&title=${songTitle}&artist=${songArtist}&duration=${songDur}&_=${Date.now()}`;
        const res = await fetch(apiUrl, { cache: 'no-store' });
        if (res.ok) {
          const data = await res.json();
          if (data && data.available) {
            synced = typeof data.synced_lyrics === 'string' ? data.synced_lyrics.trim() : '';
            plain = typeof data.lyrics === 'string' ? data.lyrics.trim() : '';
            try {
              if (synced) window.lyricsSyncedText = synced;
              if (plain) window.lyricsOriginalText = plain;
            } catch (_) {}
          }
        }
      } catch (err) {
        console.warn('[LyricsShare] Fetch lyrics error:', err);
      }
    }

    // 3. Fallback: try window.loadLyrics if still empty
    if (!synced && !plain && typeof window.loadLyrics === 'function') {
      try {
        await window.loadLyrics(false);
        if (typeof window.getLyricsData === 'function') {
          const d = window.getLyricsData();
          synced = typeof d?.synced === 'string' ? d.synced.trim() : '';
          plain = typeof d?.original === 'string' ? d.original.trim() : '';
        }
        if (!synced && typeof window.lyricsSyncedText === 'string') synced = window.lyricsSyncedText.trim();
        if (!plain && typeof window.lyricsOriginalText === 'string') plain = window.lyricsOriginalText.trim();
      } catch (_) {}
    }

    // Extract clean lines
    state.lyricsLines = extractCleanLyricsLines(synced, plain);

    // Default select active or first lines
    if (state.lyricsLines.length) {
      const currentTime = window.audio?.currentTime || 0;
      let matchIdx = -1;
      for (let i = 0; i < state.lyricsLines.length; i++) {
        const item = state.lyricsLines[i];
        if (item.sec !== null && item.sec <= currentTime) {
          matchIdx = i;
        }
      }

      if (matchIdx !== -1) {
        state.selectedLineIds.add(state.lyricsLines[matchIdx].id);
        if (matchIdx + 1 < state.lyricsLines.length && state.selectedLineIds.size < state.maxSelection) {
          state.selectedLineIds.add(state.lyricsLines[matchIdx + 1].id);
        }
      } else {
        const initialCount = Math.min(2, state.lyricsLines.length);
        for (let i = 0; i < initialCount; i++) {
          state.selectedLineIds.add(state.lyricsLines[i].id);
        }
      }
    }

    // Render populated list
    renderLyricsList();
    updateSelectModalUI();
  }

  function preloadArtwork(url) {
    if (!url) {
      state.loadedImage = null;
      state.loadedImageUrl = '';
      state.cardPalette = getFallbackSongPalette(state.song);
      applySongPalette();
      return;
    }
    if (state.loadedImageUrl === url && state.loadedImage) {
      state.cardPalette = extractSongPalette(state.loadedImage, state.song);
      applySongPalette();
      return;
    }

    const img = new Image();
    img.crossOrigin = 'anonymous';
    img.onload = () => {
      state.loadedImage = img;
      state.loadedImageUrl = url;
      state.cardPalette = extractSongPalette(img, state.song);
      applySongPalette();
    };
    img.onerror = () => {
      state.loadedImage = null;
      state.cardPalette = getFallbackSongPalette(state.song);
      applySongPalette();
    };
    img.src = url;
  }

  // ─── Select Lyrics Screen ───
  function openSelectModal(isLoading = false) {
    const modal = $('#lyricsShareSelectModal');
    if (!modal) return;

    const song = state.song;
    const thumb = $('#lssSelectSongThumb');
    const title = $('#lssSelectSongTitle');
    const artist = $('#lssSelectSongArtist');

    if (thumb) thumb.src = getSongArtworkUrl(song) || 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg"/>';
    if (title) title.textContent = song.title || 'Unknown Title';
    if (artist) artist.textContent = parseSongArtists(song);

    hideAlertBanner();

    if (isLoading) {
      const container = $('#lssLyricsListContainer');
      if (container) {
        container.innerHTML = `
          <div class="lss-empty-state" style="padding:48px 16px;">
            <div class="lss-spinner-ring" style="width:36px;height:36px;margin-bottom:12px;"></div>
            <h5>Finding lyrics…</h5>
            <p>Searching synchronized lyrics for <b>${escapeHtml(song.title || 'song')}</b></p>
          </div>
        `;
      }
      const continueBtn = $('#lssContinueBtn');
      if (continueBtn) continueBtn.disabled = true;
      const counterText = $('#lssCounterText');
      if (counterText) counterText.textContent = `Finding lyrics…`;
    } else {
      renderLyricsList();
      updateSelectModalUI();
    }

    modal.classList.add('active');
    modal.setAttribute('aria-hidden', 'false');
  }

  function closeSelectModal() {
    const modal = $('#lyricsShareSelectModal');
    if (!modal) return;
    modal.classList.remove('active');
    modal.setAttribute('aria-hidden', 'true');
    hideAlertBanner();
  }

  function renderLyricsList() {
    const container = $('#lssLyricsListContainer');
    if (!container) return;
    container.innerHTML = '';

    if (!state.lyricsLines.length) {
      container.innerHTML = `
        <div class="lss-empty-state">
          <svg viewBox="0 0 24 24" width="48" height="48" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="opacity:0.4;">
            <path d="M9 18V5l12-2v13"></path>
            <circle cx="6" cy="18" r="3"></circle>
            <circle cx="18" cy="16" r="3"></circle>
          </svg>
          <h5>No lyrics found for this song</h5>
          <p>Synced lyrics are not available for this track yet.</p>
          <button class="lss-ghost-btn" id="lssEmptyCloseBtn" type="button" style="margin-top:12px;padding:8px 20px;">
            Close
          </button>
        </div>
      `;

      $('#lssEmptyCloseBtn')?.addEventListener('click', () => {
        closeSelectModal();
      });
      return;
    }

    state.lyricsLines.forEach((item) => {
      const isSelected = state.selectedLineIds.has(item.id);
      const card = document.createElement('div');
      card.className = `lss-lyric-card ${isSelected ? 'selected' : ''}`;
      card.dataset.lineId = item.id;
      card.innerHTML = `
        <div class="lss-lyric-text">${escapeHtml(item.text)}</div>
        <div class="lss-lyric-check" aria-hidden="true">${isSelected ? '✓' : ''}</div>
      `;

      card.addEventListener('click', () => toggleLyricLine(item.id, card));
      container.appendChild(card);
    });
  }

  function toggleLyricLine(lineId, cardElement) {
    if (state.selectedLineIds.has(lineId)) {
      // Deselect
      state.selectedLineIds.delete(lineId);
      cardElement.classList.remove('selected');
      const check = cardElement.querySelector('.lss-lyric-check');
      if (check) check.textContent = '';
      hideAlertBanner();
      getHapticFn()(8);
    } else {
      // Check maximum limit
      if (state.selectedLineIds.size >= state.maxSelection) {
        showAlertBanner(`Maximum ${state.maxSelection} lines can be shared on a card to keep it clear and readable.`);
        getHapticFn()(30);
        return;
      }
      state.selectedLineIds.add(lineId);
      cardElement.classList.add('selected');
      const check = cardElement.querySelector('.lss-lyric-check');
      if (check) check.textContent = '✓';
      hideAlertBanner();
      getHapticFn()(12);
    }

    updateSelectModalUI();
  }

  function showAlertBanner(msg) {
    const banner = $('#lssAlertBanner');
    const msgEl = $('#lssAlertMsg');
    if (!banner || !msgEl) return;
    msgEl.textContent = msg;
    banner.classList.remove('visible');
    void banner.offsetWidth; // Trigger reflow for animation
    banner.classList.add('visible');
  }

  function hideAlertBanner() {
    const banner = $('#lssAlertBanner');
    if (banner) banner.classList.remove('visible');
  }

  function updateSelectModalUI() {
    const count = state.selectedLineIds.size;
    const badge = $('#lssCounterBadge');
    const counterText = $('#lssCounterText');
    const continueBtn = $('#lssContinueBtn');

    if (counterText) {
      counterText.textContent = `${count} of ${state.maxSelection} lines selected`;
    }

    if (badge) {
      badge.classList.toggle('active', count > 0);
      badge.classList.toggle('limit-reached', count >= state.maxSelection);
    }

    if (continueBtn) {
      continueBtn.disabled = count === 0;
    }
  }

  // ─── Preview Screen ───
  function openPreviewModal() {
    const modal = $('#lyricsSharePreviewModal');
    if (!modal) return;

    state.activeTab = 'lyrics';
    switchPreviewTab('lyrics');
    applySongPalette();
    syncCardContent();

    modal.classList.add('active');
    modal.setAttribute('aria-hidden', 'false');
  }

  function closePreviewModal() {
    const modal = $('#lyricsSharePreviewModal');
    if (!modal) return;
    modal.classList.remove('active');
    modal.setAttribute('aria-hidden', 'true');
    $('#lssShareSheet')?.classList.remove('open');
  }

  function switchPreviewTab(tab) {
    state.activeTab = tab;
    $('#lssTabLyrics')?.classList.toggle('active', tab === 'lyrics');
    $('#lssTabSong')?.classList.toggle('active', tab === 'song');

    const lyricsCenter = $('#lssCardLyricsCenter');
    const songCenter = $('#lssCardSongCenter');
    const cardQuote = $('#lssCardQuote');
    const cardBottom = $('#lssCardBottom');

    if (tab === 'lyrics') {
      if (lyricsCenter) lyricsCenter.style.display = 'flex';
      if (songCenter) songCenter.style.display = 'none';
      if (cardQuote) cardQuote.style.display = 'block';
      if (cardBottom) cardBottom.style.display = 'flex';
    } else {
      if (lyricsCenter) lyricsCenter.style.display = 'none';
      if (songCenter) songCenter.style.display = 'flex';
      if (cardQuote) cardQuote.style.display = 'none';
      if (cardBottom) cardBottom.style.display = 'none';
    }

    getHapticFn()(10);
  }

  function setAspectRatio(ratio) {
    if (!['9:16', '1:1', '4:5'].includes(ratio)) ratio = '9:16';
    state.aspectRatio = ratio;

    $$('.lss-aspect-btn').forEach((b) => b.classList.toggle('active', b.dataset.ratio === ratio));

    const card = $('#lssVisualCard');
    if (card) {
      card.classList.remove('ratio-9-16', 'ratio-1-1', 'ratio-4-5');
      card.classList.add(`ratio-${ratio.replace(':', '-')}`);
    }

    getHapticFn()(8);
  }

  function syncCardContent() {
    const song = state.song;
    if (!song) return;

    const artUrl = getSongArtworkUrl(song);
    const titleText = song.title || 'Unknown Title';
    const artistText = parseSongArtists(song);

    // Bottom Meta
    const metaArt = $('#lssCardArtThumb');
    const metaTitle = $('#lssCardMetaTitle');
    const metaArtist = $('#lssCardMetaArtist');
    if (metaArt) metaArt.src = artUrl;
    if (metaTitle) metaTitle.textContent = titleText;
    if (metaArtist) metaArtist.textContent = artistText;

    // Song Tab Big Center
    const bigArt = $('#lssBigArtwork');
    const bigTitle = $('#lssBigSongTitle');
    const bigArtist = $('#lssBigSongArtist');
    if (bigArt) bigArt.src = artUrl;
    if (bigTitle) bigTitle.textContent = titleText;
    if (bigArtist) bigArtist.textContent = artistText;

    // Selected Lyrics Lines (Preserve original song order)
    const linesWrap = $('#lssCardLyricsLines');
    if (linesWrap) {
      linesWrap.innerHTML = '';
      const selectedList = state.lyricsLines.filter((l) => state.selectedLineIds.has(l.id));
      const count = selectedList.length;

      let fontSize = 21;
      let lineHeight = 1.48;
      let gap = 10;
      if (count > 6) {
        fontSize = 15;
        lineHeight = 1.35;
        gap = 5;
      } else if (count > 4) {
        fontSize = 17;
        lineHeight = 1.4;
        gap = 7;
      } else if (count > 2) {
        fontSize = 19;
        lineHeight = 1.44;
        gap = 8;
      }
      linesWrap.style.gap = gap + 'px';

      if (selectedList.length) {
        selectedList.forEach((line) => {
          const p = document.createElement('div');
          p.className = 'lss-card-line';
          p.style.fontSize = fontSize + 'px';
          p.style.lineHeight = String(lineHeight);
          p.textContent = line.text;
          linesWrap.appendChild(p);
        });
      } else {
        const p = document.createElement('div');
        p.className = 'lss-card-line';
        p.style.opacity = '0.7';
        p.textContent = `♪ Listening to ${titleText} on KRISH MUSIC`;
        linesWrap.appendChild(p);
      }
    }
  }

  // ─── Dynamic Song Color Application ───
  function applySongPalette() {
    const palette = state.cardPalette || extractSongPalette(state.loadedImage, state.song);
    state.cardPalette = palette;

    const card = $('#lssVisualCard');
    if (!card) return;

    // Apply Spotify-style dynamic gradient matching the song
    card.style.background = `radial-gradient(circle at 82% 16%, ${palette.glow} 0%, transparent 68%), linear-gradient(180deg, ${palette.primary} 0%, ${palette.dark} 100%)`;
    card.style.borderColor = palette.border;
    card.style.boxShadow = `0 28px 70px rgba(0, 0, 0, 0.75), 0 0 45px ${palette.glow}`;

    const quote = $('#lssCardQuote');
    if (quote) quote.style.color = palette.accent;

    const brandDot = $('#lssCardBrandBadge svg');
    if (brandDot) brandDot.style.fill = palette.accent;

    const waveBars = $$('.lss-card-wave i', card);
    waveBars.forEach((bar) => {
      bar.style.background = palette.accent;
    });
  }

  // ─── High-Resolution HTML5 Canvas Generator ───
  async function generateCardImageBlob() {
    const song = state.song;
    const ratio = state.aspectRatio;

    let width = 1080;
    let height = 1920; // 9:16 default
    if (ratio === '1:1') {
      height = 1080;
    } else if (ratio === '4:5') {
      height = 1350;
    }

    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const ctx = canvas.getContext('2d');

    const palette = state.cardPalette || extractSongPalette(state.loadedImage, song);

    // 1. Draw Song-wise Dynamic Gradient Background
    const grad = ctx.createLinearGradient(0, 0, 0, height);
    grad.addColorStop(0, palette.primary);
    grad.addColorStop(1, palette.dark);
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, width, height);

    // Ambient radial glow matching the song artwork
    const radGlow = ctx.createRadialGradient(width * 0.8, height * 0.16, 40, width * 0.8, height * 0.16, width * 0.75);
    radGlow.addColorStop(0, palette.glow);
    radGlow.addColorStop(1, 'transparent');
    ctx.fillStyle = radGlow;
    ctx.fillRect(0, 0, width, height);

    // Border
    ctx.lineWidth = 10;
    ctx.strokeStyle = palette.border;
    roundRect(ctx, 20, 20, width - 40, height - 40, 48);
    ctx.stroke();

    // 2. Header: KRISH MUSIC Branding & Quote
    const padX = 84;
    const topY = 120;

    // Pill badge
    const badgeW = 260;
    const badgeH = 58;
    ctx.fillStyle = 'rgba(0, 0, 0, 0.45)';
    roundRect(ctx, padX, topY, badgeW, badgeH, 29);
    ctx.fill();
    ctx.lineWidth = 2;
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.18)';
    ctx.stroke();

    // Play Dot with Song Accent
    ctx.fillStyle = palette.accent;
    ctx.beginPath();
    ctx.arc(padX + 32, topY + badgeH / 2, 9, 0, Math.PI * 2);
    ctx.fill();

    // Brand Text
    ctx.fillStyle = '#ffffff';
    ctx.font = '900 24px system-ui, -apple-system, sans-serif';
    ctx.textBaseline = 'middle';
    ctx.textAlign = 'left';
    ctx.fillText('KRISH MUSIC', padX + 54, topY + badgeH / 2 + 1);

    // Quote mark in lyrics mode
    if (state.activeTab === 'lyrics') {
      ctx.fillStyle = palette.accent;
      ctx.font = '900 80px Georgia, serif';
      ctx.textAlign = 'right';
      ctx.textBaseline = 'top';
      ctx.fillText('“', width - padX, topY - 14);
    }

    // 4. Footer for Lyrics Card: Coordinates
    const botY = height - 190;
    const sepY = botY - 32;

    // 3. Center Content: Safe lyrics area (guaranteed 36px clearance above separator)
    const contentTop = topY + 130;
    const contentBottom = sepY - 36;
    const contentH = Math.max(120, contentBottom - contentTop);

    if (state.activeTab === 'lyrics') {
      const selectedList = state.lyricsLines.filter((l) => state.selectedLineIds.has(l.id));
      const lines = selectedList.length ? selectedList.map((l) => l.text) : [`Listening to ${song.title || 'Music'}`];

      // Dynamic responsive font size based on lines count and content height
      let sizePx = 54;
      if (lines.length > 6) sizePx = 36;
      else if (lines.length > 4) sizePx = 42;
      else if (lines.length > 2) sizePx = 48;

      const maxLineWidth = width - padX * 2;
      let wrappedLines = [];
      let lineSpacing = sizePx * 1.45;
      let totalTextH = 0;

      // Iterative fit: decrease size until all lines fit within contentH
      while (sizePx >= 20) {
        ctx.font = `800 ${sizePx}px system-ui, -apple-system, sans-serif`;
        wrappedLines = [];
        lines.forEach((line) => {
          const words = line.split(' ');
          let cur = '';
          words.forEach((w) => {
            const test = cur ? cur + ' ' + w : w;
            if (ctx.measureText(test).width <= maxLineWidth) {
              cur = test;
            } else {
              if (cur) wrappedLines.push(cur);
              cur = w;
            }
          });
          if (cur) wrappedLines.push(cur);
        });
        lineSpacing = sizePx * 1.42;
        totalTextH = wrappedLines.length * lineSpacing;
        if (totalTextH <= contentH - 20) {
          break;
        }
        sizePx -= 2;
      }

      ctx.fillStyle = '#ffffff';
      ctx.textBaseline = 'middle';

      // Drop shadow for crystal clear legibility
      ctx.shadowColor = 'rgba(0, 0, 0, 0.55)';
      ctx.shadowBlur = 18;
      ctx.shadowOffsetX = 0;
      ctx.shadowOffsetY = 4;

      let startY = contentTop + Math.max(0, (contentH - totalTextH) / 2) + sizePx / 2;

      // Safe clipping: guarantee text NEVER touches or bleeds into the footer
      ctx.save();
      ctx.beginPath();
      ctx.rect(padX - 10, contentTop - 10, width - padX * 2 + 20, contentH + 10);
      ctx.clip();

      wrappedLines.forEach((wLine) => {
        ctx.textAlign = 'left';
        ctx.fillText(wLine, padX, startY);
        startY += lineSpacing;
      });

      ctx.restore();
      ctx.shadowBlur = 0;

      // Divider line
      ctx.lineWidth = 2;
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.12)';
      ctx.beginPath();
      ctx.moveTo(padX, sepY);
      ctx.lineTo(width - padX, sepY);
      ctx.stroke();

      let metaStartX = padX;
      const thumbSize = 88;
      if (state.loadedImage) {
        ctx.save();
        roundRect(ctx, metaStartX, botY, thumbSize, thumbSize, 20);
        ctx.clip();
        ctx.drawImage(state.loadedImage, metaStartX, botY, thumbSize, thumbSize);
        ctx.restore();
      } else {
        ctx.fillStyle = '#222';
        roundRect(ctx, metaStartX, botY, thumbSize, thumbSize, 20);
        ctx.fill();
      }
      metaStartX += thumbSize + 24;

      // Title & Artist in Footer
      ctx.textAlign = 'left';
      ctx.textBaseline = 'top';
      ctx.fillStyle = '#ffffff';
      ctx.font = '800 32px system-ui, sans-serif';
      const footerTitle = truncateText(ctx, song.title || 'Unknown Title', width - metaStartX - 220);
      ctx.fillText(footerTitle, metaStartX, botY + 8);

      ctx.fillStyle = 'rgba(255, 255, 255, 0.72)';
      ctx.font = '600 24px system-ui, sans-serif';
      const footerArtist = truncateText(ctx, parseSongArtists(song), width - metaStartX - 220);
      ctx.fillText(footerArtist, metaStartX, botY + 48);

      // Waveform audio bars right side
      const waveX = width - padX - 90;
      const waveY = botY + 24;
      const barHeights = [18, 38, 28, 44, 22];
      ctx.fillStyle = palette.accent;
      barHeights.forEach((h, i) => {
        roundRect(ctx, waveX + i * 16, waveY + (44 - h) / 2, 8, h, 4);
        ctx.fill();
      });
    } else {
      // Song Tab Center: Large artwork, Title, Artist
      const artSize = Math.min(width * 0.48, 440);
      const artX = (width - artSize) / 2;
      const artY = contentTop + (contentH - (artSize + 170)) / 2;

      // Draw Big Artwork
      if (state.loadedImage) {
        ctx.save();
        roundRect(ctx, artX, artY, artSize, artSize, 40);
        ctx.clip();
        ctx.drawImage(state.loadedImage, artX, artY, artSize, artSize);
        ctx.restore();
      } else {
        ctx.fillStyle = '#222';
        roundRect(ctx, artX, artY, artSize, artSize, 40);
        ctx.fill();
      }

      // Border around artwork
      ctx.lineWidth = 4;
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.22)';
      roundRect(ctx, artX, artY, artSize, artSize, 40);
      ctx.stroke();

      // Big Title & Artist
      ctx.fillStyle = '#ffffff';
      ctx.font = '900 52px system-ui, -apple-system, sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'top';
      const truncatedTitle = truncateText(ctx, song.title || 'Unknown Title', width - padX * 2);
      ctx.fillText(truncatedTitle, width / 2, artY + artSize + 36);

      ctx.fillStyle = 'rgba(255, 255, 255, 0.75)';
      ctx.font = '600 34px system-ui, -apple-system, sans-serif';
      const truncatedArtist = truncateText(ctx, parseSongArtists(song), width - padX * 2);
      ctx.fillText(truncatedArtist, width / 2, artY + artSize + 104);

      // Centered Equalizer Waveform in Footer
      const waveX = (width - 100) / 2;
      const waveY = height - 160;
      const barHeights = [18, 38, 28, 44, 22];
      ctx.fillStyle = palette.accent;
      barHeights.forEach((h, i) => {
        roundRect(ctx, waveX + i * 18, waveY + (44 - h) / 2, 8, h, 4);
        ctx.fill();
      });
    }

    return new Promise((resolve) => {
      canvas.toBlob((blob) => resolve(blob), 'image/png', 0.95);
    });
  }

  function roundRect(ctx, x, y, width, height, radius) {
    if (typeof radius === 'number') {
      radius = { tl: radius, tr: radius, br: radius, bl: radius };
    }
    ctx.beginPath();
    ctx.moveTo(x + radius.tl, y);
    ctx.lineTo(x + width - radius.tr, y);
    ctx.quadraticCurveTo(x + width, y, x + width, y + radius.tr);
    ctx.lineTo(x + width, y + height - radius.br);
    ctx.quadraticCurveTo(x + width, y + height, x + width - radius.br, y + height);
    ctx.lineTo(x + radius.bl, y + height);
    ctx.quadraticCurveTo(x, y + height, x, y + height - radius.bl);
    ctx.lineTo(x, y + radius.tl);
    ctx.quadraticCurveTo(x, y, x + radius.tl, y);
    ctx.closePath();
  }

  function truncateText(ctx, text, maxW) {
    if (ctx.measureText(text).width <= maxW) return text;
    let t = text;
    while (t.length > 3 && ctx.measureText(t + '…').width > maxW) {
      t = t.slice(0, -1);
    }
    return t + '…';
  }

  // ─── Social Sharing Actions ───
  async function handleShareAction(actionType) {
    const song = state.song;
    if (!song) return;

    const spinner = $('#lssRenderSpinner');
    const toast = getToastFn();
    const songUrl = getSongDeepLink(song);

    // Get selected lyrics text snippet for social descriptions
    const selectedList = state.lyricsLines.filter((l) => state.selectedLineIds.has(l.id));
    const lyricsSnippet = selectedList.map((l) => l.text).join('\n') || `Listening to ${song.title} on KRISH MUSIC`;
    const shareText = `"${lyricsSnippet}"\n\n🎵 ${song.title} - ${parseSongArtists(song)}\nListen on KRISH MUSIC: ${songUrl}`;

    try {
      if (spinner) spinner.classList.add('active');

      const blob = await generateCardImageBlob();
      const fileName = `krish_music_${(song.title || 'song').replace(/[^a-zA-Z0-9]/g, '_').toLowerCase()}_card.png`;
      const file = new File([blob], fileName, { type: 'image/png' });

      if (spinner) spinner.classList.remove('active');

      if (actionType === 'copy-link') {
        if (navigator.clipboard?.writeText) {
          await navigator.clipboard.writeText(songUrl);
          toast('Song link copied to clipboard! 🔗');
        } else {
          toast(`Link: ${songUrl}`);
        }
        return;
      }

      if (actionType === 'download') {
        downloadBlob(blob, fileName);
        toast('Lyrics Card downloaded in high-res! 📥');
        return;
      }

      // Web Share API with File
      const canShareFile = navigator.canShare && navigator.canShare({ files: [file] });

      if (actionType === 'native') {
        if (canShareFile) {
          try {
            await navigator.share({
              files: [file],
              title: song.title,
              text: shareText,
              url: songUrl
            });
            toast('Shared successfully! 🎉');
            return;
          } catch (e) {
            if (e.name !== 'AbortError') {
              downloadBlob(blob, fileName);
              toast('Share aborted — card saved to downloads');
            }
            return;
          }
        } else if (navigator.share) {
          try {
            await navigator.share({
              title: song.title,
              text: shareText,
              url: songUrl
            });
            return;
          } catch (_) {}
        }
        // Fallback: download
        downloadBlob(blob, fileName);
        toast('Downloaded image card! Open your favorite app to share.');
        return;
      }

      // App-Specific Integrations
      if (actionType === 'whatsapp') {
        if (canShareFile && /Android|iPhone|iPad/i.test(navigator.userAgent)) {
          try {
            await navigator.share({ files: [file], text: shareText, title: song.title });
            return;
          } catch (_) {}
        }
        downloadBlob(blob, fileName);
        const waUrl = `whatsapp://send?text=${encodeURIComponent(shareText)}`;
        window.location.href = waUrl;
        toast('Card downloaded! Opening WhatsApp to share with friends…');
        return;
      }

      if (actionType === 'telegram') {
        downloadBlob(blob, fileName);
        const tgUrl = `https://t.me/share/url?url=${encodeURIComponent(songUrl)}&text=${encodeURIComponent(shareText)}`;
        window.open(tgUrl, '_blank');
        toast('Card downloaded! Opening Telegram to share…');
        return;
      }

      if (actionType === 'facebook') {
        downloadBlob(blob, fileName);
        const fbUrl = `https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(songUrl)}`;
        window.open(fbUrl, '_blank');
        toast('Card downloaded! Opening Facebook to share…');
        return;
      }

      if (actionType === 'sms') {
        downloadBlob(blob, fileName);
        const smsUrl = `sms:?body=${encodeURIComponent(shareText)}`;
        window.location.href = smsUrl;
        toast('Card downloaded! Opening Messages…');
        return;
      }

      if (actionType === 'instagram-stories' || actionType === 'snapchat') {
        if (canShareFile) {
          try {
            await navigator.share({
              files: [file],
              title: song.title,
              text: shareText,
              url: songUrl
            });
            toast(`Opened share sheet for ${actionType === 'snapchat' ? 'Snapchat' : 'Instagram Stories'}!`);
            return;
          } catch (e) {
            if (e.name === 'AbortError') return;
          }
        }
        downloadBlob(blob, fileName);
        if (navigator.clipboard?.writeText) {
          await navigator.clipboard.writeText(songUrl);
        }
        toast(`Story card downloaded & link copied! Add to your ${actionType === 'snapchat' ? 'Snapchat' : 'Instagram'} Story 📸`);
      }
    } catch (err) {
      if (spinner) spinner.classList.remove('active');
      console.error('[LyricsShare] Share error:', err);
      toast('Could not share directly. Image downloaded instead.');
    }
  }

  function downloadBlob(blob, fileName) {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 1500);
  }

  // ─── Export to Window ───
  window.KrishLyricsShare = {
    open: openLyricsShareModal,
    state: state,
    generateBlob: generateCardImageBlob
  };

  window.openLyricsShareModal = openLyricsShareModal;

  // Auto-init on DOM ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', ensureModalsExist);
  } else {
    ensureModalsExist();
  }
})();
